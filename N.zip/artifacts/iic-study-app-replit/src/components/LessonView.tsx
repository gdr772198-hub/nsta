// @ts-nocheck

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import ReactMarkdown from 'react-markdown';
import { LessonContent, Subject, ClassLevel, Chapter, MCQItem, ContentType, User, SystemSettings } from '../types';
import { ArrowLeft, Clock, AlertTriangle, ExternalLink, CheckCircle, XCircle, Trophy, BookOpen, Play, Lock, ChevronRight, ChevronLeft, Save, X, Maximize, Minimize2, Volume2, VolumeX, Square, Zap, StopCircle, Globe, Lightbulb, FileText, BrainCircuit, Grip, CheckSquare, List, Download, BarChart3, RotateCcw, Monitor, CloudOff, MoreVertical, EyeOff, Eye, LayoutGrid, Pencil, Send, Plus, Tv, SkipForward } from 'lucide-react';
import { CustomConfirm, CustomAlert } from './CustomDialogs';
import { CreditConfirmationModal } from './CreditConfirmationModal';
import { CustomPlayer } from './CustomPlayer';
import { ModernVideoPlayer } from './ModernVideoPlayer';
import { ModernAudioPlayer } from './ModernAudioPlayer';
import { ModernPdfViewer } from './ModernPdfViewer';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { decodeHtml } from '../utils/htmlDecoder';
import { storage } from '../utils/storage';
import { getChapterData, saveUserHistory, saveTestResult, saveUserToLive, saveAdminMark2Topics, subscribeAdminMark2Topics, saveSuggestion } from '../firebase';
import { getRoutineLessonCreditGiven, setRoutineLessonCreditGiven } from '../utils/routineFirebase';
import { WriteModeCorrection } from "./WriteModeCorrection";
import { SpeakButton } from './SpeakButton';
import { McqSpeakButtons } from './McqSpeakButtons';
import { ChunkedNotesReader } from './ChunkedNotesReader';
import { recordNoteStar, recordNoteUnstar } from '../services/noteStars';
import { renderMathInHtml, formatExplanationHtml } from '../utils/mathUtils';
import McqQuestionDisplay from './McqQuestionDisplay';
import McqPracticeCard from './McqPracticeCard';
import McqQuestionNavigator from './McqQuestionNavigator';
import { hapticCorrect, hapticWrong } from '../utils/haptic';
import { playSoundClick, playSoundCorrect, playSoundWrong, playSoundVictory, isSoundEnabled, setSoundEnabled } from '../utils/soundEffects';
import { stopSpeaking } from '../utils/ttsHighlighter';
import { speakText, stripHtml } from '../utils/textToSpeech';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DownloadOptionsModal } from './DownloadOptionsModal';
import { downloadAsMHTML } from '../utils/downloadUtils';
import { saveOfflineItem } from '../utils/offlineStorage';
import { rotateScreen, isDesktopModeOn, setDesktopMode } from '../utils/displayPrefs';
import { applyDeduction, getTotalCredits } from '../utils/creditSystem';
import { getUserTier, getEffectiveNotesTier, filterHtmlByTier, injectSectionTierTags } from '../utils/permissionUtils';
import { getLevelFromScore } from '../utils/levelSystem';
import { getActiveBoost, tryEarnScore, subtractDailyScore, getMcqStreakBonus } from '../utils/scoreSystem';
import { fireCreditNotify } from '../utils/creditNotify';
import DraggableNstaLogoFab from './DraggableNstaLogoFab';
import { ReadingScoreSession, ReadingScoreState } from '../utils/readingScoreEngine';
import { ReadingScoreHUD } from './ReadingScoreHUD';
import { PdfViewer } from './PdfViewer';
import { useAppTheme } from '../utils/themeContext';
import { fireSessionComplete } from '../utils/sessionNotify';
import { deferStudyCoins } from '../utils/studyRewards';
import { getMcqStatements } from '../utils/mcqStructure';
import { extractStatements } from '../utils/mcqParser';
import { MathLessonViewer } from './MathLessonViewer';


interface Props {
  content: LessonContent | null;
  subject: Subject;
  classLevel: ClassLevel;
  chapter: Chapter;
  loading: boolean;
  onBack: () => void;
  onMCQComplete?: (count: number, answers: Record<number, number>, usedData: MCQItem[], timeTaken: number, questionTimes?: Record<number, number>) => void;
  user?: User; // Optional for non-MCQ views
  onUpdateUser?: (user: User) => void;
  settings?: SystemSettings; // New Prop for Pricing
  isStreaming?: boolean; // Support for streaming content
  onLaunchContent?: (content: any) => void;
  onToggleAutoTts?: (enabled: boolean) => void;
  instantExplanation?: boolean; // NEW: Instant Feedback Mode
  onShowMarksheet?: (result?: any) => void; // NEW: Marksheet Trigger
  onImmersiveChange?: (isImmersive: boolean) => void;
  onNext?: () => void;
  nextTitle?: string;
  schoolMode?: boolean;
  schoolControlsRef?: React.MutableRefObject<(() => void) | null>;
  onSchoolModeSwitch?: () => void;
  schoolModeSwitchDots?: boolean;
  schoolSaveOffline?: () => void;
  onAdminBoard?: () => void;
  /** Called when admin/subadmin taps the Edit button — opens content editor for this chapter. */
  onAdminEdit?: () => void;
  /** Class 6-12: kya yeh subject ka pehla lesson hai? Pehla lesson sab ke liye free hota hai. */
  isFirstChapter?: boolean;
  onSendToMcqCommunity?: (draft: { question: string; statements?: string[]; options: [string,string,string,string]; correctAnswer: number; explanation: string }) => void;
  /** Session khatam hone pe pending coins pass karo — App 4s baad HOME pe add karega */
  onSessionCreditsEarned?: (credits: number) => void;
}

export const LessonView: React.FC<Props> = ({ 
  content, 
  subject, 
  classLevel, 
  chapter,
  loading, 
  onBack,
  onMCQComplete,
  user,
  onUpdateUser,
  settings,
  isStreaming = false,
  onLaunchContent,
  onToggleAutoTts,
  instantExplanation = false, // Default to standard mode
  onShowMarksheet,
  onImmersiveChange,
  onNext,
  nextTitle,
  schoolMode = false,
  schoolControlsRef,
  onSchoolModeSwitch,
  schoolModeSwitchDots = false,
  schoolSaveOffline,
  onAdminBoard,
  onAdminEdit,
  isFirstChapter = false,
  onSendToMcqCommunity,
  onSessionCreditsEarned,
}) => {
  const appTheme = useAppTheme();
  const [mcqState, setMcqState] = useState<Record<number, number | null>>({});
  const [mcqStreak, setMcqStreak] = useState(0);
  const [soundActive, setSoundActive] = useState<boolean>(() => isSoundEnabled());

  const toggleSound = () => {
    const next = !soundActive;
    setSoundActive(next);
    setSoundEnabled(next);
    if (next) playSoundClick();
  };
  const [mcqScorePopup, setMcqScorePopup] = useState<number | null>(null);
  const [mcqScoreVisible, setMcqScoreVisible] = useState(false);
  const mcqPopupTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showMcqScore = (pts: number) => {
    if (mcqPopupTimerRef.current) clearTimeout(mcqPopupTimerRef.current);
    setMcqScorePopup(pts);
    setMcqScoreVisible(true);
    mcqPopupTimerRef.current = setTimeout(() => setMcqScoreVisible(false), 1800);
  };
  const [revealedAnswers, setRevealedAnswers] = useState<Set<number>>(new Set());
  const [timeSpentPerQuestion, setTimeSpentPerQuestion] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false); // Used to trigger Analysis Mode
  const [localMcqData, setLocalMcqData] = useState<MCQItem[]>([]);
  const [showResumePrompt, setShowResumePrompt] = useState(false);
  const [analysisUnlocked, setAnalysisUnlocked] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [language, setLanguage] = useState<'English' | 'Hindi'>('English');
  const [notesViewMode, setNotesViewMode] = useState<'readable' | 'styled'>('readable');
  const writeControlsRef = useRef<(() => void) | null>(null);
  const _modeToggleFn = useRef<((mode: 'readable' | 'styled') => void) | null>(null);
  const [pendingModeSwitch, setPendingModeSwitch] = useState<'readable' | 'styled' | null>(null);
  const _applyModeSwitchFn = useRef<((mode: 'readable' | 'styled') => void) | null>(null);
  const [pendingNextChapter, setPendingNextChapter] = useState(false);
  const [isLandscape, setIsLandscape] = useState<boolean>(() => {
    try { return window.matchMedia('(orientation: landscape)').matches; } catch { return false; }
  });
  const [viewingNoteChunkMode, setViewingNoteChunkMode] = useState(false);
  const [showModeUnlockAlert, setShowModeUnlockAlert] = useState(false);
  const [htmlUnlocked, setHtmlUnlocked] = useState<boolean>(() => {
    try {
      const key = `nst_html_unlock_${content?.id || content?.title || 'note'}`;
      return localStorage.getItem(key) === '1';
    } catch { return false; }
  });
  const [universalNotes, setUniversalNotes] = useState<any[]>([]);
  const [recLoading, setRecLoading] = useState(false);
  const [viewingNote, setViewingNote] = useState<any>(null); // New state for HTML Note Modal
  const [isDesktopMode, setIsDesktopMode] = useState<boolean>(isDesktopModeOn);
  const [rotateToast, setRotateToast] = useState<string | null>(null);
  const [isImmersive, setIsImmersive] = useState(false);
  const [showBlankScreen, setShowBlankScreen] = useState(false);
  useEffect(() => {
    if (onImmersiveChange) onImmersiveChange(isImmersive);
  }, [isImmersive]);

  // ── Reading Score Config ──────────────────────────────────────────────────
  // userRef always has the latest user — prevents stale closure when TTS fires
  // multiple onScoreEarned calls rapidly (each would see same old totalScore otherwise)
  const userRef = useRef(user);
  useEffect(() => { userRef.current = user; }, [user]);

  // ── Routine credit gating ─────────────────────────────────────────────────
  // isFirstTimeRef: true  → credits flow normally (first-ever visit)
  // isFirstTimeRef: false → pts only, no credits (repeat visit)
  // Firebase check runs on mount; pessimistic default = true (first time).
  // creditsEarnedThisSessionRef tracks whether this session actually earned anything
  // so we only write to Firebase if the user actually did something.
  const isFirstTimeRef = useRef(true);
  const creditsEarnedThisSessionRef = useRef(false);

  useEffect(() => {
    const uid = user?.id;
    const lid = chapter?.id;
    if (!uid || !lid) return;
    getRoutineLessonCreditGiven(uid, lid).then(alreadyGiven => {
      isFirstTimeRef.current = !alreadyGiven;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, chapter?.id]);

  // ── Session-complete accumulation (pts + credits per mode) ──────────────────
  const sessionReadingPtsRef = useRef(0);
  const sessionWritingPtsRef = useRef(0);
  const sessionWritingCrRef  = useRef(0);
  const sessionVideoPtsRef   = useRef(0);
  const sessionVideoCrRef    = useRef(0);
  const sessionAudioPtsRef   = useRef(0);
  const sessionPdfPtsRef     = useRef(0);
  const sessionQaPtsRef      = useRef(0);
  // MCQ flush refs — set when showResults fires, read in flushSessionEvents on back
  const mcqFlushPtsRef       = useRef(0);
  const mcqFlushCrRef        = useRef(0);

  // Per-mode time tracking — record when each mode first earned pts, accumulate on flush
  const modeFirstEarnMsRef = useRef<Partial<Record<string, number>>>({});
  const modeAccumSecsRef   = useRef<Partial<Record<string, number>>>({});

  /** Record first-earn timestamp for a mode (idempotent). */
  const markModeActive = (mode: string) => {
    if (!modeFirstEarnMsRef.current[mode]) {
      modeFirstEarnMsRef.current[mode] = Date.now();
    }
  };

  /** Get accumulated seconds for a mode (first-earn → now). */
  const getModeTimeSecs = (mode: string): number => {
    const start = modeFirstEarnMsRef.current[mode];
    if (!start) return modeAccumSecsRef.current[mode] || 0;
    return (modeAccumSecsRef.current[mode] || 0) + Math.round((Date.now() - start) / 1000);
  };

  /** Fire per-mode session-complete events and reset accumulators. */
  const flushSessionEvents = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-shadow
    const chapter = chapter?.title || '';
    const subj = subject?.name || '';

    if (sessionReadingPtsRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('Reading'),
        activityType: 'Reading', sessionScore: sessionReadingPtsRef.current });
      sessionReadingPtsRef.current = 0;
      modeFirstEarnMsRef.current['Reading'] = undefined;
      modeAccumSecsRef.current['Reading'] = 0;
    }
    if (sessionWritingPtsRef.current > 0 || sessionWritingCrRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('Writing'),
        activityType: 'Writing',
        sessionScore: sessionWritingPtsRef.current || undefined,
        creditsEarned: sessionWritingCrRef.current || undefined });
      sessionWritingPtsRef.current = 0; sessionWritingCrRef.current = 0;
      modeFirstEarnMsRef.current['Writing'] = undefined;
      modeAccumSecsRef.current['Writing'] = 0;
    }
    if (sessionVideoPtsRef.current > 0 || sessionVideoCrRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('Video'),
        activityType: 'Video',
        sessionScore: sessionVideoPtsRef.current || undefined,
        creditsEarned: sessionVideoCrRef.current || undefined });
      sessionVideoPtsRef.current = 0; sessionVideoCrRef.current = 0;
      modeFirstEarnMsRef.current['Video'] = undefined;
      modeAccumSecsRef.current['Video'] = 0;
    }
    if (sessionAudioPtsRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('Audio'),
        activityType: 'Audio', sessionScore: sessionAudioPtsRef.current });
      sessionAudioPtsRef.current = 0;
      modeFirstEarnMsRef.current['Audio'] = undefined;
      modeAccumSecsRef.current['Audio'] = 0;
    }
    if (sessionPdfPtsRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('PDF'),
        activityType: 'PDF', sessionScore: sessionPdfPtsRef.current });
      sessionPdfPtsRef.current = 0;
      modeFirstEarnMsRef.current['PDF'] = undefined;
      modeAccumSecsRef.current['PDF'] = 0;
    }
    if (sessionQaPtsRef.current > 0) {
      fireSessionComplete({ type: 'LESSON', subject: subj, chapter,
        timeSecs: getModeTimeSecs('QA'),
        activityType: 'QA', sessionScore: sessionQaPtsRef.current });
      sessionQaPtsRef.current = 0;
      modeFirstEarnMsRef.current['QA'] = undefined;
      modeAccumSecsRef.current['QA'] = 0;
    }
    if (mcqFlushPtsRef.current > 0 || mcqFlushCrRef.current > 0) {
      fireSessionComplete({ type: 'MCQ', subject: subj, chapter,
        timeSecs: getModeTimeSecs('MCQ'),
        activityType: 'MCQ',
        sessionScore: mcqFlushPtsRef.current || undefined,
        coinsEarned: mcqFlushCrRef.current || undefined });
      mcqFlushPtsRef.current = 0;
      mcqFlushCrRef.current = 0;
      modeFirstEarnMsRef.current['MCQ'] = undefined;
      modeAccumSecsRef.current['MCQ'] = 0;
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapter?.title, subject?.name]);

  const onUpdateUserRef = useRef(onUpdateUser);
  useEffect(() => { onUpdateUserRef.current = onUpdateUser; }, [onUpdateUser]);

  /** Back button handler — flushes session events, passes pending coins, then calls onBack. */
  const handleBack = useCallback(() => {
    flushSessionEvents();
    if (pendingSessionCreditsRef.current > 0) {
      onSessionCreditsEarned?.(pendingSessionCreditsRef.current);
      pendingSessionCreditsRef.current = 0;
    }
    // ── Routine Firebase: mark credits given after first session ──────────────
    // If this was a first-time session and the user actually earned credits/pts,
    // write to Firebase so the next visit knows to give pts only (no credits).
    if (isFirstTimeRef.current && creditsEarnedThisSessionRef.current) {
      const uid = userRef.current?.id;
      const lid = chapter?.id;
      if (uid && lid) {
        isFirstTimeRef.current = false; // prevent double-write if back is called again
        setRoutineLessonCreditGiven(uid, lid).catch(() => {});
      }
    }
    onBack();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flushSessionEvents, onBack, onSessionCreditsEarned, chapter?.id]);

  // ── Coin accumulation: fractional carry-over prevents small events losing coins ──
  // Reading coins are awarded immediately per interval but fractional amounts
  // carry forward so even +1 TTS events eventually convert to real coins.
  // MCQ coins are deferred to session-end (showResults) to avoid per-answer flooding.
  const mcqSessionPtsRef = useRef(0);
  // Live MCQ pts accumulated this session (shown in MCQ top bar)
  const [mcqLivePts, setMcqLivePts] = useState(0);
  // Live reading pts accumulated this session (shown in readable-mode notes chip)
  const [readingLivePts, setReadingLivePts] = useState(0);
  // Score chip tooltip visibility
  const [writingScoreTooltip, setWritingScoreTooltip] = useState(false);
  const [videoScoreTooltip, setVideoScoreTooltip] = useState(false);
  const [mcqScoreTooltip, setMcqScoreTooltip] = useState(false);
  // Fractional coin accumulator — carries sub-1 amounts between reading events
  const coinFracAccumRef = useRef(0);

  // ── Pending session coins — collected during session, applied on HOME return ──
  const pendingSessionCreditsRef = useRef(0);

  const awardMcqSessionCoins = useCallback((
    totalPts: number,
  ) => {
    if (totalPts <= 0) return;
    const _user = userRef.current;
    const _onUpdateUser = onUpdateUserRef.current;
    if (!_user || !_onUpdateUser) return;

    // ── Routine credit gating: MCQ coins only on first visit ─────────────────
    if (!isFirstTimeRef.current) return;

    const userLevel = getLevelFromScore(_user.totalScore || 0);
    const ratio = userLevel >= 5 ? (1 / 6) : 0.125;
    const isCreditEconomy = _user.studyMode === 'CREDIT';
    if (!isCreditEconomy) return;
    const coins = Math.floor(totalPts * ratio);
    if (coins <= 0) return;

    creditsEarnedThisSessionRef.current = true;

    // Save coins so flushSessionEvents can include them in MCQ session payload
    mcqFlushCrRef.current += coins;

    // Study coins stay pending until the student returns to Home.
    deferStudyCoins(_user.id, coins);
  }, []);

  const handleReadingScoreEarned = useCallback((pts: number, activity: string) => {
    const _user = userRef.current;
    const _onUpdateUser = onUpdateUserRef.current;
    if (!_user || !_onUpdateUser || pts <= 0) return;
    // Accumulate per mode for session-complete breakdown
    const act = activity?.toUpperCase() || '';
    if (act.startsWith('VIDEO')) {
      sessionVideoPtsRef.current += pts; markModeActive('Video');
    } else if (act.startsWith('AUDIO')) {
      sessionAudioPtsRef.current += pts; markModeActive('Audio');
    } else if (act.startsWith('WRITE')) {
      sessionWritingPtsRef.current += pts; markModeActive('Writing');
    } else if (act.startsWith('PDF')) {
      sessionPdfPtsRef.current += pts; markModeActive('PDF');
    } else if (act.startsWith('QA')) {
      sessionQaPtsRef.current += pts; markModeActive('QA');
    } else {
      sessionReadingPtsRef.current += pts; markModeActive('Reading');
    }
    // Update live reading chip for reading-mode activities only
    if (!act.startsWith('VIDEO') && !act.startsWith('AUDIO')) {
      setReadingLivePts(prev => prev + pts);
    }

    // Update totalScore immediately — reading/MCQ pts only
    const scoreUpdated = { ..._user, totalScore: (_user.totalScore || 0) + pts };

    // ── Routine credit gating: coins only on first visit AND Credit Economy is ON ─────────
    // If isFirstTimeRef is false (repeat visit) or not credit economy, skip coin accumulation — pts only.
    const isCreditEconomy = _user.studyMode === 'CREDIT';
    if (isFirstTimeRef.current && isCreditEconomy) {
      // Fractional coin accumulator: add this event's coin-value to running total,
      // then award only the integer part — remainder carries to the next event.
      const userLevel = getLevelFromScore(_user.totalScore || 0);
      const ratio = userLevel >= 5 ? (1 / 6) : 0.125;
      coinFracAccumRef.current += pts * ratio;
      const coins = Math.floor(coinFracAccumRef.current);
      coinFracAccumRef.current -= coins;

      // Coins deferred — accumulate for session-end (no immediate balance update / notification)
      if (coins > 0) {
        deferStudyCoins(_user.id, coins);
        pendingSessionCreditsRef.current += coins;
        creditsEarnedThisSessionRef.current = true;
      }
    }
    _onUpdateUser(scoreUpdated);
    saveUserToLive(scoreUpdated);
  }, []);

  // Credits earned directly (video 60s, pdf 60s, writing 60s) — deferred to session-end (Credit Economy only)
  const handleCreditsEarned = useCallback((credits: number, activity: string) => {
    if (credits <= 0) return;
    const isCreditEconomy = userRef.current?.studyMode === 'CREDIT';
    if (!isCreditEconomy) return;

    // Accumulate per mode for session-complete breakdown
    const act = activity?.toUpperCase() || '';
    if (act.startsWith('VIDEO')) {
      sessionVideoCrRef.current += credits; markModeActive('Video');
    } else {
      sessionWritingCrRef.current += credits; markModeActive('Writing');
    }

    // ── Routine credit gating: credits only on first visit ────────────────────
    if (!isFirstTimeRef.current) return;

    // Defer — apply on HOME return
    deferStudyCoins(userRef.current?.id, credits);
    pendingSessionCreditsRef.current += credits;
    creditsEarnedThisSessionRef.current = true;
  }, []);

  // Award MCQ coins once when results are shown (session over)
  useEffect(() => {
    if (showResults && mcqSessionPtsRef.current > 0) {
      // Save pts for flushSessionEvents BEFORE resetting
      mcqFlushPtsRef.current += mcqSessionPtsRef.current;
      awardMcqSessionCoins(mcqSessionPtsRef.current);
      mcqSessionPtsRef.current = 0;
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showResults]);

  // Lesson label shown in coin/score history: "Physics · Ch 3 Motion"
  const lessonLabel = [subject?.name, chapter?.title].filter(Boolean).join(' · ') || undefined;

  const readingScoreConfig = user?.id ? {
    userId: user.id,
    userLevel: getLevelFromScore(user.totalScore || 0),
    subscriptionLevel: user.subscriptionTier || 'FREE',
    isPremium: !!(user.isPremium || (user.subscriptionTier && user.subscriptionTier !== 'FREE')),
    boostPercent: getActiveBoost(user),
    lessonLabel,
    onScoreEarned: handleReadingScoreEarned,
  } : undefined;

  // Writing mode: pts via onScoreEarned, 5% scroll/1min required
  const writingScoreConfig = readingScoreConfig ? {
    ...readingScoreConfig,
    mode: 'writing' as const,
  } : undefined;

  // ── Media (Video / Audio) time-based score session ───────────────────────
  const mediaScoreSessionRef = useRef<ReadingScoreSession | null>(null);
  const [mediaScoreState, setMediaScoreState] = useState<ReadingScoreState | null>(null);

  // ── Writing HTML (Notes Maker styled mode) score session ─────────────────
  const writingHtmlScoreSessionRef = useRef<ReadingScoreSession | null>(null);
  const [writingHtmlScoreState, setWritingHtmlScoreState] = useState<ReadingScoreState | null>(null);

  useEffect(() => {
    // Detect if current content is video or audio
    const isVideoContent = content?.type === 'VIDEO_LECTURE' || (
      contentValue && (contentValue.startsWith('http://') || contentValue.startsWith('https://')) &&
      !['PDF_FREE','PDF_PREMIUM','PDF_ULTRA','PDF_VIEWER'].includes(content?.type || '') &&
      !content?.type?.includes('AUDIO') &&
      (contentValue.includes('youtube') || contentValue.includes('youtu.be') ||
       contentValue.includes('drive.google.com') || contentValue.includes('notebooklm.google.com'))
    );
    const isAudioContent = content?.type?.includes('AUDIO') || (
      contentValue &&
      (contentValue.includes('drive.google.com') || contentValue.includes('notebooklm.google.com')) &&
      (content?.title?.toLowerCase().includes('audio') || content?.title?.toLowerCase().includes('podcast'))
    );
    const isMediaContent = isVideoContent || isAudioContent;

    if (!isMediaContent || !user?.id) {
      if (mediaScoreSessionRef.current) {
        mediaScoreSessionRef.current.stop();
        mediaScoreSessionRef.current = null;
        setMediaScoreState(null);
      }
      return;
    }

    const _lessonLabel = [subject?.name, chapter?.title].filter(Boolean).join(' · ') || undefined;
    const session = new ReadingScoreSession(
      {
        userId: user.id,
        userLevel: getLevelFromScore(user.totalScore || 0),
        subscriptionLevel: user.subscriptionTier || 'FREE',
        isPremium: !!(user.isPremium || (user.subscriptionTier && user.subscriptionTier !== 'FREE')),
        boostPercent: getActiveBoost(user as any),
        mode: isAudioContent ? 'audio' : 'video',
        lessonLabel: _lessonLabel,
        // Video: 6s → +1 pts; Audio: 30s → pts
        onScoreEarned: handleReadingScoreEarned,
        // Video: 60s → +10 credits (doesn't affect pts/totalScore)
        onCreditsEarned: isVideoContent ? handleCreditsEarned : undefined,
      },
      (state) => setMediaScoreState(state),
    );
    mediaScoreSessionRef.current = session;
    session.start();

    // YouTube play/pause detection via postMessage (enablejsapi=1)
    // playerState: 1=playing, 2=paused, 0=ended, 3=buffering, -1=unstarted
    const handleYtMessage = (e: MessageEvent) => {
      if (typeof e.data !== 'string') return;
      try {
        const data = JSON.parse(e.data);
        if (data.event === 'infoDelivery' && data.info?.playerState !== undefined) {
          const playing = data.info.playerState === 1 || data.info.playerState === 3;
          mediaScoreSessionRef.current?.setVideoPlaying(playing);
        }
        // Also handle onStateChange format
        if (data.event === 'onStateChange' && data.info !== undefined) {
          const playing = data.info === 1 || data.info === 3;
          mediaScoreSessionRef.current?.setVideoPlaying(playing);
        }
      } catch {}
    };

    if (isVideoContent) {
      window.addEventListener('message', handleYtMessage);
    }

    return () => {
      session.stop();
      mediaScoreSessionRef.current = null;
      if (isVideoContent) {
        window.removeEventListener('message', handleYtMessage);
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [content?.id, content?.type, user?.id]);

  // Writing HTML (Notes Maker styled mode) score session — starts when user switches to styled mode
  useEffect(() => {
    if (notesViewMode !== 'styled' || !writingScoreConfig) {
      if (writingHtmlScoreSessionRef.current) {
        writingHtmlScoreSessionRef.current.stop();
        writingHtmlScoreSessionRef.current = null;
        setWritingHtmlScoreState(null);
      }
      return;
    }
    const session = new ReadingScoreSession(writingScoreConfig, setWritingHtmlScoreState);
    writingHtmlScoreSessionRef.current = session;
    session.start();
    return () => {
      session.stop();
      writingHtmlScoreSessionRef.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notesViewMode, writingScoreConfig?.userId]);

  // On mount: always re-apply stored desktop mode preference to the viewport
  useEffect(() => {
    const current = isDesktopModeOn();
    setDesktopMode(current);
    setIsDesktopMode(current);
  }, []);

  // Re-apply desktop mode whenever orientation changes (manual or programmatic rotation)
  useEffect(() => {
    const reapply = () => {
      // Wait for browser to settle after rotation then re-apply viewport
      setTimeout(() => {
        const current = isDesktopModeOn();
        setDesktopMode(current);
        setIsDesktopMode(current);
      }, 400);
    };
    window.addEventListener('orientationchange', reapply);
    window.addEventListener('resize', reapply);
    return () => {
      window.removeEventListener('orientationchange', reapply);
      window.removeEventListener('resize', reapply);
    };
  }, []);

  const handleRotate = async () => {
    const newVal = !isDesktopMode;
    setDesktopMode(newVal);
    setIsDesktopMode(newVal);
    setRotateToast(newVal ? '💻 Desktop Mode: ON (Compact Layout)' : '📱 Mobile Mode: ON');
    setTimeout(() => setRotateToast(null), 2200);
  };

  const toggleDesktopMode = () => {
    const newVal = !isDesktopMode;
    setDesktopMode(newVal);
    setIsDesktopMode(newVal);
  };

  const [showQuestionDrawer, setShowQuestionDrawer] = useState(false);
  const [showTopicSidebar, setShowTopicSidebar] = useState(false);
  const [batchIndex, setBatchIndex] = useState(0);
  const [skippedQuestions, setSkippedQuestions] = useState<Set<number>>(new Set());
  const [comparisonMsg, setComparisonMsg] = useState('');
  const [activeAnalysisTab, setActiveAnalysisTab] = useState<'CHAPTER_ANALYSIS' | 'OVERVIEW' | 'QUESTIONS' | 'MISTAKES'>('CHAPTER_ANALYSIS');
  // Auto-enable TTS for Premium Instant Explanation Mode
  const [autoReadEnabled, setAutoReadEnabled] = useState(settings?.isAutoTtsEnabled || instantExplanation || false);
  const BATCH_SIZE = 1;

  // Per-topic star system (same storage as StudentDashboard: nst_starred_notes_v1)
  const noteKey = chapter?.id ? `chapter_${chapter.id}` : '';
  type StarEntry = { id: string; noteKey: string; topicText: string; savedAt: string };
  const [lessonStars, setLessonStars] = useState<StarEntry[]>(() => {
    try {
      const raw = localStorage.getItem('nst_starred_notes_v1');
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  });
  const isTopicStarred = (text: string) =>
    lessonStars.some(n => n.noteKey === noteKey && n.topicText === text);
  const toggleTopicStar = (text: string) => {
    const exists = lessonStars.some(n => n.noteKey === noteKey && n.topicText === text);
    setLessonStars(prev => {
      const updated = exists
        ? prev.filter(n => !(n.noteKey === noteKey && n.topicText === text))
        : [...prev, { id: Date.now().toString(), noteKey, topicText: text, savedAt: new Date().toISOString() }];
      try { localStorage.setItem('nst_starred_notes_v1', JSON.stringify(updated)); } catch {}
      return updated;
    });
    // Global social-proof sync so ANY user saving a note reflects globally in trending
    if (user?.id) {
      if (!exists) {
        recordNoteStar(user.id, noteKey, text, {
          lessonTitle: chapter?.title || content?.title,
          subject: subject?.title || subject?.name,
        }).catch(() => {});
      } else {
        recordNoteUnstar(user.id, text).catch(() => {});
      }
    }
    // Admin star in Class 6-12 → also save to Firebase Mark 2 so ALL users
    // see the orange highlight in their own reader instantly.
    if (isAdmin) {
      const existsInMark2 = mark2Topics.includes(text);
      const updatedMark2 = existsInMark2
        ? mark2Topics.filter(t => t !== text)
        : [...mark2Topics, text];
      setMark2Topics(updatedMark2);
      saveAdminMark2Topics(noteKey, updatedMark2);
    }
  };

  // Admin highlight system — admin stars a topic → RTDB → all users see orange highlight
  const isAdmin = user?.role === 'ADMIN' || user?.role === 'SUB_ADMIN';

  const [mark2Topics, setMark2Topics] = useState<string[]>([]);

  // Real-time RTDB subscription — all users get live highlight updates
  useEffect(() => {
    if (!noteKey) return;
    const unsub = subscribeAdminMark2Topics(noteKey, (topics) => {
      setMark2Topics(topics);
    });
    return unsub;
  }, [noteKey]);

  const isTopicMark2 = (text: string) => mark2Topics.includes(text);

  const submitRef = useRef<() => void>();

  useEffect(() => {
      if (settings?.isAutoTtsEnabled !== undefined) {
          setAutoReadEnabled(settings.isAutoTtsEnabled);
      } else if (instantExplanation) {
          setAutoReadEnabled(true);
      }
  }, [settings?.isAutoTtsEnabled, instantExplanation]);

  // LANDSCAPE DETECTION
  useEffect(() => {
    try {
      const mq = window.matchMedia('(orientation: landscape)');
      const handler = (e: MediaQueryListEvent) => setIsLandscape(e.matches);
      mq.addEventListener('change', handler);
      return () => mq.removeEventListener('change', handler);
    } catch {}
  }, []);

  // LANGUAGE AUTO-SELECT
  useEffect(() => {
    if (user?.board === 'BSEB' || user?.board === 'NCERT_HI') {
        setLanguage('Hindi');
    } else if (user?.board === 'NCERT_EN') {
        setLanguage('English');
    }
  }, [user?.board]);

  // LOAD UNIVERSAL NOTES FOR ANALYSIS
  useEffect(() => {
      if (content?.type === 'MCQ_ANALYSIS' && universalNotes.length === 0) {
          setRecLoading(true);
          getChapterData('nst_universal_notes').then(data => {
              if (data && data.notesPlaylist) {
                  setUniversalNotes(data.notesPlaylist);
              }
              setRecLoading(false);
          });
      }
  }, [content?.type]);

  // Full Screen Ref
  const containerRef = useRef<HTMLDivElement>(null);
  const projectorContainerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isProjectorFullscreen, setIsProjectorFullscreen] = useState(false);
  const [showSuggestionPanel, setShowSuggestionPanel] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [mcqSuggestionOpen, setMcqSuggestionOpen] = useState<Record<number, boolean>>({});
  const [mcqSuggestionText, setMcqSuggestionText] = useState<Record<number, string>>({});
  const [mcqSuggestionSent, setMcqSuggestionSent] = useState<Set<number>>(new Set());

  // ── Projector Mode ──
  const [isProjectorMode, setIsProjectorMode] = useState(false);
  const [projectorQIndex, setProjectorQIndex] = useState(0);
  const [projectorReveal, setProjectorReveal] = useState(false);
  const [projectorSelected, setProjectorSelected] = useState<number | null>(null);
  const [projectorFocused, setProjectorFocused] = useState(false);
  const [projectorSelections, setProjectorSelections] = useState<Record<number, number>>({});
  const [projectorSkipped, setProjectorSkipped] = useState<Set<number>>(new Set());
  const [projectorNavigatorOpen, setProjectorNavigatorOpen] = useState(false);
  const [projectorShowReview, setProjectorShowReview] = useState(false);

  const toggleFullScreen = () => {
      if (!document.fullscreenElement) {
          const request = containerRef.current?.requestFullscreen();
          if (!request) return;
          request.then(() => setIsFullscreen(true)).catch(e => console.error(e));
      } else {
          document.exitFullscreen().then(() => {
              setIsFullscreen(false);
          });
      }
  };

  const toggleProjectorFullscreen = async () => {
      const projectorElement = projectorContainerRef.current;
      if (!projectorElement) return;

      try {
          if (document.fullscreenElement === projectorElement) {
              await document.exitFullscreen();
          } else {
              // A different fullscreen target can be left behind when the
              // projector is opened from an already immersive lesson.
              if (document.fullscreenElement) {
                  await document.exitFullscreen();
              }
              await projectorElement.requestFullscreen();
          }
      } catch (error) {
          console.error('Unable to toggle projector fullscreen', error);
      }
  };

  const closeProjectorMode = async () => {
      if (document.fullscreenElement === projectorContainerRef.current) {
          try {
              await document.exitFullscreen();
          } catch (error) {
              console.error('Unable to exit projector fullscreen', error);
          }
      }
      setIsProjectorMode(false);
  };

  useEffect(() => {
      const handleFullscreenChange = () => {
           setIsFullscreen(document.fullscreenElement === containerRef.current);
           setIsProjectorFullscreen(document.fullscreenElement === projectorContainerRef.current);
      };
      document.addEventListener('fullscreenchange', handleFullscreenChange);
      return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
      if (isProjectorMode) return;
      if (document.fullscreenElement === projectorContainerRef.current) {
          document.exitFullscreen().catch(() => {});
      }
      setIsProjectorFullscreen(false);
  }, [isProjectorMode]);

  // Keyboard shortcut for Projector Mode (M for sound mute/unmute)
  useEffect(() => {
      if (!isProjectorMode) return;
      const handleKeyDown = (e: KeyboardEvent) => {
          if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
          if (e.key === 'm' || e.key === 'M') {
              e.preventDefault();
              toggleSound();
          }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isProjectorMode, soundActive]);

  // TIMER STATE
  const [sessionTime, setSessionTime] = useState(0); // Total seconds
  
      // TIMER EFFECT (UPDATED: Track Per Question)
  useEffect(() => {
      let interval: any;
          if (!showResults && !showSubmitModal && !showResumePrompt && content?.mcqData) {
          interval = setInterval(() => {
              setSessionTime(prev => prev + 1);

                  // Track time for current question (only if viewing 1 question at a time or first in batch)
                  // Assuming batchIndex corresponds to question index if BATCH_SIZE is 1
                  if (true) { // BATCH_SIZE is confirmed 1 in render logic
                      setTimeSpentPerQuestion(prev => ({
                          ...prev,
                          [batchIndex]: (prev[batchIndex] || 0) + 1
                      }));
                  }
          }, 1000);
      }
      return () => clearInterval(interval);
      }, [showResults, showSubmitModal, showResumePrompt, batchIndex, content]);

  // ANTI-CHEAT (Exam Mode)
  useEffect(() => {
      if (content?.subtitle?.includes('Premium Test') && !showResults && !showSubmitModal) {
          const handleVisibilityChange = () => {
              if (document.hidden) {
                  setAlertConfig({isOpen: true, message: "⚠️ Exam Mode Violation! Test Submitted Automatically."});
                  // Defer the submit call to avoid circular dependency before definition
                  // Since handleConfirmSubmit is defined below, we might need a ref or define it earlier.
                  // However, useEffect runs after render, so `handleConfirmSubmit` const should be available if defined in scope.
                  // The issue is likely `handleConfirmSubmit` is used before definition in this closure?
                  // No, hoisting applies to function declarations, not const arrow functions.
                  if (submitRef.current) {
                      submitRef.current();
                  }
              }
          };
          document.addEventListener("visibilitychange", handleVisibilityChange);
          return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
      }
  }, [content, showResults, showSubmitModal, mcqState]);

  // Custom Dialog State
  const [alertConfig, setAlertConfig] = useState<{isOpen: boolean, message: string, type?: 'ERROR' | 'SUCCESS' | 'INFO'}>({isOpen: false, message: ''});
  const [confirmConfig, setConfirmConfig] = useState<{isOpen: boolean, title: string, message: string, onConfirm: () => void}>({isOpen: false, title: '', message: '', onConfirm: () => {}});

  // TTS STATE
  const contentRef = useRef<HTMLDivElement>(null);
  const plainTextContent = content ? decodeHtml(content.aiHtmlContent || content.content || "") : "";

  if (loading) {
      return (
          <div className="h-[70vh] flex flex-col items-center justify-center text-center p-8">
              <div className="w-16 h-16 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin mb-4"></div>
              <h3 className="text-xl font-bold text-slate-800 animate-pulse">Loading Content...</h3>
              <p className="text-slate-600 text-sm">Please wait while we fetch the data.</p>
          </div>
      );
  }

  if (!content) return null;

  // ── MATH DIGITAL PICTURE VIEWER (BOOK / PREMIUM NOTES / SOLUTION / MCQ) ──
  const isMathSubject =
    subject?.name?.toLowerCase().includes('math') ||
    subject?.name?.toLowerCase().includes('ganit') ||
    subject?.name?.includes('गणित') ||
    subject?.id?.toLowerCase().includes('math');

  const hasMathImagePages =
    (content.mathBookPages && content.mathBookPages.length > 0) ||
    (content.mathPremiumNotesPages && content.mathPremiumNotesPages.length > 0) ||
    (content.mathSolutionPages && content.mathSolutionPages.length > 0);

  if (hasMathImagePages || (isMathSubject && (content.mathBookPages || content.mathPremiumNotesPages || content.mathSolutionPages))) {
    return (
      <MathLessonViewer
        content={content}
        chapterTitle={chapter?.title || content.title || 'Math Lesson'}
        subjectName={subject?.name || 'Mathematics'}
        user={user!}
        onBack={onBack}
        onUpdateUser={onUpdateUser}
        onSessionCreditsEarned={onSessionCreditsEarned}
      />
    );
  }

  // 1. AI IMAGE/HTML NOTES
  const activeContentValue = (language === 'Hindi' && content.schoolPremiumNotesHtml_HI) 
      ? content.schoolPremiumNotesHtml_HI 
      : (content.content || content.pdfUrl || content.videoUrl || '');

  const contentValue = activeContentValue;
  const isImage = contentValue && (contentValue.startsWith('data:image') || contentValue.match(/\.(jpeg|jpg|gif|png|webp|bmp)$/i));
  const isHtml = content.aiHtmlContent || (contentValue && !contentValue.startsWith('http') && contentValue.includes('<'));

  // SCHOOL MODE FREE NOTES FIX
  const isFree = content.type === 'PDF_FREE' || content.type === 'NOTES_HTML_FREE' || (content.type === 'VIDEO_LECTURE' && content.videoPlaylist?.some(v => v.access === 'FREE'));
  
  const [fabOpen, setFabOpen] = useState(false);
  const [savedOffline, setSavedOffline] = useState(false);

  const handleSaveNotesOffline = () => {
    if (!user) return;
    const htmlContent = content?.aiHtmlContent || (content?.content?.includes('<') ? content.content : null);
    saveOfflineItem({
      id: `notes_${chapter.id}`,
      type: 'NOTE',
      title: chapter.title,
      subtitle: subject.name,
      data: {
        html: htmlContent,
        theory: content?.content,
        topicNotes: content?.topicNotes,
        questions: localMcqData,
      }
    });
    setSavedOffline(true);
    setAlertConfig({ isOpen: true, message: '✅ Notes saved offline! Check the Offline tab.', type: 'SUCCESS' });
  };

  // FLOATING IMMERSIVE BUTTON — always rendered via portal into document.body
  // so it escapes any fixed/overflow parent stacking context.
  // Note: Disabled when viewing MCQ content as per user requirement.
  const isMcqContent = (content.type === 'MCQ_ANALYSIS' || content.type === 'MCQ_SIMPLE' || content.type === 'MCQ_RESULT') || (Boolean(content.mcqData) && (content.mcqData?.length || 0) > 0 && content.type?.includes('MCQ'));
  const fabBottom = isImmersive ? 16 : 80;
  const floatingBtn = isMcqContent ? null : createPortal(
    <>
      {/* Backdrop — close menu on outside tap (not in schoolMode) */}
      {fabOpen && !schoolMode && (
        <div
          style={{ position: 'fixed', inset: 0, zIndex: 9190 }}
          onClick={() => setFabOpen(false)}
        />
      )}

      {/* Sub-action buttons above FAB (not in schoolMode — direct focus toggle instead) */}
      {fabOpen && !schoolMode && (
        <div style={{ position: 'fixed', bottom: fabBottom + 68, right: '16px', zIndex: 9200, display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'flex-end' }}>
          <button
            onClick={() => { setIsImmersive(v => !v); setFabOpen(false); }}
            style={{ display: 'flex', alignItems: 'center', gap: '6px', background: isImmersive ? '#4f46e5' : '#1e293b', color: '#fff', border: 'none', borderRadius: '24px', padding: '8px 14px', fontSize: '12px', fontWeight: 900, boxShadow: '0 4px 16px rgba(0,0,0,0.25)', cursor: 'pointer', whiteSpace: 'nowrap' }}
          >
            {isImmersive ? '↩ Exit Focus' : '🎯 Focus Mode'}
          </button>
          {isAdmin && (localMcqData.length > 0 || (content?.mcqData && content.mcqData.length > 0)) && (
            <button
              onClick={() => { setProjectorQIndex(0); setProjectorReveal(false); setProjectorSelections({}); setProjectorSkipped(new Set()); setProjectorNavigatorOpen(false); setProjectorShowReview(false); setIsProjectorMode(true); setFabOpen(false); }}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#d97706', color: '#fff', border: 'none', borderRadius: '24px', padding: '8px 14px', fontSize: '12px', fontWeight: 900, boxShadow: '0 4px 16px rgba(0,0,0,0.25)', cursor: 'pointer', whiteSpace: 'nowrap' }}
            >
              📽️ Projector Mode
            </button>
          )}
          {isHtml && (
            <button
              onClick={() => { _modeToggleFn.current?.(notesViewMode === 'readable' ? 'styled' : 'readable'); setFabOpen(false); }}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', background: notesViewMode === 'styled' ? '#0f766e' : '#6366f1', color: '#fff', border: 'none', borderRadius: '24px', padding: '8px 14px', fontSize: '12px', fontWeight: 900, boxShadow: '0 4px 16px rgba(0,0,0,0.25)', cursor: 'pointer', whiteSpace: 'nowrap' }}
            >
              {notesViewMode === 'styled' ? <><Volume2 size={14} /> TTS Reader</> : <><FileText size={14} /> Notes Maker</>}
            </button>
          )}
        </div>
      )}

      {/* Main FAB button — draggable anywhere on screen, in schoolMode: direct focus toggle; otherwise open menu */}
      <DraggableNstaLogoFab
        isActive={isImmersive || fabOpen}
        onToggle={() => (schoolMode ? setIsImmersive(v => !v) : setFabOpen(v => !v))}
        appLogo={settings?.appLogo}
        appName={settings?.appShortName || settings?.appName || 'NSTA'}
        title={schoolMode ? (isImmersive ? 'Exit Focus Mode' : 'Focus Mode') : (fabOpen ? 'Close menu' : 'Options')}
        defaultPosition={{ bottom: fabBottom, right: 16 }}
        zIndex={99999}
      >
        {schoolMode ? (
          isImmersive ? (
            <X size={22} style={{ color: '#fff', pointerEvents: 'none' }} />
          ) : settings?.appLogo ? (
            <img src={settings.appLogo} alt="App" style={{ width: '38px', height: '38px', objectFit: 'contain', borderRadius: '50%', pointerEvents: 'none' }} />
          ) : (
            <span style={{ fontSize: '18px', fontWeight: 900, color: '#fff', pointerEvents: 'none' }}>{(settings?.appShortName || settings?.appName || 'A').charAt(0)}</span>
          )
        ) : fabOpen ? (
          <X size={22} style={{ color: '#fff', pointerEvents: 'none' }} />
        ) : settings?.appLogo ? (
          <img src={settings.appLogo} alt="App" style={{ width: '38px', height: '38px', objectFit: 'contain', borderRadius: '50%', pointerEvents: 'none' }} />
        ) : (
          <span style={{ fontSize: '18px', fontWeight: 900, color: '#fff', pointerEvents: 'none' }}>
            {(settings?.appShortName || settings?.appName || 'A').charAt(0)}
          </span>
        )}
      </DraggableNstaLogoFab>
    </>,
    document.body
  );

  // NEXT CHAPTER COIN MODAL — 20 coins to advance to the next reading page
  const nextChapterModal = pendingNextChapter && onNext && user && onUpdateUser
    ? createPortal(
        <CreditConfirmationModal
          title={`📖 Agla Chapter: ${nextTitle || 'Next'}`}
          cost={20}
          user={user}
          userCredits={getTotalCredits(user)}
          onConfirm={() => {
            const updated = applyDeduction(user, 20);
            if (updated) { onUpdateUser(updated); saveUserToLive(updated); }
            setPendingNextChapter(false);
            onNext();
          }}
          onCancel={() => setPendingNextChapter(false)}
          isAutoEnabledInitial={false}
        />,
        document.body
      )
    : null;

  // COIN DEDUCTION MODAL — shown when user tries to switch reading/writing mode
  const coinModal = pendingModeSwitch !== null && user && onUpdateUser
    ? createPortal(
        <CreditConfirmationModal
          title={pendingModeSwitch === 'readable' ? '📖 Reading Mode (TTS)' : '✨ Premium Notes'}
          cost={20}
          user={user}
          userCredits={getTotalCredits(user)}
          onConfirm={() => {
            const updated = applyDeduction(user, 20);
            if (updated) { onUpdateUser(updated); saveUserToLive(updated); }
            const target = pendingModeSwitch;
            setPendingModeSwitch(null);
            _applyModeSwitchFn.current?.(target!);
          }}
          onCancel={() => setPendingModeSwitch(null)}
          isAutoEnabledInitial={false}
        />,
        document.body
      )
    : null;

  // FREE HTML NOTE MODAL
  if (viewingNote) {
      return (
          <div className="fixed inset-0 z-[200] bg-white flex flex-col">
              {/* Header */}
              <header className="px-3 py-2.5 flex items-center gap-2.5 shadow-md sticky top-0 z-10" style={{ background: appTheme.topBarGrad }}>
                  <button onClick={() => { setViewingNote(null); setViewingNoteChunkMode(false); }} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"><X size={18}/></button>
                  <div className="min-w-0 flex-1 flex items-center gap-2">
                      {settings?.appLogo && <img src={settings.appLogo} className="w-7 h-7 object-contain rounded-lg shrink-0" />}
                      <div className="min-w-0">
                          <h2 className="font-black text-white uppercase text-[13px] truncate leading-tight">{settings?.appName || 'Free Notes'}</h2>
                          <p className="text-[10px] text-amber-300 font-bold uppercase tracking-widest">📖 Recommended Reading</p>
                      </div>
                  </div>
                  <button
                    onClick={() => setViewingNoteChunkMode(m => !m)}
                    className={`shrink-0 p-2 rounded-xl transition-colors ${viewingNoteChunkMode ? 'bg-amber-400/30 text-amber-300' : 'bg-white/10 text-white hover:bg-white/20'}`}
                    title={viewingNoteChunkMode ? 'HTML Mode' : 'TTS Reader'}
                  >
                    <Volume2 size={18} />
                  </button>
                  <button onClick={toggleFullScreen} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors" title="Toggle Fullscreen"><Maximize size={18} /></button>
              </header>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-6 bg-slate-50">
                  <div className="w-full mx-auto bg-white p-6 rounded-3xl shadow-sm border border-slate-100 min-h-[50vh]">
                      <h1 className="text-2xl font-black text-slate-900 mb-6 border-b pb-4">{viewingNote.title}</h1>
                      {viewingNoteChunkMode ? (
                          <ChunkedNotesReader
                              key={`viewing-note-chunk-${viewingNote.title}`}
                              content={decodeHtml(viewingNote.content)
                                  .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
                                  .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
                                  .replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>|<\/div>|<\/li>|<\/h[1-6]>/gi, '\n')
                                  .replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ')
                                  .replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim()}
                              topBarLabel={viewingNote.title}
                              preferChunkMode
                              hideTopBar={false}
                          />
                      ) : (
                          <div
                              className="notes-html-content"
                              dangerouslySetInnerHTML={{ __html: renderMathInHtml(decodeHtml(viewingNote.content)) }}
                          />
                      )}
                  </div>
              </div>

          </div>
      );
  }

  if (content.type === 'NOTES_IMAGE_AI' || isImage || isHtml) {
      const preventMenu = (e: React.MouseEvent | React.TouchEvent) => e.preventDefault();
      
      if (isHtml) {
          const htmlToRender = content.aiHtmlContent || content.content;
          const decodedContent = decodeHtml(htmlToRender);
          // Tier filter — locked data-tier blocks remove karo BEFORE stripping
          // taaki readable/TTS mode mein bhi gated content nahi dikhega
          const _notesTier = classLevel !== 'COMPETITION' ? getEffectiveNotesTier(user ?? null, isFirstChapter) : 'ULTRA';
          const taggedContent = classLevel !== 'COMPETITION' ? injectSectionTierTags(decodedContent) : decodedContent;
          const filteredContent = filterHtmlByTier(taggedContent, _notesTier);
          const strippedContent = filteredContent
              .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
              .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
              // Block-level closers → newline so 📌/📖/📝/💡 section markers
              // stay on separate lines; without this, splitNoteSections' heading
              // regex ([^\n]*) grabs the entire content as one giant heading and
              // repeats it across all three tabs (Book Text / Smart Notes / आसान समझ).
              .replace(/<\/?\s*(?:p|div|h[1-6]|li|ul|ol|tr|td|th|section|article|blockquote|pre|br)\s*[^>]*>/gi, '\n')
              .replace(/<[^>]*>/g, ' ')
              .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
              .replace(/[^\S\n]+/g, ' ')   // collapse spaces/tabs but keep newlines
              .replace(/\n{3,}/g, '\n\n')  // max 2 consecutive newlines
              .trim();

          const isPremiumUser = !!(user?.isPremium || (user?.subscriptionTier && user.subscriptionTier !== 'FREE'));
          const HTML_UNLOCK_COST = 10;
          const htmlUnlockKey = `nst_html_unlock_${content?.id || content?.title || 'note'}`;

          const handleNotesMakerDownload = async () => {
              // Ensure desktop mode is on for the download (full-width render)
              const wasDesktop = isDesktopModeOn();
              if (!wasDesktop) { setDesktopMode(true); setIsDesktopMode(true); }
              await new Promise(r => setTimeout(r, 300));
              await downloadAsMHTML('notes-maker-printable', `${content.title}_Notes`, {
                  appName: 'NSTA',
                  pageTitle: content.title,
                  subtitle: chapter?.subject || 'Notes',
              });
              if (!wasDesktop) { setDesktopMode(false); setIsDesktopMode(false); }
          };

          const MODE_COIN_COST = 20;
          const isUserWithoutCredit = (user?.studyMode || 'WITHOUT_CREDIT') !== 'CREDIT';
          const isWithoutCreditOrVip = isUserWithoutCredit && Boolean(user?.isPremium || user?.subscriptionLevel === 'BASIC' || user?.subscriptionLevel === 'ULTRA' || user?.subscriptionTier === 'BASIC' || user?.subscriptionTier === 'ULTRA' || isPremiumUser || user?.role === 'ADMIN' || user?.role === 'SUB_ADMIN');

          const applyModeSwitch = (targetMode: 'readable' | 'styled') => {
              const currentDesktop = isDesktopModeOn();
              setIsDesktopMode(currentDesktop);
              setDesktopMode(currentDesktop);
              if (targetMode === 'styled') {
                  if (!isPremiumUser && !isWithoutCreditOrVip && !htmlUnlocked && user && onUpdateUser) {
                      const updatedUser = applyDeduction(user, HTML_UNLOCK_COST)!;
                      onUpdateUser(updatedUser);
                      saveUserToLive(updatedUser);
                      try { localStorage.setItem(htmlUnlockKey, '1'); } catch {}
                      setHtmlUnlocked(true);
                  }
                  setNotesViewMode('styled');
              } else {
                  setNotesViewMode('readable');
              }
          };

          const handleModeToggle = (targetMode: 'readable' | 'styled') => {
              if (targetMode === notesViewMode) return;
              // Show 20-coin deduction popup only if Credit Economy is ON and user is not VIP / Without Credit
              if (!user || !onUpdateUser || user.studyMode !== 'CREDIT' || isWithoutCreditOrVip) {
                  applyModeSwitch(targetMode);
                  return;
              }
              setPendingModeSwitch(targetMode);
          };
          _modeToggleFn.current = handleModeToggle;
          _applyModeSwitchFn.current = applyModeSwitch;

          // Strip leading title heading from HTML to avoid showing title twice
          // filteredContent use karo (tier-gated) — decodedContent nahi (unfiltered)
          const deduplicatedHtml = filteredContent.replace(/^(\s*<(div|section)[^>]*>\s*)?<h[12][^>]*>[^<]*<\/h[12]>/i, '');

          // Mode switcher panel (shared for both portrait and landscape)
          const modeSwitcher = (
              <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-1">
                      <div className="flex items-center bg-slate-200 rounded-2xl p-1 gap-1 shadow-inner flex-1">
                          <button
                              onClick={() => handleModeToggle('readable')}
                              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black uppercase tracking-wide transition-all duration-200 ${
                                  notesViewMode === 'readable'
                                      ? 'bg-white text-indigo-700 shadow-md'
                                      : 'text-slate-500 hover:text-slate-700'
                              }`}
                          >
                              <Volume2 size={14} />
                              TTS Reader
                          </button>
                          <button
                              onClick={() => handleModeToggle('styled')}
                              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black uppercase tracking-wide transition-all duration-200 ${
                                  notesViewMode === 'styled'
                                      ? 'bg-white text-teal-700 shadow-md'
                                      : 'text-slate-500 hover:text-slate-700'
                              }`}
                          >
                              <FileText size={14} />
                              Notes Maker
                              {!isPremiumUser && !htmlUnlocked && (
                                  <span className="text-[9px] bg-amber-500 text-white rounded-full px-1.5 py-0.5 font-black leading-none">
                                      {HTML_UNLOCK_COST}🪙
                                  </span>
                              )}
                          </button>
                      </div>
                      {/* Rotate button — accessible in both read and write modes */}
                      <button
                          onClick={handleRotate}
                          className="p-2.5 bg-slate-200 hover:bg-slate-300 rounded-2xl text-slate-600 transition-colors flex-shrink-0"
                          title="Screen Rotate"
                      >
                          <RotateCcw size={15} />
                      </button>
                  </div>
                  {isLandscape && (
                      <div className="text-[10px] text-slate-400 text-center mt-1">
                          {notesViewMode === 'readable' ? 'TTS Reader' : 'Notes Maker'} mode
                      </div>
                  )}
              </div>
          );

          // Notes content panel (shared for both portrait and landscape)
          const notesContent = (
              <>
                  {notesViewMode === 'readable' ? (
                      <ChunkedNotesReader
                          content={strippedContent}
                          language={language === 'Hindi' ? 'hi-IN' : 'en-US'}
                          topBarLabel={content.title}
                          className="bg-white p-4 sm:p-5 rounded-2xl shadow-sm border border-slate-100 mt-2"
                          noteKey={noteKey}
                          isStarred={isTopicStarred}
                          onStarToggle={toggleTopicStar}
                          preferChunkMode
                          hideTopBar={isImmersive}
                          hideFix={schoolMode}
                          hideDesktopToggle={true}
                          suppressStickyControls={schoolMode}
                          triggerControlsRef={schoolControlsRef}
                          onMoreOptions={schoolMode && onSchoolModeSwitch ? onSchoolModeSwitch : undefined}
                          onDesktopModeChange={setIsDesktopMode}
                          readingScoreConfig={readingScoreConfig}
                          isAdmin={isAdmin}
                          useImportantMark2={false}
                          isMarked2={isTopicMark2}
                          onMark2Toggle={undefined}
                          onSaveOffline={schoolSaveOffline ?? (user ? handleSaveNotesOffline : undefined)}
                          isSavedOffline={savedOffline}
                          onAdminEdit={isAdmin ? onAdminEdit : undefined}
                          onBack={schoolMode ? onBack : undefined}
                      />
                  ) : (
                      <>
                      {/* Notes Maker top bar — label, download, exit */}
                      <div className="flex items-center justify-between px-1 py-1 mb-1">
                          <span className="text-[10px] font-black text-teal-600 uppercase tracking-widest flex items-center gap-1">
                              <FileText size={11} /> Notes Maker
                          </span>
                          <div className="flex items-center gap-2">
                              <button
                                  onClick={handleNotesMakerDownload}
                                  className="flex items-center gap-1 text-[10px] font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 hover:bg-emerald-100 active:scale-95 transition-all"
                              >
                                  <Download size={10} /> Save
                              </button>
                              <button
                                  onClick={() => handleModeToggle('readable')}
                                  className="flex items-center gap-1 text-[10px] font-black text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200 hover:bg-slate-200 active:scale-95 transition-all"
                              >
                                  <X size={10} /> Exit
                              </button>
                          </div>
                      </div>
                      {/* Printable container: wraps all Notes Maker HTML for download */}
                      <div id="notes-maker-printable">
                      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden mt-2">
                          <div
                              className="notes-html-content p-4 sm:p-6"
                              dangerouslySetInnerHTML={{ __html: renderMathInHtml(deduplicatedHtml) }}
                              style={{ fontSize: '15px', lineHeight: '1.8' }}
                              {...(classLevel !== 'COMPETITION' ? { 'data-user-tier': getEffectiveNotesTier(user ?? null, isFirstChapter) } : {})}
                          />
                      </div>
                      {/* MULTI-HTML SECTIONS: Additional HTML blocks on same page */}
                      {(() => {
                          const sections = (content as any).schoolHtmlSections || (content as any).competitionHtmlSections || (content as any).htmlSections;
                          if (!sections || sections.length === 0) return null;
                          return sections.map((sec: { id: string; title?: string; html: string; chunkNotes?: string }, idx: number) => {
                              const hasChunk = !!(sec.chunkNotes?.trim());
                              const hasHtml  = !!(sec.html?.trim());
                              return (
                                  <div key={sec.id || idx} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden mt-3">
                                      {sec.title && (
                                          <div className="px-4 pt-4 pb-1">
                                              <h3 className="text-sm font-black text-slate-700 flex items-center gap-2">
                                                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 text-[10px] font-black flex items-center justify-center">{idx + 1}</span>
                                                  {sec.title}
                                              </h3>
                                              <div className="h-px bg-slate-100 mt-2" />
                                          </div>
                                      )}
                                      {/* Read mode plain text — tier filter apply karo taaki locked content nahi dikhega */}
                                      {hasChunk && (() => {
                                          // Agar class notes hain aur tier restriction hai toh sec.html se filtered text derive karo
                                          let readableText = sec.chunkNotes || '';
                                          if (classLevel !== 'COMPETITION' && hasHtml && _notesTier !== 'ULTRA') {
                                              const filteredSecHtml = filterHtmlByTier(injectSectionTierTags(sec.html), _notesTier);
                                              readableText = filteredSecHtml
                                                  .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
                                                  .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
                                                  .replace(/<[^>]*>/g, ' ')
                                                  .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
                                                  .replace(/\s+/g, ' ').trim();
                                          }
                                          if (!readableText) return null;
                                          return (
                                              <div className="notes-html-content p-4 sm:p-6 border-b border-slate-100 text-slate-700" style={{ fontSize: '15px', lineHeight: '1.8' }}
                                                  dangerouslySetInnerHTML={{ __html: renderMathInHtml(readableText) }}
                                              />
                                          );
                                      })()}
                                      {/* Write mode HTML */}
                                      {hasHtml && (
                                          <div
                                              className="notes-html-content p-4 sm:p-6"
                                              dangerouslySetInnerHTML={{ __html: renderMathInHtml(classLevel !== 'COMPETITION' ? injectSectionTierTags(sec.html || '') : (sec.html || '')) }}
                                              style={{ fontSize: '15px', lineHeight: '1.8' }}
                                              {...(classLevel !== 'COMPETITION' ? { 'data-user-tier': getEffectiveNotesTier(user ?? null, isFirstChapter) } : {})}
                                          />
                                      )}
                                  </div>
                              );
                          });
                      })()}
                      </div>
                      </>
                  )}
                  {isStreaming && (
                      <div className="flex items-center gap-2 text-slate-600 mt-4 animate-pulse pb-4">
                          <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                          <span className="text-xs font-bold">AI writing...</span>
                      </div>
                  )}
              </>
          );

          return (
              <div className="fixed inset-0 z-50 bg-white flex flex-col">
                  {/* Rotate toast */}
                  {rotateToast && (
                      <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-lg animate-in fade-in">
                          {rotateToast}
                      </div>
                  )}
                  {/* Header — write mode bar */}
                  <header className={`px-3 pt-2 pb-2 flex-shrink-0 z-10 shadow-md${isImmersive || schoolMode ? ' hidden' : ''}`} style={{ background: appTheme.topBarGrad }}>
                      <div className="flex items-center gap-2">
                          <button onClick={handleBack} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"><ArrowLeft size={18} /></button>
                          <div className="min-w-0 flex-1">
                              <h2 className="text-[13px] font-black text-white truncate leading-tight">{content.title}</h2>
                              <p className="text-[10px] font-bold text-amber-300 uppercase tracking-wide truncate">{notesViewMode === 'styled' ? '✨ Premium Notes' : '📖 Reading Mode'}</p>
                          </div>
                          {/* Live score chip — both reading & writing modes */}
                          <div className="relative shrink-0" style={{ zIndex: 50 }}>
                              <span
                                  onClick={() => { setWritingScoreTooltip(true); setTimeout(() => setWritingScoreTooltip(false), 2500); }}
                                  style={{ fontSize: '10px', fontWeight: 900, color: notesViewMode === 'styled' ? '#10b981' : '#6366f1', background: notesViewMode === 'styled' ? 'rgba(16,185,129,0.12)' : 'rgba(99,102,241,0.12)', border: `1px solid ${notesViewMode === 'styled' ? 'rgba(16,185,129,0.3)' : 'rgba(99,102,241,0.3)'}`, borderRadius: 99, padding: '2px 8px', cursor: 'pointer', display: 'block' }}>
                                  📖 {readingLivePts}
                              </span>
                              {writingScoreTooltip && (
                                  <div style={{ position: 'absolute', top: '100%', right: 0, marginTop: 6, background: 'linear-gradient(135deg,#eef2ff,#f5f3ff)', borderTop: '2px solid #10b981', border: '1.5px solid rgba(99,102,241,0.2)', borderTopWidth: 2, borderTopColor: '#10b981', borderRadius: 12, padding: '7px 12px', whiteSpace: 'nowrap', zIndex: 100, boxShadow: '0 4px 20px rgba(16,185,129,0.15), inset 0 -1px 0 #c7d2fe', animation: 'rshud-slide 0.18s ease', display: 'flex', alignItems: 'center', gap: 8, minWidth: 260 }}>
                                      <span style={{ fontSize: 14, flexShrink: 0 }}>✍️</span>
                                      <span style={{ fontSize: 10, fontWeight: 900, color: '#059669', textTransform: 'uppercase', letterSpacing: '0.06em', flexShrink: 0 }}>Writing Score</span>
                                      <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                          <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Score</span>
                                          <span style={{ fontSize: 13, fontWeight: 900, color: '#10b981', lineHeight: 1.2 }}>+{notesViewMode === 'styled' ? (writingHtmlScoreState?.totalSessionScore ?? 0) : readingLivePts}</span>
                                      </div>
                                      <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                          <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Progress</span>
                                          <span style={{ fontSize: 13, fontWeight: 900, color: '#16a34a', lineHeight: 1.2 }}>{notesViewMode === 'styled' ? `${Math.round(writingHtmlScoreState?.progressPercent ?? 0)}%` : '--'}</span>
                                      </div>
                                      <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                          <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Next</span>
                                          <span style={{ fontSize: 11, fontWeight: 900, color: (notesViewMode === 'styled' && writingHtmlScoreState?.isPermanentlyStopped) ? '#ef4444' : '#f59e0b', lineHeight: 1.2 }}>
                                              {notesViewMode === 'styled'
                                                ? writingHtmlScoreState?.isPermanentlyStopped ? 'Scroll karo'
                                                  : writingHtmlScoreState?.isPaused ? 'Paused'
                                                  : `+10 in ${writingHtmlScoreState?.nextRewardInSec ?? 60}s`
                                                : '+5 in 30s'}
                                          </span>
                                      </div>
                                      <div style={{ flex: 1 }} />
                                      <button onClick={() => setWritingScoreTooltip(false)} style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: '50%', width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 11, fontWeight: 900, cursor: 'pointer', flexShrink: 0, padding: 0 }}>✕</button>
                                  </div>
                              )}
                          </div>
                          {/* Language pill */}
                          {!schoolMode && (
                              <button onClick={() => setLanguage(l => l === 'English' ? 'Hindi' : 'English')}
                                  className="shrink-0 px-2.5 py-1 bg-white/10 border border-white/20 rounded-lg text-[11px] font-black text-white/80 hover:bg-white/20 flex items-center gap-1 transition-all">
                                  <Globe size={11} /> {language === 'English' ? 'हि' : 'EN'}
                              </button>
                          )}
                          {/* Admin Edit button */}
                          {isAdmin && onAdminEdit && (
                              <button onClick={onAdminEdit} className="shrink-0 p-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-xl text-amber-300 border border-amber-400/30 transition-colors" title="Edit / Delete Notes (Admin)">
                                  <Pencil size={17} />
                              </button>
                          )}
                          {/* ⋮ More menu */}
                          {!schoolMode && (
                              <div className="relative shrink-0">
                                  {showMoreMenu && <div className="fixed inset-0 z-40" onClick={() => setShowMoreMenu(false)} />}
                                  <button onClick={() => setShowMoreMenu(s => !s)}
                                      className={`p-2 rounded-xl transition-colors ${showMoreMenu ? 'bg-white/25 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}>
                                      <MoreVertical size={17} />
                                  </button>
                                  {showMoreMenu && (
                                      <div className="absolute right-0 top-11 z-50 bg-white border border-slate-100 rounded-2xl shadow-2xl w-56 py-2 overflow-hidden">
                                          <button onClick={() => { writeControlsRef.current?.(); setShowMoreMenu(false); }}
                                              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                              <LayoutGrid size={15} className="text-slate-400 shrink-0" /> Controls
                                          </button>
                                          <div className="my-1.5 border-t border-slate-100" />
                                          <button onClick={() => { handleRotate(); setShowMoreMenu(false); }}
                                              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                              <RotateCcw size={15} className="text-slate-400 shrink-0" /> Screen Rotate
                                          </button>
                                          <button onClick={() => { toggleFullScreen(); setShowMoreMenu(false); }}
                                              className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                              <Maximize size={15} className="text-slate-400 shrink-0" /> Fullscreen
                                          </button>
                                          <div className="my-1.5 border-t border-slate-100" />
                                          <button onClick={() => { setShowSuggestionPanel(s => !s); setShowMoreMenu(false); }}
                                              className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition-colors ${showSuggestionPanel ? 'bg-amber-50 text-amber-700' : 'text-slate-700 hover:bg-slate-50'}`}>
                                              <Lightbulb size={15} className={`shrink-0 ${showSuggestionPanel ? 'text-amber-500' : 'text-slate-400'}`} />
                                              💡 Suggestions & Corrections
                                          </button>
                                      </div>
                                  )}
                              </div>
                          )}
                          <button onClick={handleBack} className="shrink-0 p-2 bg-white/10 hover:bg-red-500/20 hover:text-red-300 text-white/70 rounded-xl transition-colors"><X size={17} /></button>
                      </div>
                  </header>

                  {/* 💡 Suggestions & Corrections panel — write mode */}
                  {showSuggestionPanel && !schoolMode && (
                      <div className="flex-shrink-0 border-b border-amber-200 bg-amber-50">
                          <WriteModeCorrection user={user} lessonTitle={chapter.title} subject={subject.name} classLevel={classLevel} />
                      </div>
                  )}

                  {/* ── Blank Screen overlay — covers content, header stays visible ── */}
                  {showBlankScreen && (
                      <div
                          className="absolute inset-0 z-30 flex flex-col items-center justify-center select-none"
                          style={{ background: '#0f172a', top: 0 }}
                          onClick={() => setShowBlankScreen(false)}
                      >
                          <div className="flex flex-col items-center gap-4 pointer-events-none">
                              <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
                                  <EyeOff size={32} className="text-white/40" />
                              </div>
                              <p className="text-white/30 text-sm font-bold tracking-widest uppercase">Screen Hidden</p>
                              <p className="text-white/20 text-xs">Tap anywhere to show</p>
                          </div>
                      </div>
                  )}

                  {isLandscape ? (
                      /* ── LANDSCAPE: Split screen — controls left, notes right ── */
                      <div className="flex-1 flex flex-row overflow-hidden bg-slate-50">
                          {/* Left panel: mode switcher controls */}
                          <div className={`w-[220px] flex-shrink-0 bg-white border-r border-slate-100 flex flex-col p-4 gap-3 overflow-y-auto${isImmersive ? ' hidden' : ''}`}>
                              {/* Language toggle */}
                              {!schoolMode && <div className="mt-2">
                                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Language</p>
                                  <button
                                      onClick={() => setLanguage(l => l === 'English' ? 'Hindi' : 'English')}
                                      className="w-full px-3 py-2 bg-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 border border-slate-200 flex items-center justify-center gap-1 transition-all"
                                  >
                                      <Globe size={14} /> {language === 'English' ? 'हिंदी में बदलें' : 'Switch to English'}
                                  </button>
                              </div>}
                              
                          </div>
                          {/* Right panel: notes content */}
                          <div className="flex-1 overflow-y-auto px-4 py-3 min-w-0">
                              {notesContent}
                          </div>
                      </div>
                  ) : (
                      /* ── PORTRAIT: Normal single-column layout ── */
                      <div className="flex-1 overflow-y-auto w-full pb-6 bg-slate-50">
                          <div className="w-full max-w-5xl mx-auto px-4 md:px-8">
                              {notesContent}
                          </div>
                      </div>
                  )}
              {/* Next Chapter bar — shown at bottom when next chapter is available */}
              {onNext && (
                <div className={`flex-shrink-0 border-t border-slate-200/60 bg-white px-4 py-2.5${isImmersive ? ' hidden' : ''}`}>
                  <button
                    onClick={() => {
                      const isCreditEconomy = user?.studyMode === 'CREDIT';
                      if (user && onUpdateUser && isCreditEconomy) { setPendingNextChapter(true); }
                      else { onNext(); }
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 active:scale-[0.98] transition-all group shadow-sm"
                  >
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center shrink-0 group-hover:bg-indigo-500/30 transition-colors">
                      <BookOpen size={15} className="text-indigo-400" />
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <p className="text-[9px] font-semibold text-slate-400 uppercase tracking-[0.14em]">Agla Chapter</p>
                      {nextTitle && <p className="text-sm font-semibold text-white truncate mt-0.5">{nextTitle}</p>}
                    </div>
                    <ChevronRight size={16} className="text-slate-500 shrink-0 group-hover:text-indigo-400 transition-colors" />
                  </button>
                </div>
              )}
              {floatingBtn}
              {coinModal}
              {nextChapterModal}
              </div>
          );
      }
      
      if (isImage) {
          return (
              <div className="fixed inset-0 z-50 bg-[#111] flex flex-col" style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)', paddingLeft: 'env(safe-area-inset-left)', paddingRight: 'env(safe-area-inset-right)' }}>
                  <header className={`bg-black/90 backdrop-blur-md text-white p-4 absolute top-0 left-0 right-0 z-10 flex items-center justify-between border-b border-white/10${isImmersive ? ' hidden' : ''}`} style={{ top: 'env(safe-area-inset-top)' }}>
                      <div className="flex items-center gap-3"><button onClick={toggleFullScreen} className="p-2 bg-slate-100 rounded-full text-slate-600 hover:bg-slate-200" title="Toggle Fullscreen"><Maximize size={20} /></button>
                          <button onClick={handleBack} className="p-2 bg-white/10 rounded-full"><ArrowLeft size={20} /></button>
                          <div>
                              <h2 className="text-sm font-bold text-white/90">{content.title}</h2>
                              <p className="text-[10px] text-teal-400 font-bold uppercase tracking-widest">Image Notes</p>
                          </div>
                      </div>
                      <button onClick={handleBack} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors backdrop-blur-md"><X size={20} /></button>
                  </header>
                  <div className="flex-1 min-h-0 overflow-auto pt-16 flex items-center justify-center" onContextMenu={preventMenu}>
                      <img
                          src={content.content}
                          alt="Notes"
                          className="max-w-full max-h-full object-contain"
                          style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                          draggable={false}
                      />
                  </div>
              {floatingBtn}
              </div>
          );
      }
  }

  // 2. URL LINK / PDF NOTES (Strict HTTP check)
  const isUrl = contentValue && (contentValue.startsWith('http://') || contentValue.startsWith('https://'));
  if (['PDF_FREE', 'PDF_PREMIUM', 'PDF_ULTRA', 'PDF_VIEWER'].includes(content.type) || isUrl) {
      const isGoogleDriveAudio = (contentValue.includes('drive.google.com') || contentValue.includes('notebooklm.google.com')) && (content.title.toLowerCase().includes('audio') || content.title.toLowerCase().includes('podcast') || content.type.includes('AUDIO'));

      if (isGoogleDriveAudio) {
          return (
              <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col p-4 items-center justify-center">
                  <div className="w-full max-w-xl">
                      <ModernAudioPlayer
                          audioUrl={contentValue}
                          title={content.title}
                          subtitle={chapter?.name || subject?.name}
                          mediaId={`lesson_aud_${content?.id || content?.title}`}
                          appLogo={settings?.appLogo}
                          appName={settings?.appShortName || 'NSTA'}
                          user={user}
                          isAdmin={isAdmin}
                          onBack={handleBack}
                      />
                  </div>
                  {floatingBtn}
              </div>
          );
      }

      const isVideo = isUrl && (
          content.type === 'VIDEO' ||
          contentValue.includes('youtube.com') ||
          contentValue.includes('youtu.be') ||
          contentValue.endsWith('.mp4') ||
          contentValue.includes('cloudinary.com')
      );

      if (isVideo) {
          return (
              <div className="fixed inset-0 z-50 bg-black flex flex-col">
                  {/* ── Modern Video Player with Watermark, Quality Selector & In-App Offline Download ── */}
                  <div className="flex-1 relative flex flex-col justify-center bg-black" onClick={e => e.stopPropagation()}>
                    <ModernVideoPlayer
                      videoUrl={contentValue}
                      title={content.title}
                      mediaId={`lesson_vid_${content?.id || content?.title}`}
                      subject={chapter?.name || subject?.name}
                      appLogo={settings?.appLogo}
                      appName={settings?.appShortName || 'NSTA'}
                      user={user}
                      isAdmin={isAdmin}
                      onBack={handleBack}
                      onNext={onNext}
                      nextTitle={nextTitle}
                    />
                  </div>

                  {/* ── Media score HUD ── */}
                  {mediaScoreState && (
                      <ReadingScoreHUD
                          state={mediaScoreState}
                          visible={true}
                          levelColor="#818cf8"
                      />
                  )}
                  {floatingBtn}
              </div>
          );
      }

      return (
          <PdfViewer
              url={contentValue}
              title={content.title}
              onBack={onBack}
              sessionKey={chapter?.id ? `chapter_${chapter.id}` : undefined}
              userId={user?.id}
              userLevel={getLevelFromScore(user?.totalScore || 0)}
              subscriptionLevel={user?.subscriptionTier || 'FREE'}
              isPremium={!!(user?.isPremium || (user?.subscriptionTier && user.subscriptionTier !== 'FREE'))}
              boostPercent={getActiveBoost(user as any)}
              onScoreEarned={handleReadingScoreEarned}
              onCreditsEarned={handleCreditsEarned}
              onNext={onNext}
              nextTitle={nextTitle}
              onSchoolModeSwitch={schoolMode && onSchoolModeSwitch ? onSchoolModeSwitch : undefined}
              isAdmin={user?.role === 'ADMIN' || user?.role === 'SUB_ADMIN'}
              onAdminBoard={onAdminBoard}
          />
      );
  }

  // 3. MANUAL TEXT / MARKDOWN NOTES (Fallback)
  if (content.content || isStreaming) {
      return (
          <div className="flex flex-col h-full bg-white">
              {rotateToast && (
                  <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-lg animate-in fade-in">
                      {rotateToast}
                  </div>
              )}
              {/* Header — write mode bar */}
              <header className={`px-3 pt-2 pb-2 sticky top-0 z-10 shadow-md${isImmersive || schoolMode ? ' hidden' : ''}`} style={{ background: appTheme.topBarGrad }}>
                  <div className="flex items-center gap-2">
                      <button onClick={handleBack} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"><ArrowLeft size={18} /></button>
                      <div className="min-w-0 flex-1">
                          <h2 className="text-[13px] font-black text-white truncate leading-tight">{content.title}</h2>
                          <p className="text-[10px] font-bold text-amber-300 uppercase tracking-wide">📖 Notes</p>
                      </div>
                      {/* School mode controls */}
                      {schoolMode && onSchoolModeSwitch && (
                          <button onClick={onSchoolModeSwitch} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"><LayoutGrid size={17} /></button>
                      )}
                      {schoolMode && (
                          <button onClick={() => schoolControlsRef?.current?.()} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"><MoreVertical size={17} /></button>
                      )}
                      {/* Language pill */}
                      {!schoolMode && (
                          <button onClick={() => setLanguage(l => l === 'English' ? 'Hindi' : 'English')}
                              className="shrink-0 px-2.5 py-1 bg-white/10 border border-white/20 rounded-lg text-[11px] font-black text-white/80 hover:bg-white/20 flex items-center gap-1 transition-all">
                              <Globe size={11} /> {language === 'English' ? 'हि' : 'EN'}
                          </button>
                      )}
                      {/* Admin Edit button */}
                      {isAdmin && onAdminEdit && (
                          <button onClick={onAdminEdit} className="shrink-0 p-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-xl text-amber-300 border border-amber-400/30 transition-colors" title="Edit / Delete Notes (Admin)">
                              <Pencil size={17} />
                          </button>
                      )}
                      {/* ⋮ More menu */}
                      {!schoolMode && (
                          <div className="relative shrink-0">
                              {showMoreMenu && <div className="fixed inset-0 z-40" onClick={() => setShowMoreMenu(false)} />}
                              <button onClick={() => setShowMoreMenu(s => !s)}
                                  className={`p-2 rounded-xl transition-colors ${showMoreMenu ? 'bg-white/25 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}>
                                  <MoreVertical size={17} />
                              </button>
                              {showMoreMenu && (
                                  <div className="absolute right-0 top-11 z-50 bg-white border border-slate-100 rounded-2xl shadow-2xl w-56 py-2 overflow-hidden">
                                      <button onClick={() => { writeControlsRef.current?.(); setShowMoreMenu(false); }}
                                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                          <LayoutGrid size={15} className="text-slate-400 shrink-0" /> Controls
                                      </button>
                                      <div className="my-1.5 border-t border-slate-100" />
                                      <button onClick={() => { handleRotate(); setShowMoreMenu(false); }}
                                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                          <RotateCcw size={15} className="text-slate-400 shrink-0" /> Screen Rotate
                                      </button>
                                      <button onClick={() => { toggleFullScreen(); setShowMoreMenu(false); }}
                                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                          <Maximize size={15} className="text-slate-400 shrink-0" /> Fullscreen
                                      </button>
                                      <div className="my-1.5 border-t border-slate-100" />
                                      <button onClick={() => { setShowSuggestionPanel(s => !s); setShowMoreMenu(false); }}
                                          className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition-colors ${showSuggestionPanel ? 'bg-amber-50 text-amber-700' : 'text-slate-700 hover:bg-slate-50'}`}>
                                          <Lightbulb size={15} className={`shrink-0 ${showSuggestionPanel ? 'text-amber-500' : 'text-slate-400'}`} />
                                          💡 Suggestions & Corrections
                                      </button>
                                  </div>
                              )}
                          </div>
                      )}
                      <button onClick={handleBack} className="shrink-0 p-2 bg-white/10 hover:bg-red-500/20 hover:text-red-300 text-white/70 rounded-xl transition-colors"><X size={17} /></button>
                  </div>
              </header>
              <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-white">
                  <div className="w-full max-w-5xl mx-auto">
                      <ChunkedNotesReader
                          content={content.content || ''}
                          language={language === 'Hindi' ? 'hi-IN' : 'en-US'}
                          noteKey={noteKey}
                          isStarred={isTopicStarred}
                          onStarToggle={toggleTopicStar}
                          preferChunkMode
                          hideTopBar={schoolMode ? isImmersive : true}
                          hideFix={schoolMode}
                          hideDesktopToggle={true}
                          suppressStickyControls={schoolMode}
                          triggerControlsRef={schoolMode ? schoolControlsRef : writeControlsRef}
                          onMoreOptions={schoolMode && onSchoolModeSwitch ? onSchoolModeSwitch : undefined}
                          onDesktopModeChange={setIsDesktopMode}
                          readingScoreConfig={writingScoreConfig}
                          isAdmin={isAdmin}
                          useImportantMark2={false}
                          isMarked2={isTopicMark2}
                          onMark2Toggle={undefined}
                          onSaveOffline={schoolSaveOffline ?? (user ? handleSaveNotesOffline : undefined)}
                          isSavedOffline={savedOffline}
                          onAdminEdit={isAdmin ? onAdminEdit : undefined}
                          onBack={schoolMode ? onBack : undefined}
                      />
                      {isStreaming && (
                        <div className="flex items-center gap-2 text-slate-600 mt-4 animate-pulse">
                            <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                            <span className="text-xs font-bold">AI writing...</span>
                        </div>
                      )}
                  </div>
              </div>
          {floatingBtn}
          </div>
      );
  }

  if (content.isComingSoon) {
      return (
          <div className="min-h-[70vh] flex flex-col items-center justify-center text-center p-6 bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 rounded-2xl m-4 border-2 border-dashed border-orange-200">
              <div className="relative mb-4">
                <div className="absolute inset-0 bg-orange-300/30 blur-2xl rounded-full" />
                <Clock size={72} className="relative text-orange-500 opacity-90" />
              </div>
              <h2 className="text-2xl font-black text-slate-800 mb-2">Coming Soon</h2>
              <p className="text-slate-600 max-w-xs mx-auto mb-4 text-sm">
                  Yeh content abhi Admin ke dwara taiyar ki ja rahi hai. Jaldi hi available hogi.
              </p>
              {/* Diagnostic chip — helps the user tell admin EXACTLY what's missing */}
              <div className="bg-white/80 backdrop-blur border border-orange-200 rounded-xl px-3 py-2 mb-4 text-[11px] text-slate-700 font-semibold shadow-sm">
                <div className="text-[9px] font-black text-orange-600 uppercase tracking-widest mb-1">Missing Content</div>
                <div>📖 <b>{chapter?.title || content.title}</b></div>
                {content.subjectName && <div className="text-slate-500 mt-0.5">📚 {content.subjectName}</div>}
              </div>
              <button onClick={handleBack} className="px-6 py-2.5 rounded-xl bg-slate-700 text-white font-bold text-sm hover:bg-slate-800 active:scale-95 transition shadow-md">
                  Go Back
              </button>
          </div>
      );
  }

  // --- MCQ RENDERER ---
  if ((content.type === 'MCQ_ANALYSIS' || content.type === 'MCQ_SIMPLE' || content.type === 'MCQ_RESULT') && content.mcqData) {
      // --- INITIALIZATION & RESUME LOGIC ---
      useEffect(() => {
          if (!content.mcqData) return;
          
          const sourceData = (language === 'Hindi' && content.manualMcqData_HI && content.manualMcqData_HI.length > 0)
              ? content.manualMcqData_HI
              : content.mcqData;

          if (content.userAnswers) {
              setMcqState(content.userAnswers);
              setShowResults(true);
              setAnalysisUnlocked(true);
              setLocalMcqData(sourceData);
              return;
          }

          const key = `nst_mcq_progress_${chapter.id}`;
          storage.getItem(key).then(saved => {
              if (saved) {
                  setShowResumePrompt(true);
                  setLocalMcqData(sourceData);
              } else {
                  setLocalMcqData(sourceData);
              }
          });
      }, [content.mcqData, content.manualMcqData_HI, chapter.id, content.userAnswers, language]);

      // --- SAVE PROGRESS LOGIC ---
      useEffect(() => {
          if (!showResults && Object.keys(mcqState).length > 0) {
              const key = `nst_mcq_progress_${chapter.id}`;
              storage.setItem(key, {
                  mcqState,
                  batchIndex,
                  localMcqData
              });
          }
      }, [mcqState, batchIndex, chapter.id, localMcqData, showResults]);

      const handleResume = () => {
          const key = `nst_mcq_progress_${chapter.id}`;
          storage.getItem(key).then(saved => {
              if (saved) {
                  const parsed = saved;
                  setMcqState(parsed.mcqState || {});
                  setBatchIndex(parsed.batchIndex || 0);
                  if (parsed.localMcqData) setLocalMcqData(parsed.localMcqData);
              }
              setShowResumePrompt(false);
          });
      };

      const handleRestart = () => {
          const key = `nst_mcq_progress_${chapter.id}`;
          storage.removeItem(key);
          setMcqState({});
          setSkippedQuestions(new Set());
          setBatchIndex(0);
          setLocalMcqData([...(content.mcqData || [])].sort(() => Math.random() - 0.5));
          setShowResumePrompt(false);
          setAnalysisUnlocked(false);
          setShowResults(false);
          setMcqLivePts(0);
      };

      const handleRecreate = () => {
          setConfirmConfig({
              isOpen: true,
              title: "Restart Quiz?",
              message: "This will shuffle questions and reset your current progress.",
              onConfirm: () => {
                  const shuffled = [...(content.mcqData || [])].sort(() => Math.random() - 0.5);
                  setLocalMcqData(shuffled);
                  setMcqState({});
                  setSkippedQuestions(new Set());
                  setBatchIndex(0);
                  setShowResults(false);
                  setAnalysisUnlocked(false);
                  const key = `nst_mcq_progress_${chapter.id}`;
                  storage.removeItem(key);
                  setConfirmConfig(prev => ({...prev, isOpen: false}));
              }
          });
      };

      const displayData = localMcqData.length > 0 ? localMcqData : (content.mcqData || []);
      const currentBatchData = displayData.slice(batchIndex * BATCH_SIZE, (batchIndex + 1) * BATCH_SIZE);
      const hasMore = (batchIndex + 1) * BATCH_SIZE < displayData.length;

      const score = Object.keys(mcqState).reduce((acc, key) => {
          const qIdx = parseInt(key);
          return acc + (mcqState[qIdx] === displayData[qIdx].correctAnswer ? 1 : 0);
      }, 0);

      const currentCorrect = score;
      const currentWrong = Object.keys(mcqState).length - currentCorrect;
      const attemptedCount = Object.keys(mcqState).length;
       // A student may submit as soon as at least one question is answered.
       // There is intentionally no 20/30-question threshold here.
       const minRequired = 1;
       const canSubmit = attemptedCount >= minRequired;

      const currentBatchAttemptedCount = currentBatchData.reduce((acc, _, localIdx) => {
          const idx = (batchIndex * BATCH_SIZE) + localIdx;
          return acc + (mcqState[idx] !== undefined && mcqState[idx] !== null ? 1 : 0);
      }, 0);
      const canGoNext = currentBatchAttemptedCount >= 1;

      const nextQuestion = () => {
          playSoundClick();
          setBatchIndex(prev => prev + 1);
          const container = document.querySelector('.mcq-container');
          if (container) container.scrollTop = 0;
      };

      const handleOptionSelect = (qIdx: number, oIdx: number) => {
          // Answers stay editable until the final submit.
          const wasAnswered = mcqState[qIdx] !== undefined && mcqState[qIdx] !== null;
          setMcqState(prev => ({ ...prev, [qIdx]: oIdx }));
          setSkippedQuestions(prev => {
              const next = new Set(prev);
              next.delete(qIdx);
              return next;
          });
          const isCorrect = oIdx === displayData[qIdx].correctAnswer;

          if (isCorrect) {
              playSoundCorrect();
              hapticCorrect();
          } else {
              playSoundWrong();
              hapticWrong();
          }

          // ── MCQ Scoring: +2 correct, -1 wrong, streak bonuses ────────────────
          if (user?.id && !showResults && !wasAnswered) {
              const _subValid = !!(user.isPremium || (user.subscriptionTier && user.subscriptionTier !== 'FREE'));
              const _tier = user.subscriptionTier || 'FREE';
              if (isCorrect) {
                  const newStreak = mcqStreak + 1;
                  setMcqStreak(newStreak);
                  const _mcqLabel = [subject?.name, chapter?.title].filter(Boolean).join(' · ') || undefined;
                  const pts = tryEarnScore(user.id, 5, _tier, _subValid, 0, 'MCQ_CORRECT', undefined, undefined, _mcqLabel);
                  const bonus = getMcqStreakBonus(newStreak);
                  const bonusPts = bonus > 0 ? tryEarnScore(user.id, bonus, _tier, _subValid, 0, `MCQ_STREAK_${newStreak}`, undefined, undefined, _mcqLabel) : 0;
                  const totalPts = pts + bonusPts;
                  if (totalPts > 0) {
                      const _u = userRef.current;
                      if (_u && onUpdateUserRef.current) {
                          const updated = { ..._u, totalScore: (_u.totalScore || 0) + totalPts };
                          onUpdateUserRef.current(updated);
                          saveUserToLive(updated);
                      }
                      // Accumulate MCQ pts for one-time coin award at session end
                      mcqSessionPtsRef.current += totalPts;
                      setMcqLivePts(prev => prev + totalPts);
                      markModeActive('MCQ');
                      showMcqScore(totalPts);
                  }
              } else {
                  setMcqStreak(0);
                  subtractDailyScore(user.id, 2);
                  const _u = userRef.current;
                  if (_u && onUpdateUserRef.current) {
                      const updated = { ..._u, totalScore: Math.max(0, (_u.totalScore || 0) - 2) };
                      onUpdateUserRef.current(updated);
                      saveUserToLive(updated);
                  }
                  showMcqScore(-2);
              }
          }

           // This flow shows one question at a time (BATCH_SIZE is 1), so
           // choosing an option immediately opens the next question. The
           // final question remains available for the existing submit flow.
           if (!showResults && qIdx === batchIndex && batchIndex < displayData.length - 1) {
               nextQuestion();
           }
      };

      const handleSubmitRequest = () => {
          setShowSubmitModal(true);
      };

    // COMPARISON LOGIC
    useEffect(() => {
        if (showResults && user?.mcqHistory) {
            // Find previous attempts for THIS chapter
            const attempts = user.mcqHistory
                .filter(h => h.chapterId === chapter.id)
                .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

            // Current result is effectively the "latest" one we just submitted or viewing?
            // If we are viewing results in LessonView, we might not have saved it to history YET if McqView handles it.
            // But LessonView is also used for "Review".
            // Let's compare with the *latest* in history (which is the previous one if we consider the current session as new).
            // Actually, if showResults is true, the user has just finished.
            // The history might update via parent.

            if (attempts.length > 0) {
                const last = attempts[0]; // Most recent in history
                // If the current session score is available
                const currentScore = Object.keys(mcqState).reduce((acc, key) => {
                    const qIdx = parseInt(key);
                    return acc + (mcqState[qIdx] === displayData[qIdx].correctAnswer ? 1 : 0);
                }, 0);

                const currPct = Math.round((currentScore / displayData.length) * 100);
                const prevPct = Math.round((last.score / last.totalQuestions) * 100);

                const getStatus = (p: number) => p >= 80 ? 'STRONG' : p >= 50 ? 'AVERAGE' : 'WEAK';
                const prevStatus = getStatus(prevPct);
                const currStatus = getStatus(currPct);

                let msg = '';
                if (currPct >= prevPct) {
                    const improvement = currPct - prevPct;
                    msg = `Welcome ${user.name}, aapne achhi mehnat ki! Pichhli test me ${prevPct}% aapka marks tha, ish baar aapne ${currPct}% kiya. ${improvement > 0 ? `Improvement: ${improvement}%!` : 'Consistent performance!'}`;
                } else if (prevStatus === 'STRONG' && (currStatus === 'AVERAGE' || currStatus === 'WEAK')) {
                    msg = `Pichhli baar aapka ${prevPct}% aaya tha, ish baar ${currPct}%. Thoda aur mehnat kijiye aur revision kijiye. Next attempt me achha result aayega. Do hard work ${user.name}!`;
                }
                setComparisonMsg(msg);
            }
        }
    }, [showResults, user]);

    const handleConfirmSubmit = () => {
        setShowSubmitModal(false);
        playSoundVictory();
        const key = `nst_mcq_progress_${chapter.id}`;
        storage.removeItem(key);
        
        // Don't show results or unlock analysis immediately
        // This allows the MarksheetCard in McqView to handle the flow
        setShowResults(false);
        setAnalysisUnlocked(false);
        
        // CHECK WARNING (Rushed Questions)
        const rushedCount = Object.keys(timeSpentPerQuestion).filter(k => timeSpentPerQuestion[parseInt(k)] < 5).length;
        if (rushedCount > 5) {
            setAlertConfig({
                isOpen: true,
                type: 'ERROR',
                message: "Warning: It seems you finished too fast. Try to read questions carefully next time!"
            });
        }

        if (onMCQComplete) {
            onMCQComplete(score, mcqState as Record<number, number>, displayData, sessionTime, timeSpentPerQuestion);
        }

        // EXTRA SYNC FOR HISTORY (Ensuring it saves even if parent is busy)
        const historyItem = {
            id: `mcq_${chapter.id}_${Date.now()}`,
            type: 'MCQ_RESULT',
            title: `${chapter.title} - Test`,
            date: new Date().toISOString(),
            score,
            totalQuestions: displayData.length,
            timeTaken: sessionTime,
            chapterId: chapter.id,
            subjectId: subject.id,
            classLevel,
            userAnswers: mcqState,
            questions: displayData,
            omrData: Object.entries(mcqState || {}).map(([qIdx, ans]) => ({
              qIndex: Number(qIdx),
              selected: ans,
              correct: displayData[Number(qIdx)]?.correctAnswer,
            })),
        };

        if (user?.id) {
            saveUserHistory(user.id, historyItem);
            saveTestResult(user.id, historyItem);
        }

    };

    // Keep submitRef updated for Anti-Cheat
    useEffect(() => {
        submitRef.current = handleConfirmSubmit;
    }, [handleConfirmSubmit]);

    const [downloadModalOpen, setDownloadModalOpen] = useState(false);
    const [isDownloading, setIsDownloading] = useState(false);

    const handleDownloadRequest = () => {
        if (!user) return;
        setDownloadModalOpen(true);
    };

    const handleSaveOffline = () => {
        if (!user) return;

        // Save both MCQ data and any associated notes
        const payload: any = {
            questions: localMcqData
        };

        if (content?.content) payload.theory = content.content; // Markdown fallback
        if (content?.topicNotes) payload.topicNotes = content.topicNotes;

        saveOfflineItem({
            id: `lesson_mcq_${chapter.id}_${Date.now()}`,
            type: 'MCQ',
            title: chapter.title,
            subtitle: subject.name,
            data: payload
        });
        setAlertConfig({isOpen: true, message: "MCQ & Notes Saved Offline!"});
    };

    const handleConfirmDownload = async (type: 'PDF' | 'MHTML') => {
        if (!user || !onUpdateUser) return;

        let cost = 10;
        // Level gates: creditFreeEvent requires L8, globalFreeMode requires L10
        const _dlUserLevel = (() => {
          if (!user) return 1;
          const score = user.totalScore || 0;
          const levels = [0, 100, 250, 500, 1000, 2000, 3500, 5500, 8000, 11000, 15000, 20000, 26000, 33000, 41000];
          let lvl = 1;
          for (let i = levels.length - 1; i >= 0; i--) { if (score >= levels[i]) { lvl = i + 1; break; } }
          return lvl;
        })();
        if ((settings?.isCreditFreeEvent && _dlUserLevel >= 8) || (settings?.isGlobalFreeMode && _dlUserLevel >= 10)) {
            cost = 0;
        }

        if (user.credits < cost) {
            setAlertConfig({isOpen: true, message: `Insufficient Credits! Download costs ${cost} coins.`});
            return;
        }

        // Deduct
        if (cost > 0) {
            const updatedUser = applyDeduction(user, cost) ?? user;
            onUpdateUser(updatedUser);
            localStorage.setItem('nst_current_user', JSON.stringify(updatedUser));
            saveUserToLive(updatedUser);
        }

        setIsDownloading(true);
        setDownloadModalOpen(false);

        // Allow UI to update (show hidden container if needed, though it's always there but maybe hidden via CSS)
        // We use a timeout to let the UI thread breathe
        setTimeout(async () => {
            // Temporarily apply desktop mode for download so content renders at full width
            const wasDesktop = isDesktopModeOn();
            if (!wasDesktop) setDesktopMode(true);

            // Small extra delay to let viewport change settle
            await new Promise(r => setTimeout(r, 200));

            if (type === 'MHTML') {
                downloadAsMHTML('printable-analysis-report', `${chapter.title}_Analysis`);
            } else {
                const element = document.getElementById('printable-analysis-report');
                if (element) {
                    try {
                        const canvas = await html2canvas(element, { scale: 1.5, backgroundColor: '#ffffff', useCORS: true });
                        const imgData = canvas.toDataURL('image/png');

                        const pdf = new jsPDF('p', 'mm', 'a4');
                        const pdfWidth = pdf.internal.pageSize.getWidth();
                        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

                        let heightLeft = pdfHeight;
                        let position = 0;
                        const pageHeight = pdf.internal.pageSize.getHeight();

                        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
                        heightLeft -= pageHeight;

                        while (heightLeft >= 0) {
                            position = heightLeft - pdfHeight;
                            pdf.addPage();
                            pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
                            heightLeft -= pageHeight;
                        }

                        pdf.save(`${chapter.title}_Analysis.pdf`);
                    } catch (e) {
                        console.error("PDF Gen Error", e);
                        setAlertConfig({isOpen: true, message: "PDF Generation Failed."});
                    }
                }
            }

            // Restore original viewport if we changed it
            if (!wasDesktop) { setDesktopMode(false); setIsDesktopMode(false); }
            setIsDownloading(false);
            setAlertConfig({isOpen: true, message: `Download Complete! (${cost} Coins Deducted)`});
        }, 500);
    };

    const renderAnalysisDashboard = () => {
        const isPremium = content?.analysisType === 'PREMIUM';

        // Allow download even if not premium analysis? User asked for download button "analysis, revision hub dono ke pass".
        // We render it here.

        return (
            <div className="space-y-6 mb-8 animate-in slide-in-from-top-4">
                {comparisonMsg && (
                    <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl mb-4 animate-in slide-in-from-top-2">
                        <p className="text-sm text-blue-800 font-bold leading-relaxed">
                            {comparisonMsg}
                        </p>
                    </div>
                )}

                {/* TABS HEADER */}
                <div className="flex p-1 bg-slate-100 rounded-xl mb-4">
                    <button onClick={() => setActiveAnalysisTab('OVERVIEW')} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeAnalysisTab === 'OVERVIEW' ? 'bg-white shadow text-slate-800' : 'text-slate-600'}`}>Overview</button>
                    <button onClick={() => setActiveAnalysisTab('QUESTIONS')} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeAnalysisTab === 'QUESTIONS' ? 'bg-white shadow text-slate-800' : 'text-slate-600'}`}>All Questions</button>
                    <button onClick={() => setActiveAnalysisTab('MISTAKES')} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${activeAnalysisTab === 'MISTAKES' ? 'bg-white shadow text-slate-800' : 'text-slate-600'}`}>Mistakes</button>
                </div>

                <div className="flex justify-end mb-4 gap-2">
                    <button
                        onClick={handleDownloadRequest}
                        className="bg-green-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg hover:bg-green-700 flex items-center gap-2"
                    >
                        <Download size={16} /> Download Report (10 CR)
                    </button>
                    <button
                        onClick={handleSaveOffline}
                        className="bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg hover:bg-slate-900 flex items-center gap-2 border border-slate-700 transition-all"
                    >
                        <Download size={16} className="animate-bounce" /> Save Offline
                    </button>
                </div>

                {/* AI REPORT (PREMIUM ONLY) */}
                {isPremium && content?.aiAnalysisText && (
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-purple-100 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-purple-100 rounded-full blur-3xl opacity-50 -mr-10 -mt-10"></div>
                    <div className="flex items-center justify-between mb-4 relative z-10">
                        <div className="flex items-center gap-3"><button onClick={toggleFullScreen} className="p-2 bg-slate-100 rounded-full text-slate-600 hover:bg-slate-200" title="Toggle Fullscreen"><Maximize size={20} /></button>
                            <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-lg shadow-purple-200">
                                <BrainCircuit size={20} />
                            </div>
                            <div>
                                <h3 className="font-black text-slate-800 text-lg">AI Performance Report</h3>
                                <p className="text-xs text-purple-600 font-bold">Deep Insights & Strategy</p>
                            </div>
                        </div>
                        <SpeakButton text={content.aiAnalysisText} className="p-2 bg-purple-50 text-purple-600 hover:bg-purple-100" />
                    </div>
                    <div className="prose prose-sm prose-slate max-w-none w-full prose-p:text-slate-600 prose-headings:font-black prose-headings:text-slate-800 bg-slate-50 p-4 rounded-xl border border-slate-100 notes-html-content">
                        <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{content.aiAnalysisText}</ReactMarkdown>
                    </div>
                </div>
                )}
            </div>
        );
    };

    const renderRecommendedNotes = () => {
        const isPremium = content?.analysisType === 'PREMIUM';

        // Filter Notes by Chapter AND Topic (if available)
        const notes = universalNotes.filter(n => {
            const isChapterMatch = n.chapterId === chapter.id;
            // Also show if subtopic name matches
            return isChapterMatch;
        });

        // Group Notes by Topic
        const groupedNotes: Record<string, any[]> = {};
        notes.forEach(n => {
            const t = n.topic || 'General';
            if (!groupedNotes[t]) groupedNotes[t] = [];
            groupedNotes[t].push(n);
        });

        return (
            <div className={`p-6 rounded-3xl shadow-sm border relative overflow-hidden mt-8 animate-in slide-in-from-bottom-4 ${isPremium ? 'bg-white border-red-100' : 'bg-white border-orange-100'}`}>
                <div className="flex items-center gap-3 mb-4 relative z-10">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${isPremium ? 'bg-red-600 text-white shadow-red-200' : 'bg-orange-500 text-white shadow-orange-200'}`}>
                        {isPremium ? <FileText size={20} /> : <Lightbulb size={20} />}
                    </div>
                    <div>
                        <h3 className="font-black text-slate-800 text-lg">{isPremium ? 'Premium Study Notes' : 'Recommended Reading'}</h3>
                        <p className={`text-xs font-bold ${isPremium ? 'text-red-600' : 'text-orange-600'}`}>
                            {isPremium ? 'High-Yield PDFs for Weak Topics' : 'Topic-wise Revision Notes'}
                        </p>
                    </div>
                </div>

                {recLoading ? (
                    <div className="text-center py-8 text-slate-500 font-bold animate-pulse">Finding best notes...</div>
                ) : notes.length === 0 ? (
                    <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        <p className="text-slate-500 font-bold text-sm">No specific notes found for this chapter.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {Object.keys(groupedNotes).map((topic, i) => (
                            <div key={i} className="space-y-2">
                                <h4 className="text-xs font-black text-slate-600 uppercase tracking-widest pl-1">{topic}</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {groupedNotes[topic].map((note, idx) => (
                                        <div key={idx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 hover:border-blue-300 transition-colors group flex justify-between items-center">
                                            <div>
                                                <h4 className="font-bold text-slate-800 text-sm mb-1 group-hover:text-blue-700">{note.title}</h4>
                                            </div>
                                            {isPremium ? (
                                                <a href={note.url} target="_blank" rel="noopener noreferrer" className="py-1 px-3 bg-red-600 text-white rounded-lg text-[10px] font-bold hover:bg-red-700 shadow transition-all">
                                                    PDF
                                                </a>
                                            ) : (
                                                <button onClick={() => setViewingNote(note)} className="py-1 px-3 bg-orange-500 text-white rounded-lg text-[10px] font-bold hover:bg-orange-600 shadow transition-all">
                                                    Read
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        );
    };

      const handleNextPage = () => {
          setBatchIndex(prev => prev + 1);
          const container = document.querySelector('.mcq-container');
          if(container) container.scrollTop = 0;
      };

      const handlePrevPage = () => {
          if (batchIndex > 0) {
              setBatchIndex(prev => prev - 1);
              const container = document.querySelector('.mcq-container');
              if(container) container.scrollTop = 0;
          }
      };

      return (
          <div ref={containerRef} className="flex flex-col h-full bg-slate-50 relative mcq-container overflow-y-auto">
               {/* MCQ Score Popup */}
               {mcqScorePopup !== null && (
                   <div style={{
                       position: 'fixed', bottom: 80, right: 20, zIndex: 9999,
                       background: mcqScorePopup < 0 ? 'linear-gradient(135deg,#ef4444,#dc2626)' : 'linear-gradient(135deg,#6366f1,#8b5cf6)',
                       color: '#fff', borderRadius: 14, padding: '8px 16px',
                       fontSize: 14, fontWeight: 900,
                       boxShadow: mcqScorePopup < 0 ? '0 6px 20px rgba(239,68,68,0.4)' : '0 6px 20px rgba(99,102,241,0.4)',
                       opacity: mcqScoreVisible ? 1 : 0,
                       transform: mcqScoreVisible ? 'translateY(0) scale(1)' : 'translateY(8px) scale(0.95)',
                       transition: 'opacity 0.25s, transform 0.25s',
                       pointerEvents: 'none',
                   }}>
                       {mcqScorePopup < 0 ? `❌ ${mcqScorePopup} pts` : `⭐ +${mcqScorePopup} pts`}
                   </div>
               )}
               <CustomAlert 
                   isOpen={alertConfig.isOpen} 
                   message={alertConfig.message} 
                   type="ERROR"
                   onClose={() => setAlertConfig({...alertConfig, isOpen: false})} 
               />
               <CustomConfirm
                   isOpen={confirmConfig.isOpen}
                   title={confirmConfig.title}
                   message={confirmConfig.message}
                   onConfirm={confirmConfig.onConfirm}
                   onCancel={() => setConfirmConfig({...confirmConfig, isOpen: false})}
               />

               {showResumePrompt && !showResults && (
                   <div className="absolute inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
                       <div className="bg-white rounded-2xl p-6 w-full text-center shadow-2xl">
                           <h3 className="text-xl font-black text-slate-800 mb-2">Resume Session?</h3>
                           <p className="text-slate-600 text-sm mb-6">You have a saved session for this chapter.</p>
                           <div className="flex gap-3">
                               <button onClick={handleRestart} className="flex-1 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl">Restart</button>
                               <button onClick={handleResume} className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg">Resume</button>
                           </div>
                       </div>
                   </div>
               )}

               {showSuggestionPanel && (
                   <div className="sticky top-0 z-20 border-b border-amber-200 bg-amber-50">
                       <WriteModeCorrection user={user} lessonTitle={chapter.title} subject={subject.name} classLevel={classLevel} />
                   </div>
               )}

               {showSubmitModal && (
                   <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
                       <div className="bg-white rounded-2xl p-6 w-full text-center shadow-2xl animate-in zoom-in duration-200">
                           <Trophy size={48} className="mx-auto text-yellow-400 mb-4" />
                           <h3 className="text-xl font-black text-slate-800 mb-2">Submit Test?</h3>
                           <p className="text-slate-600 text-sm mb-6">
                               You have answered {Object.keys(mcqState).length} out of {displayData.length} questions.
                           </p>
                           <div className="flex gap-3">
                               <button onClick={() => setShowSubmitModal(false)} className="flex-1 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl active:scale-95 transition-all">Cancel</button>
                               <button onClick={handleConfirmSubmit} className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-200 active:scale-95 transition-all">Yes, Submit</button>
                           </div>
                       </div>
                   </div>
               )}

               {/* Topic Sidebar Overlay */}
               {showTopicSidebar && (
                   <div className="fixed inset-0 z-[60] bg-slate-900/50 backdrop-blur-sm flex justify-end" onClick={() => setShowTopicSidebar(false)}>
                        <div className="w-80 bg-white h-full shadow-2xl animate-in slide-in-from-right duration-200 flex flex-col" onClick={e => e.stopPropagation()}>
                            <div className="p-4 border-b flex items-center justify-between bg-slate-50">
                                <h3 className="font-bold text-slate-800 flex items-center gap-2"><List size={18}/> Topic Breakdown</h3>
                                <button onClick={() => setShowTopicSidebar(false)} className="p-2 hover:bg-slate-200 rounded-full"><X size={18}/></button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4">
                                {(() => {
                                    // Calculate Topic Counts
                                    const topicCounts: Record<string, {total: number, answered: number}> = {};
                                    displayData.forEach((q, idx) => {
                                        const t = q.topic || 'General';
                                        if (!topicCounts[t]) topicCounts[t] = {total: 0, answered: 0};
                                        topicCounts[t].total++;
                                        if (mcqState[idx] !== undefined) topicCounts[t].answered++;
                                    });

                                    // Identify Current Topic
                                    const currentQ = displayData[batchIndex];
                                    const currentTopic = currentQ?.topic || 'General';

                                    return (
                                        <div className="space-y-3">
                                            {Object.keys(topicCounts).map((t, i) => {
                                                const stats = topicCounts[t];
                                                const isCurrent = t === currentTopic;
                                                return (
                                                    <div key={i} className={`p-3 rounded-xl border ${isCurrent ? 'bg-blue-50 border-blue-200' : 'bg-white border-slate-100'}`}>
                                                        <div className="flex justify-between items-center mb-1">
                                                            <p className={`text-xs font-bold ${isCurrent ? 'text-blue-700' : 'text-slate-700'}`}>{t}</p>
                                                            {isCurrent && <span className="text-[9px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded font-bold">Active</span>}
                                                        </div>
                                                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                                            <div className="h-full bg-green-500 transition-all" style={{width: `${(stats.answered/stats.total)*100}%`}}></div>
                                                        </div>
                                                        <p className="text-[10px] text-slate-500 mt-1 text-right">{stats.answered} / {stats.total}</p>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    );
                                })()}
                            </div>
                        </div>
                   </div>
               )}

               {/* ── RESPONSIVE MCQ WRAPPER ── */}
               <div className="flex-1 flex overflow-hidden relative w-full">

                   {/* Question Drawer Overlay / Sidebar */}
                   {showQuestionDrawer && (
                       <div className="fixed inset-0 z-[60] bg-slate-900/50 backdrop-blur-sm flex justify-start landscape:static landscape:z-10 landscape:bg-transparent landscape:w-[320px] landscape:border-r landscape:border-slate-200 landscape:backdrop-blur-none" onClick={() => setShowQuestionDrawer(false)}>
                            <div className="w-80 landscape:w-full bg-white h-full shadow-2xl landscape:shadow-none animate-in slide-in-from-left duration-200 flex flex-col" onClick={e => e.stopPropagation()}>
                            <div className="p-4 border-b flex items-center justify-between bg-[#FDFBF7] shadow-sm rounded-t-xl border-amber-100">
                                <h3 className="font-bold text-amber-900 flex items-center gap-2 text-lg"><Grip size={20} className="text-amber-500"/> Question Palette</h3>
                                <button onClick={() => setShowQuestionDrawer(false)} className="px-3 py-1.5 flex items-center gap-1.5 bg-amber-50 text-amber-700 hover:bg-amber-100 rounded-lg font-medium transition-colors border border-amber-200 shadow-sm landscape:hidden"><X size={16}/> Back</button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-5 bg-gradient-to-b from-white to-slate-50">
                                <div className="grid grid-cols-5 gap-3">
                                    {displayData.map((_, idx) => {
                                        const isAnswered = mcqState[idx] !== undefined && mcqState[idx] !== null;
                                        const isCurrent = idx === batchIndex;

                                        let btnClass = "aspect-square rounded-xl text-sm font-bold flex items-center justify-center transition-all border shadow-sm ";
                                        if (isCurrent) {
                                            btnClass += "bg-amber-500 text-white border-amber-600 shadow-md shadow-amber-200 scale-105 ring-4 ring-amber-100";
                                        } else if (isAnswered) {
                                            btnClass += "bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100 ring-1 ring-emerald-100/50";
                                        } else if (skippedQuestions.has(idx)) {
                                            btnClass += "bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200";
                                        } else {
                                            btnClass += "bg-white text-slate-500 border-slate-200 hover:bg-slate-50 hover:border-slate-300";
                                        }

                                        return (
                                            <button
                                                key={idx}
                                                onClick={() => {
                                                    setBatchIndex(idx);
                                                    if (window.matchMedia("(orientation: portrait)").matches) {
                                                        setShowQuestionDrawer(false);
                                                    }
                                                }}
                                                className={btnClass}
                                            >
                                                {idx + 1}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                            <div className="p-4 border-t bg-[#FDFBF7] text-sm font-medium text-slate-600 flex justify-center gap-4 flex-wrap rounded-b-xl border-amber-100">
                                <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-md bg-emerald-50 border border-emerald-200 shadow-sm"></div> <span className="text-emerald-700">Answered</span></div>
                                <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-md bg-amber-100 border border-amber-300 shadow-sm"></div> <span className="text-amber-700">Skipped</span></div>
                                <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-md bg-amber-500 border border-amber-600 shadow-sm"></div> <span className="text-amber-700">Current</span></div>
                                <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-md bg-white border border-slate-200 shadow-sm"></div> <span className="text-slate-500">Unattempted</span></div>
                            </div>
                        </div>
                   </div>
               )}

               {rotateToast && (
                   <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-lg animate-in fade-in">
                       {rotateToast}
                   </div>
               )}
               {/* ── Projector Mode Overlay ── */}
               {isProjectorMode && (() => {
                   const pq = displayData[projectorQIndex] || null;
                   if (!pq) return null;
                   const total = displayData.length;
                   const optionLetters = ['A','B','C','D','E'];
                   const currentProjectorSelection = projectorSelections[projectorQIndex] ?? null;
                   const projectorAttempted = Object.keys(projectorSelections).length;
                   const projectorCorrectCount = Object.entries(projectorSelections).reduce((count, [key, value]) => (
                       count + (displayData[Number(key)]?.correctAnswer === value ? 1 : 0)
                   ), 0);
                    return createPortal(
                        <div ref={projectorContainerRef} style={{ position:'fixed', inset:0, zIndex:99999, background:'#ffffff', display:'flex', flexDirection:'column', overflow:'hidden' }}>
                           {/* Top bar — clean, matches MCQ Practice bar style */}
                           <div style={{ display:'flex', alignItems:'center', gap:8, padding:'10px 12px', borderBottom:'1px solid #f1f5f9', background:'#ffffff', flexShrink:0, boxShadow:'0 1px 4px rgba(0,0,0,0.06)' }}>
                               {/* Close */}
                               <button
                                    onClick={closeProjectorMode}
                                   style={{ flexShrink:0, padding:'8px', background:'#f8fafc', border:'none', borderRadius:12, color:'#64748b', cursor:'pointer', display:'flex', alignItems:'center' }}
                               ><X size={18} /></button>
                               {/* Title block */}
                               <div style={{ flex:1, minWidth:0 }}>
                                   <div style={{ fontSize:13, fontWeight:900, color:'#1e293b', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', lineHeight:1.2 }}>{chapter.title}</div>
                                   <div style={{ fontSize:10, fontWeight:700, color:'#d97706', textTransform:'uppercase', letterSpacing:'0.05em', lineHeight:1.2, display:'flex', alignItems:'center', gap:4 }}>
                                       <Tv size={10} /> PROJECTOR MODE
                                   </div>
                               </div>
                                {/* Screen controls — kept together so fullscreen exit is always visible */}
                                <div style={{ display:'flex', alignItems:'center', gap:6, flexShrink:0 }}>
                                    <button
                                        type="button"
                                        onClick={toggleSound}
                                        aria-label={soundActive ? 'Mute sound effects' : 'Enable sound effects'}
                                        title={soundActive ? 'Sound Effects: ON (M to mute)' : 'Sound Effects: OFF (M to unmute)'}
                                        style={{ width:34, height:34, border:`1px solid ${soundActive ? '#a7f3d0' : '#e2e8f0'}`, borderRadius:12, background:soundActive ? '#ecfdf5' : '#f8fafc', color:soundActive ? '#059669' : '#64748b', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}
                                    >
                                        {soundActive ? <Volume2 size={16} /> : <VolumeX size={16} />}
                                    </button>
                                    <button
                                        type="button"
                                        onClick={handleRotate}
                                        aria-label="Rotate screen"
                                        title="Landscape / Rotate screen"
                                        style={{ width:34, height:34, border:'1px solid #e2e8f0', borderRadius:12, background:'#f8fafc', color:'#64748b', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}
                                    >
                                        <RotateCcw size={16} />
                                    </button>
                                    <button
                                        type="button"
                                        onClick={toggleProjectorFullscreen}
                                        aria-label={isProjectorFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
                                        title={isProjectorFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
                                        style={{ width:34, height:34, border:`1px solid ${isProjectorFullscreen ? '#fca5a5' : '#e2e8f0'}`, borderRadius:12, background:isProjectorFullscreen ? '#fff1f2' : '#f8fafc', color:isProjectorFullscreen ? '#e11d48' : '#64748b', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}
                                    >
                                        {isProjectorFullscreen ? <Minimize2 size={16} /> : <Maximize size={16} />}
                                    </button>
                                </div>
                               {/* Q counter pill */}
                               <div style={{ flexShrink:0, display:'flex', alignItems:'center', gap:4, background:'#f8fafc', border:'1px solid #e2e8f0', borderRadius:12, padding:'6px 10px' }}>
                                   <span style={{ fontSize:11, fontWeight:900, color:'#1e293b' }}>{projectorQIndex + 1}</span>
                                   <span style={{ fontSize:10, color:'#94a3b8', fontWeight:700 }}>/ {total}</span>
                               </div>
                               {/* Reveal answer toggle */}
                               <button
                                   onClick={() => setProjectorReveal(r => !r)}
                                   style={{ flexShrink:0, padding:'7px 10px', background: projectorReveal ? '#dcfce7' : '#f8fafc', border: projectorReveal ? '1px solid #86efac' : '1px solid #e2e8f0', borderRadius:12, color: projectorReveal ? '#16a34a' : '#64748b', fontSize:11, fontWeight:900, cursor:'pointer', display:'flex', alignItems:'center', gap:4 }}
                               ><Eye size={13} /> {projectorReveal ? 'Hide Ans' : 'Show Ans'}</button>
                           </div>

                            {/* Shared Revision Hub-style projector question and options */}
                            <div style={{ flex:1, overflowY:'auto', padding:'40px 48px 24px', minHeight:0 }}>
                                <div style={{ maxWidth: 1400, margin: '0 auto' }}>
                                    {projectorNavigatorOpen && (
                                        <div style={{ marginBottom: 16 }}>
                                            <McqQuestionNavigator
                                                total={total}
                                                currentIndex={projectorQIndex}
                                                answers={projectorSelections}
                                                skipped={projectorSkipped}
                                                onJump={(index) => {
                                                    playSoundClick();
                                                    setProjectorQIndex(index);
                                                    setProjectorSelected(projectorSelections[index] ?? null);
                                                    setProjectorReveal(false);
                                                    setProjectorNavigatorOpen(false);
                                                }}
                                            />
                                        </div>
                                    )}
                                    <McqPracticeCard
                                        q={pq}
                                        questionNumber={pq.questionNumber ?? projectorQIndex + 1}
                                        selectedOption={currentProjectorSelection}
                                        answered={currentProjectorSelection !== null || projectorReveal}
                                        showResult={projectorShowReview || projectorReveal}
                                        disabled={projectorReveal || projectorShowReview}
                                        variant="projector"
                                        fontSize={28}
                                        onSelect={(oi) => {
                                            if (projectorReveal || projectorShowReview) return;
                                            const isCorrect = oi === pq.correctAnswer;
                                            if (isCorrect) {
                                                playSoundCorrect();
                                                hapticCorrect();
                                            } else {
                                                playSoundWrong();
                                                hapticWrong();
                                            }
                                            setProjectorSelected(oi);
                                            setProjectorSelections(prev => ({ ...prev, [projectorQIndex]: oi }));
                                            setProjectorSkipped(prev => {
                                                const next = new Set(prev);
                                                next.delete(projectorQIndex);
                                                return next;
                                            });
                                             // Keep projector mode sequential:
                                             // selecting an option opens the
                                             // next question immediately.
                                             if (projectorQIndex < total - 1) {
                                                 const nextIndex = projectorQIndex + 1;
                                                 setProjectorQIndex(nextIndex);
                                                 setProjectorSelected(projectorSelections[nextIndex] ?? null);
                                                 setProjectorReveal(false);
                                             }
                                        }}
                                         actions={(
                                             <>
                                                 <McqSpeakButtons
                                                     question={pq.question}
                                                     options={pq.options}
                                                     correctAnswer={pq.correctAnswer}
                                                     mode="all"
                                                 />
                                                 <button
                                                     type="button"
                                                     onClick={() => setProjectorNavigatorOpen(open => !open)}
                                                     aria-label="Open all projector questions"
                                                     title="All Questions"
                                                     style={{ flexShrink: 0, width: 32, height: 32, borderRadius: 999, border: 'none', background: projectorNavigatorOpen ? '#e0e7ff' : '#eef2ff', color: '#4338ca', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                                 >
                                                     <LayoutGrid size={15} />
                                                 </button>
                                             </>
                                         )}
                                    />
                                </div>

                               {/* Explanation after answering */}
                               {(projectorShowReview || projectorReveal) && currentProjectorSelection !== null && pq.explanation && (
                                   <div style={{ background:'#fefce8', border:'2px solid #fde047', borderRadius:16, padding:'20px 24px', fontSize:20, color:'#713f12', lineHeight:1.5 }}>
                                       💡 <strong>Explanation:</strong> {pq.explanation}
                                   </div>
                               )}
                               {projectorShowReview && (
                                   <div style={{ marginTop:16, background:'linear-gradient(135deg,#4f46e5,#7c3aed)', borderRadius:16, padding:'16px 20px', color:'#fff', display:'flex', alignItems:'center', justifyContent:'space-between', gap:16 }}>
                                       <div>
                                           <div style={{ fontSize:11, fontWeight:900, textTransform:'uppercase', letterSpacing:'0.08em', opacity:0.75 }}>Quiz Result</div>
                                           <div style={{ fontSize:24, fontWeight:900 }}>{projectorCorrectCount}/{projectorAttempted} correct</div>
                                       </div>
                                       <button onClick={() => setProjectorShowReview(false)} style={{ background:'rgba(255,255,255,0.18)', color:'#fff', border:'none', borderRadius:10, padding:'9px 13px', fontSize:12, fontWeight:900, cursor:'pointer' }}>Edit Answers</button>
                                   </div>
                               )}
                           </div>

                           {/* Bottom action bar */}
                           <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'16px 32px', borderTop:'3px solid #e2e8f0', background:'#f8fafc', flexShrink:0, gap:16 }}>
                               <button
                                   onClick={() => {
                                       const index = Math.max(0, projectorQIndex - 1);
                                       setProjectorQIndex(index);
                                       setProjectorReveal(false);
                                       setProjectorSelected(projectorSelections[index] ?? null);
                                   }}
                                   disabled={projectorQIndex === 0}
                                   style={{ background: projectorQIndex === 0 ? '#e2e8f0' : '#3b82f6', color: projectorQIndex === 0 ? '#94a3b8' : '#fff', border:'none', borderRadius:14, padding:'14px 32px', fontSize:20, fontWeight:900, cursor: projectorQIndex === 0 ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', gap:8 }}
                               ><ChevronLeft size={24} /> Pichla</button>

                               <button
                                   onClick={() => {
                                       if (projectorQIndex < total - 1) {
                                           setProjectorSkipped(prev => new Set([...prev, projectorQIndex]));
                                           const index = projectorQIndex + 1;
                                           setProjectorQIndex(index);
                                           setProjectorSelected(projectorSelections[index] ?? null);
                                           setProjectorReveal(false);
                                       } else if (currentProjectorSelection === null) {
                                           setProjectorSkipped(prev => new Set([...prev, projectorQIndex]));
                                       }
                                   }}
                                   disabled={projectorShowReview || (projectorQIndex === total - 1 && currentProjectorSelection !== null)}
                                   style={{ background:'#fffbeb', color:'#b45309', border:'1px solid #fcd34d', borderRadius:14, padding:'14px 18px', fontSize:16, fontWeight:900, cursor:'pointer' }}
                               >Skip</button>

                               {!projectorShowReview && projectorAttempted > 0 && (
                                   <button
                                       onClick={() => setProjectorShowReview(true)}
                                       style={{ background:'linear-gradient(135deg,#16a34a,#15803d)', color:'#fff', border:'none', borderRadius:14, padding:'14px 22px', fontSize:18, fontWeight:900, cursor:'pointer', display:'flex', alignItems:'center', gap:8 }}
                                   ><CheckCircle size={22} /> Submit ({projectorAttempted})</button>
                               )}

                               <button
                                   onClick={() => {
                                       const index = Math.min(total - 1, projectorQIndex + 1);
                                       setProjectorQIndex(index);
                                       setProjectorReveal(false);
                                       setProjectorSelected(projectorSelections[index] ?? null);
                                   }}
                                   disabled={projectorQIndex === total - 1}
                                   style={{ background: projectorQIndex === total-1 ? '#e2e8f0' : '#3b82f6', color: projectorQIndex === total-1 ? '#94a3b8' : '#fff', border:'none', borderRadius:14, padding:'14px 32px', fontSize:20, fontWeight:900, cursor: projectorQIndex === total-1 ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', gap:8 }}
                               >Agla <ChevronRight size={24} /></button>
                           </div>
                       </div>,
                       document.body
                   );
               })()}

               {/* MCQ Top Bar — Lucent style */}
               <div className={`px-3 py-2 flex items-center gap-2 sticky top-0 z-10 shadow-md${isImmersive ? ' hidden' : ''}`} style={{ background: appTheme.topBarGrad }}>
                   {/* Back */}
                   <button onClick={handleBack} className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors">
                       <ArrowLeft size={18} />
                   </button>
                   {/* Title block — flex-1, center */}
                   <div className="min-w-0 flex-1">
                       <h2 className="text-[13px] font-black text-white truncate leading-tight">{chapter.title}</h2>
                       <p className="text-[10px] font-bold text-amber-300 truncate leading-tight uppercase tracking-wide">
                           📝 MCQ {subject?.name ? `· ${subject.name}` : ''}
                       </p>
                   </div>
                   {/* Live MCQ session score chip */}
                   {!showResults && (
                       <div className="relative shrink-0" style={{ zIndex: 50 }}>
                           <span
                               onClick={() => { setMcqScoreTooltip(true); setTimeout(() => setMcqScoreTooltip(false), 2500); }}
                               style={{ fontSize: '10px', fontWeight: 900, color: '#818cf8', background: 'rgba(129,140,248,0.12)', border: '1px solid rgba(129,140,248,0.3)', borderRadius: 99, padding: '2px 8px', letterSpacing: '0.02em', cursor: 'pointer', display: 'block' }}>
                               📖 {mcqLivePts}
                           </span>
                           {mcqScoreTooltip && (
                               <div style={{ position: 'absolute', top: '100%', right: 0, marginTop: 6, background: 'linear-gradient(135deg,#eef2ff,#f5f3ff)', border: '1.5px solid rgba(99,102,241,0.2)', borderTop: '2px solid #8b5cf6', borderRadius: 12, padding: '7px 12px', whiteSpace: 'nowrap', zIndex: 100, boxShadow: '0 4px 20px rgba(139,92,246,0.15), inset 0 -1px 0 #c7d2fe', animation: 'rshud-slide 0.18s ease', display: 'flex', alignItems: 'center', gap: 8, minWidth: 260 }}>
                                   <span style={{ fontSize: 14, flexShrink: 0 }}>📝</span>
                                   <span style={{ fontSize: 10, fontWeight: 900, color: '#7c3aed', textTransform: 'uppercase', letterSpacing: '0.06em', flexShrink: 0 }}>MCQ Score</span>
                                   <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                   <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                       <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Score</span>
                                       <span style={{ fontSize: 13, fontWeight: 900, color: '#8b5cf6', lineHeight: 1.2 }}>+{mcqLivePts}</span>
                                   </div>
                                   <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                   <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                       <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Progress</span>
                                       <span style={{ fontSize: 13, fontWeight: 900, color: '#16a34a', lineHeight: 1.2 }}>--</span>
                                   </div>
                                   <div style={{ width: 1, height: 14, background: '#e2e8f0', flexShrink: 0 }} />
                                   <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                       <span style={{ fontSize: 7, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Next</span>
                                       <span style={{ fontSize: 11, fontWeight: 900, color: '#f59e0b', lineHeight: 1.2 }}>Sahi jawab pe!</span>
                                   </div>
                                   <div style={{ flex: 1 }} />
                                   <button onClick={() => setMcqScoreTooltip(false)} style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: '50%', width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 11, fontWeight: 900, cursor: 'pointer', flexShrink: 0, padding: 0 }}>✕</button>
                               </div>
                           )}
                       </div>
                   )}
                   {/* Compact timer pill */}
                   <div className="shrink-0 flex items-center gap-1.5 bg-white/10 border border-white/20 rounded-xl px-2.5 py-1.5">
                       <div className="flex flex-col items-center">
                           <span className="text-[8px] font-bold text-white/50 uppercase leading-none">Total</span>
                           <span className="text-[11px] font-mono font-black text-white leading-none">
                               {Math.floor(sessionTime / 60)}:{String(sessionTime % 60).padStart(2, '0')}
                           </span>
                       </div>
                       <div className="w-px h-5 bg-white/20" />
                       <div className="flex flex-col items-center">
                           <span className="text-[8px] font-bold text-white/50 uppercase leading-none">Q</span>
                           <span className={`text-[11px] font-mono font-black leading-none ${(timeSpentPerQuestion[batchIndex] || 0) > 60 ? 'text-red-400' : 'text-white'}`}>
                               {Math.floor((timeSpentPerQuestion[batchIndex] || 0) / 60)}:{String((timeSpentPerQuestion[batchIndex] || 0) % 60).padStart(2, '0')}
                           </span>
                       </div>
                   </div>
                   {/* Sound toggle button */}
                   <button
                       type="button"
                       onClick={toggleSound}
                       className={`shrink-0 p-2 rounded-xl border transition-colors active:scale-90 ${soundActive ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border-emerald-400/30' : 'bg-white/10 hover:bg-white/20 text-white/50 border-white/20'}`}
                       title={soundActive ? 'Sound Effects: ON (Click to Mute)' : 'Sound Effects: OFF (Click to Unmute)'}
                       aria-label={soundActive ? 'Mute sound effects' : 'Enable sound effects'}
                   >
                       {soundActive ? <Volume2 size={17} /> : <VolumeX size={17} />}
                   </button>
                   {/* Projector Mode button — admin/subadmin only */}
                   {isAdmin && (
                   <button onClick={() => { setProjectorQIndex(0); setProjectorReveal(false); setProjectorSelected(null); setProjectorSelections({}); setProjectorSkipped(new Set()); setProjectorNavigatorOpen(false); setProjectorShowReview(false); setIsProjectorMode(true); }}
                       className="shrink-0 p-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-xl text-amber-300 border border-amber-400/30 transition-colors" title="Projector Mode">
                       <Tv size={17} />
                   </button>
                   )}
                   {/* Rotate button — real screen rotation */}
                   <button onClick={handleRotate}
                       className="shrink-0 p-2 bg-white/10 hover:bg-white/20 rounded-xl text-white border border-white/20 transition-colors active:scale-90" title="Screen Rotate">
                       <RotateCcw size={17} />
                   </button>
                    {/* Fullscreen toggle stays beside rotate so the exit control is always reachable */}
                    <button onClick={toggleFullScreen}
                        className={`shrink-0 p-2 rounded-xl text-white border transition-colors active:scale-90 ${isFullscreen ? 'bg-rose-500/80 hover:bg-rose-500 border-rose-300/50' : 'bg-white/10 hover:bg-white/20 border-white/20'}`}
                        title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                        aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}>
                        {isFullscreen ? <Minimize2 size={17} /> : <Maximize size={17} />}
                    </button>
                   {/* Admin Edit button — only for admin/subadmin */}
                   {isAdmin && onAdminEdit && (
                       <button onClick={onAdminEdit} className="shrink-0 p-2 bg-amber-500/20 hover:bg-amber-500/30 rounded-xl text-amber-300 border border-amber-400/30 transition-colors" title="Edit / Delete MCQ (Admin)">
                           <Pencil size={17} />
                       </button>
                   )}
                   {/* ⋮ More menu */}
                   <div className="relative shrink-0">
                       {showMoreMenu && <div className="fixed inset-0 z-40" onClick={() => setShowMoreMenu(false)} />}
                       <button onClick={() => setShowMoreMenu(s => !s)}
                           className={`p-2 rounded-xl transition-colors ${showMoreMenu ? 'bg-white/25 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}>
                           <MoreVertical size={17} />
                       </button>
                       {showMoreMenu && (
                           <div className="absolute right-0 top-11 z-50 bg-white border border-slate-100 rounded-2xl shadow-2xl w-60 py-2 overflow-hidden">
                               {/* Language toggle */}
                               {!schoolMode && (content.manualMcqData_HI && content.manualMcqData_HI.length > 0) && (
                                   <button onClick={() => { setLanguage(l => l === 'English' ? 'Hindi' : 'English'); setShowMoreMenu(false); }}
                                       className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                       <Globe size={15} className="text-slate-400 shrink-0" />
                                       {language === 'English' ? 'Hindi (हिंदी) में' : 'English में'} Switch
                                   </button>
                               )}
                               <button onClick={() => { setShowTopicSidebar(true); setShowMoreMenu(false); }}
                                   className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                   <List size={15} className="text-slate-400 shrink-0" /> Topic Progress
                               </button>
                               <button onClick={() => { const newState = !autoReadEnabled; setAutoReadEnabled(newState); if (onToggleAutoTts) onToggleAutoTts(newState); if (!newState) window.speechSynthesis.cancel(); setShowMoreMenu(false); }}
                                   className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition-colors hover:bg-slate-50 ${autoReadEnabled ? 'text-indigo-600' : 'text-slate-700'}`}>
                                   <Volume2 size={15} className={`shrink-0 ${autoReadEnabled ? 'text-indigo-500' : 'text-slate-400'}`} />
                                   Auto-Read {autoReadEnabled ? '(ON)' : ''}
                               </button>
                               <button onClick={() => { toggleSound(); setShowMoreMenu(false); }}
                                   className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition-colors hover:bg-slate-50 ${soundActive ? 'text-emerald-600' : 'text-slate-700'}`}>
                                   {soundActive ? <Volume2 size={15} className="text-emerald-500 shrink-0" /> : <VolumeX size={15} className="text-slate-400 shrink-0" />}
                                   Sound Effects {soundActive ? '(ON)' : '(OFF)'}
                               </button>
                               <button onClick={() => { handleRotate(); setShowMoreMenu(false); }}
                                   className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                   <RotateCcw size={15} className="text-slate-400 shrink-0" /> Screen Rotate
                               </button>
                               
                               <button onClick={() => { toggleFullScreen(); setShowMoreMenu(false); }}
                                   className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-semibold transition-colors">
                                   <Maximize size={15} className="text-slate-400 shrink-0" /> Fullscreen
                               </button>
                               {isAdmin && (
                               <button onClick={() => { setProjectorQIndex(0); setProjectorReveal(false); setProjectorSelections({}); setProjectorSkipped(new Set()); setProjectorNavigatorOpen(false); setProjectorShowReview(false); setIsProjectorMode(true); setShowMoreMenu(false); }}
                                   className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-amber-700 hover:bg-amber-50 font-semibold transition-colors">
                                   <Tv size={15} className="text-amber-500 shrink-0" /> 📽️ Projector Mode
                               </button>
                               )}
                               {schoolMode && onSchoolModeSwitch && (
                                   <button onClick={() => { onSchoolModeSwitch(); setShowMoreMenu(false); }}
                                       className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-indigo-600 hover:bg-indigo-50 font-semibold transition-colors">
                                       <LayoutGrid size={15} className="text-indigo-400 shrink-0" /> Switch Mode
                                   </button>
                               )}
                               <div className="my-1.5 border-t border-slate-100" />
                               <button onClick={() => { setShowSuggestionPanel(s => !s); setShowMoreMenu(false); }}
                                   className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold transition-colors ${showSuggestionPanel ? 'bg-amber-50 text-amber-700' : 'text-slate-700 hover:bg-slate-50'}`}>
                                   <Lightbulb size={15} className={`shrink-0 ${showSuggestionPanel ? 'text-amber-500' : 'text-slate-400'}`} />
                                   💡 Suggestions & Corrections
                               </button>
                           </div>
                       )}
                   </div>
               </div>
               
               <div className={`flex-1 overflow-y-auto p-4 space-y-6 mx-auto pb-4 mcq-container ${showQuestionDrawer ? 'landscape:w-[calc(100%-320px)]' : 'w-full'}`}>
                   {/* 1. TOPIC HEADER (ANALYSIS ONLY) */}
                   {showResults && content.type === 'MCQ_ANALYSIS' && (
                       <div className="mb-4">
                           <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
                               <Zap size={24} className="text-orange-500" />
                               {content.topic ? `${content.topic} Analysis` : 'Chapter Analysis'}
                           </h2>
                           <p className="text-sm text-slate-600 font-medium ml-8">Review your performance and study recommended notes.</p>
                       </div>
                   )}

                   {/* 2. AI REPORT (Top) */}
                   {showResults && (content.type === 'MCQ_ANALYSIS' || content.type === 'MCQ_RESULT') && renderAnalysisDashboard()}

                   {/* 3. QUESTIONS LIST (Grouped by Topic if Analysis Mode) */}
                   {(() => {
                       // Premium Analysis Mode with Topic Grouping
                       if (showResults && (content.type === 'MCQ_ANALYSIS' || content.type === 'MCQ_RESULT')) {

                           // CHAPTER ANALYSIS TAB (FULL PAGE VIEW)
                           if (activeAnalysisTab === 'CHAPTER_ANALYSIS') {
                               const attempted = Object.keys(mcqState).length;
                               const correct = displayData.reduce((acc, q, i) => acc + (mcqState[i] === q.correctAnswer ? 1 : 0), 0);
                               const wrong = attempted - correct;
                               const percent = displayData.length > 0 ? Math.round((correct / displayData.length) * 100) : 0;

                               // Topic Stats
                               const topicStats: Record<string, {total: number, correct: number}> = {};
                               displayData.forEach((q, idx) => {
                                   const t = q.topic || 'General';
                                   if (!topicStats[t]) topicStats[t] = {total: 0, correct: 0};
                                   topicStats[t].total++;
                                   if (mcqState[idx] === q.correctAnswer) topicStats[t].correct++;
                               });

                               // Recent Progress (Last 3 Attempts)
                               const pastAttempts = user?.mcqHistory
                                  ?.filter(h => h.chapterId === chapter.id)
                                  .sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                                  .slice(-3) || [];

                               // Mistake Patterns (Weak Topics < 50%)
                               const weakTopics = Object.keys(topicStats)
                                  .filter(t => (topicStats[t].correct / topicStats[t].total) < 0.5)
                                  .map(t => ({ topic: t, score: topicStats[t].correct, total: topicStats[t].total }));

                               // TEACHER INSIGHT (Human Language - Expanded for All Topics)
                               const getTeacherFeedback = () => {
                                   let msg = "";
                                   let overallComparison = "";

                                   // 1. Overall Trend (Comparing with previous attempt if exists)
                                   if (pastAttempts.length > 0) {
                                       const last = pastAttempts[pastAttempts.length - 1]; // Previous attempt
                                       const prevScore = Math.round((last.score / last.totalQuestions) * 100);
                                       const currScore = percent;
                                       const diff = currScore - prevScore;

                                       if (diff > 10) overallComparison = `### 🌟 Outstanding Progress!\nExcellent improvement! Last time **${prevScore}%**, this time **${currScore}%**.`;
                                       else if (diff > 0) overallComparison = `### 👍 Good Improvement\nYou're on the right track! Score went from ${prevScore}% to ${currScore}%.`;
                                       else if (diff < -10) overallComparison = `### 📉 Needs Attention\nScore dropped significantly (${prevScore}% -> ${currScore}%). What was difficult?`;
                                       else if (diff < 0) overallComparison = `### ⚠️ Slight Drop\nPay a bit more attention. Last time ${prevScore}%, this time ${currScore}%. Consistency matters.`;
                                       else overallComparison = `### ⚖️ Consistent Performance\nGreat consistency (**${currScore}%**), but let's aim even higher now.`;
                                   } else {
                                       overallComparison = `### 👋 Welcome!\nThis is your first attempt! Let's see where there's room to improve.`;
                                   }

                                   msg += overallComparison + "\n\n";

                                   // 2. Comprehensive Topic Analysis
                                   const allTopics = Object.keys(topicStats);
                                   if (allTopics.length > 0) {
                                       msg += `#### 🧠 Topic-wise Feedback:\n`;

                                       allTopics.forEach(topic => {
                                           const stats = topicStats[topic];
                                           const accuracy = (stats.correct / stats.total) * 100;

                                           if (accuracy >= 80) {
                                               msg += `- ✅ **${topic}**: Well done! Strong grasp here (${Math.round(accuracy)}%).\n`;
                                           } else if (accuracy >= 50) {
                                               msg += `- ⚖️ **${topic}**: Decent (${Math.round(accuracy)}%), but needs a bit more revision.\n`;
                                           } else {
                                               msg += `- ❌ **${topic}**: Needs work (${Math.round(accuracy)}%). Review this topic again.\n`;
                                           }
                                       });
                                   }

                                   return msg;
                               };

                               const teacherMsg = getTeacherFeedback();

                               return (
                                   <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">

                                       {/* TEACHER INSIGHT CARD */}
                                       {teacherMsg && (
                                           <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-100 p-5 rounded-2xl flex gap-4 items-start relative overflow-hidden shadow-sm">
                                               {/* Decorative Elements */}
                                               <div className="absolute -right-4 -top-4 w-20 h-20 bg-indigo-100 rounded-full blur-2xl opacity-50"></div>

                                               <div className="w-12 h-12 rounded-full bg-white border-2 border-indigo-200 flex items-center justify-center shrink-0 shadow-sm z-10">
                                                   {/* Use an emoji or icon for the teacher avatar */}
                                                   <span className="text-2xl">👨‍🏫</span>
                                               </div>
                                               <div className="z-10 flex-1">
                                                   <h4 className="font-black text-indigo-900 text-sm mb-1 uppercase tracking-wide">Teacher's Remarks</h4>
                                                   <p className="text-indigo-800 text-sm font-medium leading-relaxed notes-html-content">
                                                       <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{teacherMsg}</ReactMarkdown>
                                                   </p>
                                               </div>
                                           </div>
                                       )}

                                       {/* HEADER & MARKSHEET BUTTON */}
                                       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                                           <div>
                                               <h2 className="text-2xl font-black text-slate-800">Analysis Dashboard</h2>
                                               <p className="text-slate-600 font-medium">Deep dive into your performance.</p>
                                           </div>
                                           {onShowMarksheet && (
                                                <button
                                                    onClick={() => onShowMarksheet(content.analytics)}
                                                    className="bg-slate-800 text-white px-5 py-3 rounded-xl text-sm font-bold shadow-lg hover:bg-slate-900 flex items-center justify-center gap-2 transition-all active:scale-95"
                                                >
                                                    <FileText size={18} /> View Official Marksheet
                                                </button>
                                           )}
                                       </div>

                                       {/* Performance Summary */}
                                       <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
                                           <h3 className="font-black text-slate-800 text-lg mb-4">Performance Summary</h3>
                                           <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                               <div className="p-3 bg-slate-50 rounded-xl border border-slate-100"><div className="text-xs text-slate-600 uppercase font-bold">Score</div><div className="text-2xl font-black text-slate-800">{correct}/{displayData.length}</div></div>
                                               <div className="p-3 bg-slate-50 rounded-xl border border-slate-100"><div className="text-xs text-slate-600 uppercase font-bold">Accuracy</div><div className="text-2xl font-black text-blue-600">{percent}%</div></div>
                                               <div className="p-3 bg-green-50 rounded-xl border border-green-100"><div className="text-xs text-green-600 uppercase font-bold">Correct</div><div className="text-2xl font-black text-green-700">{correct}</div></div>
                                               <div className="p-3 bg-red-50 rounded-xl border border-red-100"><div className="text-xs text-red-600 uppercase font-bold">Wrong</div><div className="text-2xl font-black text-red-700">{wrong}</div></div>
                                           </div>
                                       </div>

                                       {/* RECENT PROGRESS (Last 3 Attempts) */}
                                       {pastAttempts.length > 0 && (
                                           <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
                                               <h3 className="font-black text-slate-800 text-lg mb-4 flex items-center gap-2"><BarChart3 size={18}/> Recent Progress</h3>
                                               <div className="flex items-end gap-2 h-32 pb-2">
                                                   {pastAttempts.map((att, idx) => {
                                                       const p = Math.round((att.score / att.totalQuestions) * 100);
                                                       return (
                                                           <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full gap-2 group">
                                                               <span className="text-xs font-bold text-slate-600 group-hover:text-blue-600 transition-colors">{p}%</span>
                                                               <div className="w-full max-w-[40px] bg-slate-100 rounded-t-lg relative overflow-hidden group-hover:bg-blue-50 transition-colors" style={{height: `${p}%`, minHeight: '10%'}}>
                                                                   <div className="absolute bottom-0 left-0 right-0 top-0 bg-blue-500 opacity-20"></div>
                                                                   <div className="absolute bottom-0 left-0 right-0 bg-blue-600 transition-all group-hover:bg-blue-500" style={{height: '4px'}}></div>
                                                               </div>
                                                               <span className="text-[10px] font-bold text-slate-500 uppercase">{new Date(att.date).toLocaleDateString(undefined, {month:'short', day:'numeric'})}</span>
                                                           </div>
                                                       );
                                                   })}
                                               </div>
                                           </div>
                                       )}

                                       {/* MISTAKE PATTERNS (Weak Areas) */}
                                       {weakTopics.length > 0 && (
                                           <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                                                <h3 className="font-black text-red-900 text-lg mb-4 flex items-center gap-2"><AlertTriangle size={18}/> Weak Areas (Needs Focus)</h3>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                    {weakTopics.map((item, idx) => (
                                                        <div key={idx} className="bg-white p-3 rounded-xl border border-red-100 flex items-center justify-between">
                                                            <span className="font-bold text-slate-700 text-sm">{item.topic}</span>
                                                            <span className="text-xs font-black text-red-600 bg-red-50 px-2 py-1 rounded-lg">
                                                                {Math.round((item.score/item.total)*100)}% Accuracy
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>
                                           </div>
                                       )}

                                       {/* AI Analysis (If Available) */}
                                       {content?.aiAnalysisText && (
                                           <div className="bg-white p-6 rounded-3xl shadow-sm border border-purple-100 relative overflow-hidden">
                                               <div className="flex items-center justify-between mb-4 relative z-10">
                                                   <h3 className="font-black text-slate-800 text-lg flex items-center gap-2"><BrainCircuit size={18}/> AI Performance Report</h3>
                                                   <SpeakButton text={content.aiAnalysisText} className="p-2 bg-purple-50 text-purple-600 hover:bg-purple-100" />
                                               </div>
                                               <div className="prose prose-sm prose-slate max-w-none w-full prose-p:text-slate-600 prose-headings:font-black prose-headings:text-slate-800 bg-slate-50 p-4 rounded-xl border border-slate-100 notes-html-content">
                                                   <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{content.aiAnalysisText}</ReactMarkdown>
                                               </div>
                                           </div>
                                       )}

                                       {/* Topic Breakdown */}
                                       <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
                                           <h3 className="font-black text-slate-800 text-lg mb-4 flex items-center gap-2"><List size={18}/> Topic Breakdown</h3>
                                           <div className="space-y-4">
                                               {Object.keys(topicStats).map((t, i) => {
                                                   const s = topicStats[t];
                                                   const p = Math.round((s.correct/s.total)*100);
                                                   return (
                                                       <div key={i}>
                                                           <div className="flex justify-between mb-1 text-xs font-bold">
                                                               <span className="uppercase text-slate-600">{t}</span>
                                                               <span>{s.correct}/{s.total} ({p}%)</span>
                                                           </div>
                                                           <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                                                               <div className={`h-full ${p>=80?'bg-green-500':'bg-red-500'}`} style={{width: `${p}%`}}></div>
                                                           </div>
                                                       </div>
                                                   );
                                               })}
                                           </div>
                                       </div>

                                       {/* Detailed Solutions Hidden by default, redirecting to marksheet instead */}
                                       <div className="mt-8">
                                           <button
                                               onClick={() => {
                                                   if (onShowMarksheet) {
                                                       // Construct temporary result object to pass to marksheet
                                                       const result = {
                                                           id: 'temp',
                                                           userId: user?.id,
                                                           chapterId: chapter.id,
                                                           chapterTitle: chapter.title,
                                                           subjectId: subject.id,
                                                           subjectName: subject.name,
                                                           score: Object.keys(mcqState).reduce((acc, k) => acc + (mcqState[parseInt(k)] === displayData[parseInt(k)].correctAnswer ? 1 : 0), 0),
                                                           totalQuestions: displayData.length,
                                                           totalTimeSeconds: 0,
                                                           omrData: displayData.map((q, i) => ({
                                                               qIndex: i,
                                                               selected: mcqState[i] !== undefined && mcqState[i] !== null ? mcqState[i]! : -1,
                                                               correct: q.correctAnswer
                                                           })),
                                                           date: new Date().toISOString()
                                                       };
                                                       onShowMarksheet(result);
                                                   } else {
                                                       setAlertConfig({isOpen: true, title: "Unavailable", message: "Explanation page is not available here."});
                                                   }
                                               }}
                                               className="w-full bg-blue-100 text-blue-700 font-bold py-4 rounded-2xl flex justify-center items-center gap-2 hover:bg-blue-200 transition-colors"
                                           >
                                               <BookOpen size={20} /> View Full Explanations Page
                                           </button>
                                       </div>
                                   </div>
                               );
                           }

                           // TAB LOGIC
                           if (activeAnalysisTab === 'OVERVIEW') {
                               return (
                                   <div className="grid grid-cols-2 gap-4">
                                       <div className="bg-white p-4 rounded-2xl border shadow-sm">
                                           <div className="text-sm text-slate-600 font-bold uppercase mb-1">Total Questions</div>
                                           <div className="text-3xl font-black text-slate-800">{displayData.length}</div>
                                       </div>
                                       <div className="bg-white p-4 rounded-2xl border shadow-sm">
                                           <div className="text-sm text-slate-600 font-bold uppercase mb-1">Attempted</div>
                                           <div className="text-3xl font-black text-blue-600">{Object.keys(mcqState).length}</div>
                                       </div>
                                       <div className="bg-white p-4 rounded-2xl border shadow-sm border-green-100 bg-green-50">
                                           <div className="text-sm text-green-600 font-bold uppercase mb-1">Correct</div>
                                           <div className="text-3xl font-black text-green-700">
                                               {displayData.reduce((acc, q, i) => acc + (mcqState[i] === q.correctAnswer ? 1 : 0), 0)}
                                           </div>
                                       </div>
                                       <div className="bg-white p-4 rounded-2xl border shadow-sm border-red-100 bg-red-50">
                                           <div className="text-sm text-red-600 font-bold uppercase mb-1">Wrong</div>
                                           <div className="text-3xl font-black text-red-700">
                                               {displayData.reduce((acc, q, i) => acc + (mcqState[i] !== undefined && mcqState[i] !== q.correctAnswer ? 1 : 0), 0)}
                                           </div>
                                       </div>
                                   </div>
                               );
                           }

                           // 1. Group Data
                           const lastAttemptedIdx = Object.keys(mcqState).length > 0
                               ? Math.max(...Object.keys(mcqState).map(Number))
                               : -1;

                           const grouped: Record<string, {questions: MCQItem[], indices: number[], correct: number}> = {};
                           displayData.forEach((q, idx) => {
                               // For QUESTIONS tab: only show questions up to last attempted index
                               if (activeAnalysisTab === 'QUESTIONS') {
                                   if (idx > lastAttemptedIdx) return;
                               }

                               // Filter for MISTAKES tab
                               if (activeAnalysisTab === 'MISTAKES') {
                                   if (mcqState[idx] === undefined || mcqState[idx] === q.correctAnswer) return;
                               }

                               const topic = q.topic || 'General';
                               if (!grouped[topic]) grouped[topic] = {questions: [], indices: [], correct: 0};
                               grouped[topic].questions.push(q);
                               grouped[topic].indices.push(idx);
                               if (mcqState[idx] === q.correctAnswer) grouped[topic].correct++;
                           });

                           if (Object.keys(grouped).length === 0) {
                               return (
                                   <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
                                       <p className="text-slate-500 font-bold">No questions found for this filter.</p>
                                   </div>
                               );
                           }

                           return Object.keys(grouped).map((topic, groupIdx) => {
                               const group = grouped[topic];
                               const score = group.correct;
                               const total = group.questions.length;
                               const percentage = Math.round((score / total) * 100);

                               // Find Topic Note (if any)
                               const topicNote = universalNotes.find(n => n.topic === topic && (n.chapterId === chapter.id || n.type === 'HTML')); // Loose match for demo

                               return (
                                   <div key={groupIdx} className="mb-8 border-t-4 border-slate-200 pt-6">
                                       <div className="flex items-center justify-between mb-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                                           <div>
                                               <h3 className="font-black text-slate-800 text-lg flex items-center gap-2">
                                                   <span className="bg-slate-200 text-slate-600 w-6 h-6 rounded flex items-center justify-center text-xs">{groupIdx + 1}</span>
                                                   {topic}
                                               </h3>
                                           </div>
                                           <div className="text-right">
                                               {activeAnalysisTab === 'QUESTIONS' && (
                                                   <>
                                                       <div className="text-2xl font-black text-blue-600">{percentage}%</div>
                                                       <div className="text-xs font-bold text-slate-500">{score}/{total} Correct</div>
                                                   </>
                                               )}
                                               {activeAnalysisTab === 'MISTAKES' && (
                                                   <span className="text-xs font-bold text-red-500 bg-red-50 px-2 py-1 rounded">Needs Improvement</span>
                                               )}
                                           </div>
                                       </div>

                                       <div className="space-y-6">
                                           {group.questions.map((q, localI) => {
                                               const idx = group.indices[localI];
                                               const userAnswer = mcqState[idx];
                                               const isAnswered = userAnswer !== undefined && userAnswer !== null;
                                               const isCorrect = isAnswered && userAnswer === q.correctAnswer;
                                               const isWrong = isAnswered && !isCorrect;
                                               const fullQuestionText = `${q.question}. Options are: ${q.options.map((opt, i) => `Option ${i+1}: ${opt}`).join('. ')}`;

                                               return (
                                                   <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                                                       <div className="flex justify-between items-start mb-4 gap-3">
                                                           <div className="font-bold text-slate-800 flex gap-3 leading-relaxed flex-1">
                                                               <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs shrink-0 font-bold mt-0.5 ${isCorrect ? 'bg-green-100 text-green-700' : isWrong ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>
                                                                   {idx + 1}
                                                               </span>
                                                               <div className="w-full">
                                                                   {!isAnswered && (
                                                                       <span className="inline-block text-[10px] font-black text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md border border-orange-200 uppercase tracking-wide mb-1">
                                                                           Skip
                                                                       </span>
                                                                   )}
                                                                   <McqQuestionDisplay q={q} questionClassName="prose prose-sm max-w-none" />
                                                               </div>
                                                           </div>
                                                           <div className="flex items-center gap-1.5 shrink-0">
                                                               <McqSpeakButtons
                                                                   question={q.question}
                                                                   options={q.options}
                                                                   correctAnswer={q.correctAnswer}
                                                                   className="shrink-0"
                                                                   allQuestions={group.questions as any}
                                                                   index={localI}
                                                               />
                                                                <button
                                                                    type="button"
                                                                    onClick={() => setShowQuestionDrawer(true)}
                                                                    aria-label="Open all questions"
                                                                    title="All Questions"
                                                                    className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-indigo-50 text-indigo-600 hover:bg-indigo-100 active:scale-95 transition-colors"
                                                                >
                                                                    <LayoutGrid size={15} />
                                                                </button>
                                                               {onSendToMcqCommunity && (
                                                                   <button
                                                                       onPointerDown={(e) => {
                                                                           e.stopPropagation();
                                                                           const opts = q.options.length === 4
                                                                               ? q.options as [string,string,string,string]
                                                                               : ([...q.options, '', '', '', ''].slice(0, 4) as [string,string,string,string]);
                                                                           const stmts = getMcqStatements(q);
                                                                            let finalStmts = stmts;
                                                                            let cleanQ = (q.question || '').replace(/<br\s*\/?>/gi, '\n').trim();
                                                                            if (finalStmts.length === 0) {
                                                                                const ext = extractStatements(cleanQ);
                                                                                if (ext.statements.length > 0) {
                                                                                    finalStmts = ext.statements;
                                                                                    cleanQ = ext.cleanedQuestion.replace(/<br\s*\/?>/gi, '\n').trim();
                                                                                }
                                                                            }
                                                                            onSendToMcqCommunity({ question: cleanQ, statements: finalStmts.length > 0 ? finalStmts : undefined, options: opts, correctAnswer: q.correctAnswer, explanation: (q as any).explanation || '' });
                                                                       }}
                                                                       className="w-6 h-6 rounded-full flex items-center justify-center active:scale-90 transition-all bg-violet-100 text-violet-600"
                                                                       title="MCQ Community mein bhejo"
                                                                   >
                                                                       <Plus size={13} strokeWidth={2.5} />
                                                                   </button>
                                                               )}
                                                           </div>
                                                       </div>
                                                       {!isAnswered ? (
                                                           <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 text-center">
                                                               <p className="text-orange-600 font-bold text-sm">Question Skip ki gayi</p>
                                                               <p className="text-orange-500 text-xs mt-1">Sahi jawab: Option {String.fromCharCode(65 + q.correctAnswer)}) {q.options[q.correctAnswer]}</p>
                                                           </div>
                                                       ) : (
                                                       <div className="space-y-2">
                                                           {q.options.map((opt, oIdx) => {
                                                               let btnClass = "w-full text-left p-3 rounded-xl border transition-all text-sm font-medium relative overflow-hidden ";
                                                               if (oIdx === q.correctAnswer) {
                                                                   btnClass += "bg-green-100 border-green-300 text-green-800";
                                                               } else if (userAnswer === oIdx) {
                                                                   btnClass += "bg-red-100 border-red-300 text-red-800";
                                                               } else {
                                                                   btnClass += "bg-slate-50 border-slate-100 opacity-60 text-slate-800";
                                                               }

                                                               return (
                                                                   <div key={oIdx} className={btnClass}>
                                                                       <span className="relative z-10 flex justify-between items-center w-full gap-2">
                                                                           <div dangerouslySetInnerHTML={{ __html: renderMathInHtml(opt) }} className="flex-1" />
                                                                           <div className="flex items-center gap-2 shrink-0">
                                                                               {oIdx === q.correctAnswer && <CheckCircle size={16} className="text-green-600" />}
                                                                               {userAnswer === oIdx && userAnswer !== q.correctAnswer && <XCircle size={16} className="text-red-500" />}
                                                                           </div>
                                                                       </span>
                                                                   </div>
                                                               );
                                                           })}
                                                       </div>
                                                       )}
                                                       {q.explanation && (
                                                           <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-xl">
                                                               <div className="flex items-center justify-between mb-1">
                                                                   <div className="flex items-center gap-2 text-blue-700 font-bold text-xs">
                                                                       <BookOpen size={14} /> Explanation
                                                                   </div>
                                                                   <SpeakButton text={q.explanation} className="p-1 text-blue-400 hover:bg-blue-100" iconSize={14} />
                                                               </div>
                                                               <div className="text-slate-600 text-sm leading-relaxed prose prose-sm max-w-none w-full" dangerouslySetInnerHTML={{ __html: formatExplanationHtml(q.explanation) }} />
                                                           </div>
                                                       )}
                                                   </div>
                                               );
                                           })}
                                       </div>

                                       {/* TOPIC NOTE INJECTION */}
                                       {topicNote && (
                                           <div className="mt-6 bg-amber-50 p-4 rounded-xl border border-amber-200">
                                               <h4 className="font-bold text-amber-900 flex items-center gap-2 mb-2">
                                                   <Lightbulb size={18} /> {topic} Revision Note
                                               </h4>
                                               <div className="prose prose-sm max-w-none w-full text-amber-800" dangerouslySetInnerHTML={{ __html: renderMathInHtml(decodeHtml(topicNote.content || topicNote.html || '')) }} />
                                           </div>
                                       )}
                                   </div>
                               );
                           });
                       } else {
                           // Standard Batch Rendering (Test Mode)
                           return currentBatchData.map((q, localIdx) => {
                               const idx = (batchIndex * BATCH_SIZE) + localIdx;
                               const userAnswer = mcqState[idx];
                               const isAnswered = userAnswer !== undefined && userAnswer !== null;
                               const isCorrect = isAnswered && userAnswer === q.correctAnswer;
                               const isWrong = isAnswered && !isCorrect;
                               
                               const isRevealed = revealedAnswers.has(idx);
                               const showExplanation = (showResults && isAnswered) || isRevealed;
                               const fullQuestionText = `${q.question}. Options are: ${q.options.map((opt, i) => `Option ${i+1}: ${opt}`).join('. ')}`;

                                return (
                                    <div key={idx} className="transition-all">
                                        {q.topic && (
                                            <div className="mb-2 inline-flex text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                                                {q.topic}
                                            </div>
                                        )}
                                        <McqPracticeCard
                                            q={q}
                                            questionNumber={q.questionNumber ?? idx + 1}
                                            selectedOption={userAnswer ?? null}
                                            answered={isAnswered || isRevealed}
                                            showResult={showResults || isRevealed}
                                            disabled={showResults}
                                            onSelect={(oIdx) => handleOptionSelect(idx, oIdx)}
                                            actions={(
                                                <>
                                                    <McqSpeakButtons
                                                        question={q.question}
                                                        options={q.options}
                                                        correctAnswer={q.correctAnswer}
                                                        allQuestions={currentBatchData as any}
                                                        index={localIdx}
                                                    />
                                                    <button
                                                        type="button"
                                                        onClick={() => setShowQuestionDrawer(true)}
                                                        aria-label="Open all questions"
                                                        title="All Questions"
                                                        className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-indigo-50 text-indigo-600 hover:bg-indigo-100 active:scale-95 transition-colors"
                                                    >
                                                        <LayoutGrid size={15} />
                                                    </button>
                                                    {onSendToMcqCommunity && (
                                                        <button
                                                            onPointerDown={(e) => {
                                                                e.stopPropagation();
                                                                const opts = q.options.length === 4
                                                                    ? q.options as [string,string,string,string]
                                                                    : ([...q.options, '', '', '', ''].slice(0, 4) as [string,string,string,string]);
                                                                const stmts = getMcqStatements(q);
                                                                let finalStmts = stmts;
                                                                let cleanQ = (q.question || '').replace(/<br\s*\/?>/gi, '\n').trim();
                                                                if (finalStmts.length === 0) {
                                                                    const ext = extractStatements(cleanQ);
                                                                    if (ext.statements.length > 0) {
                                                                        finalStmts = ext.statements;
                                                                        cleanQ = ext.cleanedQuestion.replace(/<br\s*\/?>/gi, '\n').trim();
                                                                    }
                                                                }
                                                                onSendToMcqCommunity({ question: cleanQ, statements: finalStmts.length > 0 ? finalStmts : undefined, options: opts, correctAnswer: q.correctAnswer, explanation: (q as any).explanation || '' });
                                                            }}
                                                            className="w-7 h-7 rounded-full flex items-center justify-center active:scale-90 transition-all bg-violet-100 text-violet-600"
                                                            title="MCQ Community mein bhejo"
                                                        >
                                                            <Plus size={13} strokeWidth={2.5} />
                                                        </button>
                                                    )}
                                                    {autoReadEnabled && !showResults && !showSubmitModal && (
                                                        <SpeakButton
                                                            text={fullQuestionText}
                                                            className="hidden"
                                                            settings={settings}
                                                            autoPlay={autoReadEnabled && !showResults && !showSubmitModal}
                                                            onToggleAutoTts={onToggleAutoTts}
                                                        />
                                                    )}
                                                </>
                                            )}
                                        />

                                       {/* ── MCQ Suggestion Button ── */}
                                       <div className="mt-3 flex justify-end">
                                         <button
                                           onClick={() => setMcqSuggestionOpen(p => ({ ...p, [idx]: !p[idx] }))}
                                           className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                                             mcqSuggestionOpen[idx]
                                               ? 'bg-amber-100 text-amber-700 border-amber-300'
                                               : mcqSuggestionSent.has(idx)
                                                 ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                                                 : 'bg-white text-slate-500 border-slate-200 hover:bg-amber-50 hover:text-amber-600 hover:border-amber-200'
                                           }`}
                                         >
                                           <Lightbulb size={12} />
                                           {mcqSuggestionSent.has(idx) ? '✓ Sent' : 'Question mein galti?'}
                                         </button>
                                       </div>

                                       {mcqSuggestionOpen[idx] && (
                                         <div className="mt-2 bg-amber-50 border border-amber-200 rounded-xl p-3 space-y-2">
                                           {mcqSuggestionSent.has(idx) ? (
                                             <p className="text-xs text-emerald-700 font-bold text-center py-1">
                                               ✅ Suggestion bhej diya! Admin fix karega.
                                             </p>
                                           ) : (
                                             <>
                                               <p className="text-xs font-bold text-amber-800 flex items-center gap-1">
                                                 <Lightbulb size={11} className="text-amber-600" />
                                                 Is question mein kya galti hai? Batao:
                                               </p>
                                               <textarea
                                                 value={mcqSuggestionText[idx] || ''}
                                                 onChange={e => setMcqSuggestionText(p => ({ ...p, [idx]: e.target.value }))}
                                                 placeholder="Question galat hai, option galat hai, answer galat hai..."
                                                 className="w-full text-xs border border-amber-200 rounded-xl p-2.5 bg-white resize-none h-14 focus:outline-none focus:ring-2 focus:ring-amber-300"
                                               />
                                               <div className="flex gap-2">
                                                 <button
                                                   onClick={() => setMcqSuggestionOpen(p => ({ ...p, [idx]: false }))}
                                                   className="flex-1 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-600"
                                                 >
                                                   Cancel
                                                 </button>
                                                 <button
                                                   onClick={async () => {
                                                     const text = (mcqSuggestionText[idx] || '').trim();
                                                     if (!text) return;
                                                     try {
                                                       await saveSuggestion({
                                                         id: `mcq_lv_${Date.now()}`,
                                                         text: `MCQ: "${(q.question || '').substring(0, 100)}" | Sahi Jawab: ${q.options?.[q.correctAnswer] || '—'} | Correction: ${text}`,
                                                         uid: user?.id || 'anonymous',
                                                         userName: user?.name || user?.email?.split('@')[0] || 'Student',
                                                         userBoard: (user as any)?.board || '',
                                                         createdAt: new Date().toISOString(),
                                                         mode: 'mcq',
                                                         lessonTitle: chapter?.title,
                                                         subject: subject?.name,
                                                       });
                                                       setMcqSuggestionSent(prev => new Set(prev).add(idx));
                                                       setMcqSuggestionOpen(p => ({ ...p, [idx]: false }));
                                                     } catch (err) {
                                                       console.error('Suggestion save failed:', err);
                                                     }
                                                   }}
                                                   disabled={!(mcqSuggestionText[idx] || '').trim()}
                                                   className="flex-1 py-1.5 rounded-xl bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50"
                                                 >
                                                   <Send size={11} /> Admin ko Bhejo
                                                 </button>
                                               </div>
                                             </>
                                           )}
                                         </div>
                                       )}

                                       {showExplanation && (
                                           <div className="mt-6 flex flex-col gap-4 animate-in fade-in slide-in-from-top-2">
                                               {q.concept && (
                                                   <div className="p-4 bg-purple-50 border border-purple-100 rounded-xl">
                                                        <div className="flex items-center gap-2 text-purple-700 font-bold text-xs mb-2">
                                                            <BrainCircuit size={14} /> Core Concept
                                                        </div>
                                                        <div className="text-slate-700 text-sm leading-relaxed prose prose-sm max-w-none w-full" dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.concept) }} />
                                                   </div>
                                               )}
                                               {q.explanation && (
                                                   <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl">
                                                       <div className="flex items-center justify-between mb-1">
                                                           <div className="flex items-center gap-2 text-blue-700 font-bold text-xs">
                                                               <BookOpen size={14} /> Explanation
                                                           </div>
                                                           <SpeakButton text={q.explanation} className="p-1 text-blue-400 hover:bg-blue-100" iconSize={14} />
                                                       </div>
                                                       <div className="text-slate-600 text-sm leading-relaxed prose prose-sm max-w-none w-full" dangerouslySetInnerHTML={{ __html: formatExplanationHtml(q.explanation) }} />
                                                   </div>
                                               )}
                                               {q.commonMistake && (
                                                   <div className="p-4 bg-red-50 border border-red-100 rounded-xl">
                                                        <div className="flex items-center gap-2 text-red-700 font-bold text-xs mb-2">
                                                            <AlertTriangle size={14} /> Common Mistake
                                                        </div>
                                                        <div className="text-red-900 text-sm leading-relaxed prose prose-sm max-w-none w-full" dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.commonMistake) }} />
                                                   </div>
                                               )}
                                               {q.examTip && (
                                                   <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                                                        <div className="flex items-center gap-2 text-amber-700 font-bold text-xs mb-2">
                                                            <Lightbulb size={14} /> Exam Tip
                                                        </div>
                                                        <div className="text-amber-900 text-sm leading-relaxed prose prose-sm max-w-none w-full" dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.examTip) }} />
                                                   </div>
                                               )}
                                               {q.mnemonic && (
                                                   <div className="p-4 bg-teal-50 border border-teal-100 rounded-xl">
                                                        <div className="flex items-center gap-2 text-teal-700 font-bold text-xs mb-2">
                                                            <Zap size={14} /> Memory Trick
                                                        </div>
                                                        <div className="text-teal-900 text-sm leading-relaxed font-bold" dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.mnemonic) }} />
                                                   </div>
                                               )}
                                           </div>
                                       )}
                                   </div>
                               );
                           });
                       }
                   })()}

                   {/* 4. RECOMMENDED NOTES (Bottom) */}
                   {showResults && (content.type === 'MCQ_ANALYSIS' || content.type === 'MCQ_RESULT') && renderRecommendedNotes()}
               </div>

                {/* HIDDEN PRINT CONTAINER */}
                <div id="printable-analysis-report" style={{ position: 'absolute', left: '-10000px', width: '800px', backgroundColor: 'white', padding: '40px' }}>
                    <div className="text-center mb-8 border-b-2 border-slate-900 pb-6">
                        <h1 className="text-3xl font-black text-slate-900 uppercase">{settings?.appName || 'Analysis Report'}</h1>
                        <p className="text-lg font-bold text-slate-600">{chapter.title}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-8 text-center">
                        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                            <p className="text-xs font-bold text-slate-500 uppercase">Score</p>
                            <p className="text-4xl font-black text-slate-900">{Object.keys(mcqState).reduce((acc, k) => acc + (mcqState[parseInt(k)] === (displayData[parseInt(k)]?.correctAnswer) ? 1 : 0), 0)} / {displayData.length}</p>
                        </div>
                        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                            <p className="text-xs font-bold text-slate-500 uppercase">Accuracy</p>
                            <p className="text-4xl font-black text-blue-600">
                                {displayData.length > 0 ? Math.round((Object.keys(mcqState).reduce((acc, k) => acc + (mcqState[parseInt(k)] === (displayData[parseInt(k)]?.correctAnswer) ? 1 : 0), 0) / displayData.length) * 100) : 0}%
                            </p>
                        </div>
                    </div>

                    <div className="space-y-6">
                        {displayData.map((q, idx) => {
                            const userAnswer = mcqState[idx];
                            const isCorrect = userAnswer === q.correctAnswer;
                            const isAnswered = userAnswer !== undefined && userAnswer !== null;

                            return (
                                <div key={idx} className="border border-slate-200 rounded-xl p-4">
                                    <div className="flex gap-3 mb-2">
                                        <span className={`w-6 h-6 flex-shrink-0 rounded-full flex items-center justify-center text-xs font-bold ${isCorrect ? 'bg-green-100 text-green-700' : isAnswered ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>
                                            {idx + 1}
                                        </span>
                                        <div className="font-bold text-slate-800 text-sm w-full">
                                            <McqQuestionDisplay q={q} questionClassName="text-sm" stmtClassName="bg-slate-50/80 p-2 rounded-lg border-l-4 border-indigo-200 text-slate-700 text-xs font-medium leading-snug" />
                                        </div>
                                    </div>
                                    <div className="ml-9 space-y-1 mb-2">
                                        {q.options.map((opt, oIdx) => {
                                            const isSelected = userAnswer === oIdx;
                                            const isAns = q.correctAnswer === oIdx;
                                            let cls = "text-slate-700";
                                            if (isAns) cls = "text-green-700 font-bold";
                                            else if (isSelected) cls = "text-red-700 font-bold line-through";
                                            return (
                                                <div key={oIdx} className={`text-xs ${cls}`}>
                                                    {String.fromCharCode(65 + oIdx)}. <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(opt) }}></span>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    <div className="ml-9 p-2 bg-slate-50 text-[10px] text-slate-600 italic rounded">
                                        <span className="font-bold">Explanation:</span> <span dangerouslySetInnerHTML={{ __html: formatExplanationHtml(q.explanation || "N/A") }}></span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

               <DownloadOptionsModal
                   isOpen={downloadModalOpen}
                   onClose={() => setDownloadModalOpen(false)}
                   title="Download Analysis Report"
                   onDownloadPdf={() => handleConfirmDownload('PDF')}
                   onDownloadMhtml={() => handleConfirmDownload('MHTML')}
               />

               <div className={`fixed bottom-0 left-0 right-0 w-full mx-auto z-[9999] border-t border-slate-200/90 bg-white/95 px-3 pt-2.5 pb-safe shadow-[0_-8px_24px_rgba(15,23,42,0.09)] backdrop-blur-md sm:px-4 sm:pt-3 sm:pb-4${isImmersive ? ' hidden' : ''}`}>
                    <div className="mx-auto flex w-full max-w-3xl items-center gap-2 sm:gap-3">
                        {showResults && !hasMore ? (
                            <button
                                onClick={handleBack}
                                className="flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-slate-900 px-4 text-sm font-black text-white shadow-lg shadow-slate-200 transition-all hover:bg-slate-800 active:scale-[0.98]"
                            >
                                Finish Review <ArrowLeft size={18} />
                            </button>
                        ) : (
                            <>
                                <button
                                    type="button"
                                    onClick={handlePrevPage}
                                    disabled={batchIndex === 0}
                                    aria-label="Go to previous question"
                                    title="Back"
                                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-slate-600 shadow-sm transition-all hover:border-slate-300 hover:bg-slate-100 active:scale-95 disabled:cursor-not-allowed disabled:opacity-35 max-[380px]:h-11 max-[380px]:w-11 sm:h-14 sm:w-14"
                                >
                                    <ChevronLeft size={20} strokeWidth={2.5} />
                                </button>

                                {!showResults && (
                                    <>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                const qIdx = batchIndex * BATCH_SIZE;
                                                if (mcqState[qIdx] === undefined || mcqState[qIdx] === null) {
                                                    setSkippedQuestions(prev => new Set([...prev, qIdx]));
                                                }
                                                if (hasMore) handleNextPage();
                                            }}
                                            disabled={!hasMore}
                                            className="flex h-12 min-w-[68px] shrink-0 items-center justify-center gap-1.5 rounded-2xl border border-amber-200 bg-amber-50 px-3 text-[11px] font-black text-amber-700 shadow-sm transition-all hover:border-amber-300 hover:bg-amber-100 active:scale-95 disabled:cursor-not-allowed disabled:opacity-35 max-[380px]:h-11 max-[380px]:min-w-[58px] max-[380px]:gap-1 max-[380px]:px-2 max-[380px]:text-[10px] sm:h-14 sm:min-w-[78px] sm:text-xs"
                                        >
                                            <SkipForward size={15} strokeWidth={2.5} />
                                            <span>Skip</span>
                                        </button>

                                        <button
                                            type="button"
                                            onClick={handleNextPage}
                                            disabled={!hasMore || !canGoNext}
                                            aria-label="Go to next question"
                                            title={!canGoNext ? 'Choose an option first' : 'Next'}
                                            className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border shadow-sm transition-all active:scale-95 max-[380px]:h-11 max-[380px]:w-11 sm:h-14 sm:w-14 ${hasMore && canGoNext
                                                ? 'border-blue-600 bg-blue-600 text-white shadow-blue-200 hover:bg-blue-700'
                                                : 'cursor-not-allowed border-slate-200 bg-slate-100 text-slate-300'
                                            }`}
                                        >
                                            <ChevronRight size={20} strokeWidth={2.5} />
                                        </button>

                                        <div className="min-w-0 flex-1 text-center leading-tight">
                                            <p className="truncate text-[11px] font-black text-slate-700 sm:text-xs">
                                                <span className="max-[380px]:hidden">Question </span>{batchIndex + 1} <span className="font-bold text-slate-400">of {displayData.length}</span>
                                            </p>
                                            <p className="mt-1 text-[10px] font-bold text-slate-400 max-[380px]:hidden">
                                                {attemptedCount} answered
                                            </p>
                                        </div>

                                        <button
                                            type="button"
                                            onClick={handleSubmitRequest}
                                            disabled={!canSubmit}
                                            className={`flex h-12 min-w-[112px] shrink-0 flex-col items-center justify-center rounded-2xl px-3 text-xs font-black leading-tight shadow-lg transition-all active:scale-[0.98] max-[380px]:h-11 max-[380px]:min-w-[96px] max-[380px]:px-2 max-[380px]:text-[11px] sm:h-14 sm:min-w-[138px] sm:text-sm ${canSubmit
                                                ? 'bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-green-200 hover:from-emerald-600 hover:to-green-700'
                                                : 'cursor-not-allowed border border-slate-200 bg-slate-100 text-slate-400 shadow-none'
                                            }`}
                                        >
                                            <span className="flex items-center gap-1.5">
                                                Submit Test <Trophy size={16} strokeWidth={2.5} />
                                            </span>
                                            {!canSubmit && (
                                                <span className="mt-0.5 text-[9px] font-bold opacity-75">
                                                    Answer 1 question
                                                </span>
                                            )}
                                        </button>
                                    </>
                                )}
                            </>
                        )}
                    </div>
                </div>
                   </div>
          </div>
      );
  }

  return (
      <div className="h-[70vh] flex flex-col items-center justify-center text-center p-8 bg-slate-50 rounded-2xl m-4 border-2 border-dashed border-slate-200">
          <BookOpen size={64} className="text-slate-300 mb-4" />
          <h2 className="text-2xl font-black text-slate-800 mb-2">No Content</h2>
          <p className="text-slate-600 max-w-xs mx-auto mb-6">
              There is no content available for this lesson.
          </p>
          <button onClick={handleBack} className="mt-8 text-slate-500 font-bold hover:text-slate-600">
              Go Back
          </button>
      </div>
  );
};
