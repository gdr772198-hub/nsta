import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { telegramProxyPlugin } from './telegramProxyPlugin';

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    telegramProxyPlugin(),
  ],
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
});
