// ─── Group Study & Live Classroom Realtime Service ──────────────────────────────
// Uses Firebase Realtime Database (RTDB) for ₹0 operational cost.
// Reads & writes are streamlined; timer ticks run purely in client memory.
// Presence uses onDisconnect() for automatic zero-cost member cleanup.

import { ref, set, get, update, remove, onValue, onDisconnect, push } from 'firebase/database';
import { rtdb, auth } from '../firebase';

export interface GroupStudyMember {
  id: string;
  name: string;
  photoURL?: string;
  joinedAt: number;
  lastSeen: number;
  isHost: boolean;
  level?: number;
  handRaised?: boolean;
  statusText?: string;
}

export interface GroupStudyMessage {
  id: string;
  userId: string;
  userName: string;
  userPhotoURL?: string;
  text: string;
  timestamp: number;
  type?: 'MESSAGE' | 'DOUBT' | 'HAND_RAISE' | 'SYSTEM';
}

export interface GroupStudyMcqQuestion {
  id?: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
  subject?: string;
}

export interface GroupStudyHostSync {
  view?: string;
  activeTab?: string;
  contentViewStep?: 'SUBJECTS' | 'CHAPTERS' | 'PLAYER';
  selectedBoard?: string;
  selectedClass?: string;
  selectedSubject?: {
    id: string;
    name: string;
    icon?: string;
  };
  selectedChapter?: {
    id: string;
    title: string;
    subject?: string;
    chapterNumber?: number | string;
    classLevel?: string;
  };
  contentType?: 'NOTES' | 'MCQ' | 'PDF' | 'AUDIO' | 'VIDEO' | 'OTHER';
  notesState?: {
    isOpen: boolean;
    title: string;
    chapterId?: string;
    topicIndex?: number;
    totalTopics?: number;
    activeTopicTitle?: string;
    scrollPercent?: number;
    isAudioPlaying?: boolean;
  };
  activeMcq?: {
    isOpen: boolean;
    chapterId?: string;
    chapterTitle?: string;
    questionIndex: number;
    totalQuestions: number;
    questionText: string;
    options: string[];
    correctIndex: number;
    explanation?: string;
    status: 'QUESTION' | 'REVEAL' | 'ENDED';
    startTime: number;
    durationSeconds: number;
    studentAnswers?: Record<string, {
      studentName: string;
      studentPhoto?: string;
      selectedOption: number;
      isCorrect: boolean;
      timeTaken: number;
      timestamp: number;
    }>;
  };
  timestamp: number;
}

export type StudyRoomMcqType = 'MCQ_PRACTICE' | 'PROJECTOR_MODE' | 'REVISION_HUB';

export interface McqAnswerOutcome {
  isCorrect: boolean;
  baseXp: number;
  streakBonusXp: number;
  netXpChange: number;
  currentStreak: number;
  maxStreak: number;
  streakBrokenAt?: number;
  earnedPoints: number;
}

export interface GroupStudyRoom {
  id: string;
  name: string;
  subject: string;
  description?: string;
  code: string;
  password: string;
  isPrivate: boolean;
  hostId: string;
  hostName: string;
  hostPhotoURL?: string;
  createdAt: number;
  lastActive: number;
  maxMembers: number;
  mode: 'STUDY' | 'LIVE_MCQ' | 'LIVE_CLASS';
  mcqType: StudyRoomMcqType;
  durationMinutes: number;
  expiresAt: number;
  isExpired?: boolean;
  timer: {
    durationMinutes: number;
    startTime: number | null;
    isPaused: boolean;
    remainingSeconds: number;
  };
  liveClass?: {
    isActive: boolean;
    title: string;
    classUrl?: string;
    lectureNotes?: string;
    pinnedDoubt?: string;
  };
  liveMcq?: {
    isActive: boolean;
    title: string;
    currentQuestionIndex: number;
    totalQuestions: number;
    autoAdvance?: boolean;
    autoAdvanceSeconds?: number;
    questionStartTime: number;
    durationPerQuestion: number;
    status: 'WAITING' | 'QUESTION' | 'REVEAL' | 'ENDED';
    questions: GroupStudyMcqQuestion[];
    scores?: Record<string, {
      name: string;
      score: number;
      correctCount: number;
      wrongCount?: number;
      totalAnswered: number;
      lastAnswerTime?: number;
      selectedOption?: number;
      currentStreak?: number;
      maxStreak?: number;
      userXp?: number;
      streakBonusXp?: number;
    }>;
    questionAnswers?: Record<
      number,
      Record<
        string,
        {
          userId: string;
          userName: string;
          userPhotoURL?: string;
          selectedOption: number;
          isCorrect: boolean;
          timeTakenSec: number;
          timestamp: number;
        }
      >
    >;
  };
  hostSync?: GroupStudyHostSync;
  members?: Record<string, GroupStudyMember>;
  chat?: Record<string, GroupStudyMessage>;
}

// ── Built-in Quick Battle Question Sets ──────────────────────────────────────────
// Curated sets for Competition books so rooms can immediately launch battles
export const CURATED_MCQ_SETS: Array<{ id: string; name: string; subject: string; bookId?: string; emoji: string; questions: GroupStudyMcqQuestion[] }> = [
  {
    id: 'curated_lucent_polity',
    name: 'Lucent भारतीय संविधान एवं राजव्यवस्था',
    subject: 'Polity & Constitution',
    bookId: 'lucent',
    emoji: '📖',
    questions: [
      {
        question: 'संविधान सभा की प्रारूप समिति (Drafting Committee) के अध्यक्ष कौन थे?',
        options: ['डॉ. राजेंद्र प्रसाद', 'डॉ. भीमराव आंबेडकर', 'जवाहरलाल नेहरू', 'बी. एन. राव'],
        correctIndex: 1,
        explanation: 'डॉ. बी.आर. आंबेडकर संविधान सभा की प्रारूप समिति के अध्यक्ष थे।',
      },
      {
        question: 'भारतीय संविधान में मौलिक अधिकार (Fundamental Rights) किस देश के संविधान से प्रेरित हैं?',
        options: ['रूस', 'ब्रिटेन', 'संयुक्त राज्य अमेरिका (USA)', 'कनाडा'],
        correctIndex: 2,
        explanation: 'भारतीय संविधान में मौलिक अधिकार संयुक्त राज्य अमेरिका से लिए गए हैं।',
      },
      {
        question: 'संविधान के किस अनुच्छेद को डॉ. आंबेडकर ने "संविधान की आत्मा और हृदय" कहा था?',
        options: ['अनुच्छेद 14', 'अनुच्छेद 19', 'अनुच्छेद 21', 'अनुच्छेद 32'],
        correctIndex: 3,
        explanation: 'अनुच्छेद 32 (संवैधानिक उपचारों का अधिकार) को डॉ. आंबेडकर ने संविधान की आत्मा कहा था।',
      },
      {
        question: 'भारतीय संविधान में कुल कितनी अनुसूचियाँ (Schedules) वर्तमान में हैं?',
        options: ['8', '10', '12', '14'],
        correctIndex: 2,
        explanation: 'मूल संविधान में 8 अनुसूचियाँ थीं, वर्तमान में 12 अनुसूचियाँ हैं।',
      },
      {
        question: 'भारत में पंचायती राज व्यवस्था का उद्घाटन सर्वप्रथम किस राज्य में हुआ था?',
        options: ['उत्तर प्रदेश', 'राजस्थान (नागौर)', 'बिहार', 'मध्य प्रदेश'],
        correctIndex: 1,
        explanation: '2 अक्टूबर 1959 को राजस्थान के नागौर जिले में पंडित नेहरू द्वारा पंचायती राज का उद्घाटन हुआ था।',
      },
    ],
  },
  {
    id: 'curated_lucent_history',
    name: 'Lucent प्राचीन व मध्यकालीन भारत इतिहास',
    subject: 'Indian History',
    bookId: 'lucent',
    emoji: '📖',
    questions: [
      {
        question: 'सिंधु घाटी सभ्यता का प्रमुख बंदरगाह कौन-सा नगर था?',
        options: ['हड़प्पा', 'कालीबंगा', 'लोथल', 'मोहनजोदड़ो'],
        correctIndex: 2,
        explanation: 'लोथल (गुजरात) हड़प्पा सभ्यता का एक प्रमुख बंदरगाह था।',
      },
      {
        question: 'तराइन का प्रथम युद्ध (1191 ई.) किसके बीच लड़ा गया था?',
        options: [
          'मोहम्मद गोरी और पृथ्वीराज चौहान',
          'बाबर और इब्राहिम लोदी',
          'अकबर और हेमू',
          'महमूद गजनवी और जयपाल',
        ],
        correctIndex: 0,
        explanation: 'तराइन का प्रथम युद्ध 1191 ई. में पृथ्वीराज चौहान और मोहम्मद गोरी के मध्य हुआ, जिसमें पृथ्वीराज चौहान विजयी रहे।',
      },
      {
        question: 'जैन धर्म के 24वें एवं अंतिम तीर्थंकर कौन थे?',
        options: ['ऋषभदेव', 'पार्श्वनाथ', 'महावीर स्वामी', 'अरिष्टनेमि'],
        correctIndex: 2,
        explanation: 'महावीर स्वामी जैन धर्म के 24वें और अंतिम तीर्थंकर थे।',
      },
      {
        question: 'मुगल साम्राज्य की स्थापना 1526 में पानीपत के प्रथम युद्ध के बाद किसने की थी?',
        options: ['हुमायूँ', 'बाबर', 'शेरशाह सूरी', 'अकबर'],
        correctIndex: 1,
        explanation: 'बाबर ने 1526 में पानीपत के प्रथम युद्ध में इब्राहिम लोदी को हराकर मुगल साम्राज्य की स्थापना की।',
      },
    ],
  },
  {
    id: 'curated_speedy_science',
    name: 'Speedy Science • सामान्य विज्ञान प्रश्नोत्तरी',
    subject: 'General Science',
    bookId: 'speedyScience',
    emoji: '🔬',
    questions: [
      {
        question: 'ध्वनि की गति किस माध्यम में सर्वाधिक तेज होती है?',
        options: ['वायु में', 'जल में', 'ठोस (इस्पात) में', 'निर्वात में'],
        correctIndex: 2,
        explanation: 'ध्वनि की गति ठोस माध्यमों में सबसे अधिक होती है, जबकि निर्वात में ध्वनि गमन नहीं कर सकती।',
      },
      {
        question: 'रक्त का सामान्य pH मान कितना होता है?',
        options: ['6.4', '7.0', '7.4', '8.2'],
        correctIndex: 2,
        explanation: 'मानव रक्त हल्का क्षारीय होता है और इसका pH मान लगभग 7.4 होता है।',
      },
      {
        question: 'विटामिन C का रासायनिक नाम क्या है?',
        options: ['थायमिन', 'एस्कॉर्बिक एसिड', 'कैल्सीफेरॉल', 'रेटिनॉल'],
        correctIndex: 1,
        explanation: 'विटामिन C का रासायनिक नाम एस्कॉर्बिक एसिड (Ascorbic Acid) है।',
      },
      {
        question: 'मानव शरीर की सबसे बड़ी ग्रंथि (Largest Gland) कौन-सी है?',
        options: ['थायरॉयड', 'यकृत (Liver)', 'अग्न्याशय (Pancreas)', 'पीयूष ग्रंथि'],
        correctIndex: 1,
        explanation: 'यकृत (Liver) मानव शरीर की सबसे बड़ी ग्रंथि है।',
      },
      {
        question: 'प्रकाश वर्ष (Light Year) किसका मात्रक है?',
        options: ['समय का', 'प्रकाश की तीव्रता का', 'खगोलीय दूरी का', 'ऊर्जा का'],
        correctIndex: 2,
        explanation: 'प्रकाश वर्ष अत्यधिक लम्बी खगोलीय दूरियों को मापने का मात्रक है।',
      },
    ],
  },
  {
    id: 'curated_speedy_social',
    name: 'Speedy Social Science • सामान्य अध्ययन',
    subject: 'Social Science',
    bookId: 'speedySocialScience',
    emoji: '🌍',
    questions: [
      {
        question: 'कर्क रेखा भारत के कितने राज्यों से होकर गुजरती है?',
        options: ['6', '7', '8', '9'],
        correctIndex: 2,
        explanation: 'कर्क रेखा भारत के 8 राज्यों (गुजरात, राजस्थान, म.प्र., छत्तीसगढ़, झारखंड, प. बंगाल, त्रिपुरा, मिजोरम) से गुजरती है।',
      },
      {
        question: 'भारत छोड़ो आंदोलन (Quit India Movement) किस वर्ष प्रारंभ हुआ था?',
        options: ['1920', '1930', '1942', '1947'],
        correctIndex: 2,
        explanation: '8 अगस्त 1942 को बॉम्बे से महात्मा गांधी के नेतृत्व में भारत छोड़ो आंदोलन शुरू हुआ था।',
      },
      {
        question: 'भारतीय संविधान की आठवीं अनुसूची में कितनी भाषाओं को मान्यता दी गई है?',
        options: ['18', '20', '22', '24'],
        correctIndex: 2,
        explanation: 'भारतीय संविधान की आठवीं अनुसूची में वर्तमान में 22 प्राधिकृत भाषाएँ शामिल हैं।',
      },
      {
        question: 'नीति आयोग (NITI Aayog) के पदेन अध्यक्ष कौन होते हैं?',
        options: ['राष्ट्रपति', 'प्रधानमंत्री', 'वित्त मंत्री', 'रिजर्व बैंक गवर्नर'],
        correctIndex: 1,
        explanation: 'भारत के प्रधानमंत्री नीति आयोग के पदेन अध्यक्ष (Ex-officio Chairman) होते हैं।',
      },
    ],
  },
  {
    id: 'curated_sar_sangrah',
    name: 'Sar Sangrah • NCERT सार संग्रह स्पेशल',
    subject: 'NCERT Sar Sangrah',
    bookId: 'sarSangrah',
    emoji: '📜',
    questions: [
      {
        question: 'भारत का राष्ट्रीय आदर्श वाक्य "सत्यमेव जयते" किस उपनिषद से लिया गया है?',
        options: ['कठोपनिषद', 'मुण्डकोपनिषद', 'छांदोग्य उपनिषद', 'केनोपनिषद'],
        correctIndex: 1,
        explanation: '"सत्यमेव जयते" मुण्डकोपनिषद से उद्धृत है।',
      },
      {
        question: 'भारतीय राष्ट्रीय कांग्रेस के प्रथम अधिवेशन (1885) के अध्यक्ष कौन थे?',
        options: ['व्योमेश चन्द्र बनर्जी', 'दादाभाई नौरोजी', 'ए. ओ. ह्यूम', 'सुरेंद्रनाथ बनर्जी'],
        correctIndex: 0,
        explanation: 'भारतीय राष्ट्रीय कांग्रेस के पहले अध्यक्ष व्योमेश चन्द्र बनर्जी (W.C. Bonnerjee) थे।',
      },
      {
        question: 'ओजोन परत (Ozone Layer) वायुमंडल की किस परत में अवस्थित है?',
        options: ['क्षोभ मंडल (Troposphere)', 'समताप मंडल (Stratosphere)', 'मध्य मंडल (Mesosphere)', 'आयन मंडल'],
        correctIndex: 1,
        explanation: 'ओजोन परत समताप मंडल (Stratosphere) में पाई जाती है, जो पराबैंगनी किरणों से रक्षा करती है।',
      },
      {
        question: 'भारत का एकमात्र सक्रिय ज्वालामुखी कहाँ स्थित है?',
        options: ['नारकोंडम द्वीप', 'बैरन द्वीप (अंडमान)', 'लक्षद्वीप', 'कच्छ का रण'],
        correctIndex: 1,
        explanation: 'बैरन द्वीप (Barren Island, अंडमान एवं निकोबार) भारत का एकमात्र सक्रिय ज्वालामुखी है।',
      },
    ],
  },
  {
    id: 'curated_mcq_practice',
    name: 'MCQ Practice Bank • ऑल इंडिया टेस्ट सेट',
    subject: 'General Practice',
    bookId: 'mcq',
    emoji: '🎯',
    questions: [
      {
        question: 'भारत में राष्ट्रीय खेल दिवस किस तिथि को मेजर ध्यानचंद की जयंती पर मनाया जाता है?',
        options: ['15 अगस्त', '29 अगस्त', '5 सितंबर', '14 नवंबर'],
        correctIndex: 1,
        explanation: '29 अगस्त को हॉकी के जादूगर मेजर ध्यानचंद के जन्मदिवस पर राष्ट्रीय खेल दिवस मनाया जाता है।',
      },
      {
        question: 'वायुमंडल में सर्वाधिक मात्रा में पाई जाने वाली गैस कौन-सी है?',
        options: ['ऑक्सीजन (21%)', 'कार्बन डाइऑक्साइड (0.04%)', 'नाइट्रोजन (लगभग 78%)', 'आर्गन'],
        correctIndex: 2,
        explanation: 'वायुमंडल में नाइट्रोजन की मात्रा सर्वाधिक (लगभग 78.08%) है।',
      },
      {
        question: 'भारत का प्रथम राष्ट्रीय उद्यान (National Park) कौन-सा है?',
        options: ['काजीरंगा राष्ट्रीय उद्यान', 'जिम कॉर्बेट राष्ट्रीय उद्यान', 'कान्हा राष्ट्रीय उद्यान', 'गिर राष्ट्रीय उद्यान'],
        correctIndex: 1,
        explanation: 'उत्तराखंड में स्थित जिम कॉर्बेट राष्ट्रीय उद्यान (पहले हैली नेशनल पार्क) भारत का पहला राष्ट्रीय उद्यान है।',
      },
      {
        question: 'अंतर्राष्ट्रीय योग दिवस (International Yoga Day) प्रतिवर्ष किस तिथि को मनाया जाता है?',
        options: ['21 मई', '5 जून', '21 जून', '11 जुलाई'],
        correctIndex: 2,
        explanation: '21 जून को विश्व स्तर पर अंतर्राष्ट्रीय योग दिवस मनाया जाता है।',
      },
    ],
  },
];

// ── Room Code Generator ────────────────────────────────────────────────────────
export const generateRoomCode = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

// ── Local Fallback Cache for Smooth Experience ──────────────────────────────
const LOCAL_ROOMS_KEY = 'iic_cached_study_rooms';

export const getCachedRooms = (): Record<string, GroupStudyRoom> => {
  try {
    const raw = localStorage.getItem(LOCAL_ROOMS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

export const saveCachedRoom = (room: GroupStudyRoom) => {
  try {
    const map = getCachedRooms();
    map[room.id] = room;
    localStorage.setItem(LOCAL_ROOMS_KEY, JSON.stringify(map));
  } catch {}
};

const CREATED_ROOMS_KEY = 'nst_my_created_rooms_v1';

export const markRoomAsCreatedByMe = (roomId: string) => {
  try {
    const raw = localStorage.getItem(CREATED_ROOMS_KEY);
    const ids: string[] = raw ? JSON.parse(raw) : [];
    if (!ids.includes(roomId)) {
      ids.push(roomId);
      localStorage.setItem(CREATED_ROOMS_KEY, JSON.stringify(ids));
    }
  } catch {}
};

export const isRoomCreatedByMe = (roomId: string, hostId?: string, currentUserId?: string): boolean => {
  if (hostId && currentUserId && hostId === currentUserId) return true;
  if (auth.currentUser && hostId && hostId === auth.currentUser.uid) return true;
  try {
    const raw = localStorage.getItem(CREATED_ROOMS_KEY);
    const ids: string[] = raw ? JSON.parse(raw) : [];
    if (ids.includes(roomId)) return true;
  } catch {}
  return false;
};

export const removeCachedRoom = (roomId: string) => {
  try {
    const map = getCachedRooms();
    delete map[roomId];
    localStorage.setItem(LOCAL_ROOMS_KEY, JSON.stringify(map));
  } catch {}
};

// ── Subscribe to All Active Rooms ──────────────────────────────────────────────
export const subscribeToActiveRooms = (callback: (rooms: GroupStudyRoom[]) => void): (() => void) => {
  const roomsRef = ref(rtdb, 'group_study_rooms');
  const unsubscribe = onValue(roomsRef, (snap) => {
    const val = snap.val();
    const localMap = getCachedRooms();
    const merged: Record<string, GroupStudyRoom> = { ...localMap };

    if (val && typeof val === 'object') {
      Object.entries(val).forEach(([k, v]: [string, any]) => {
        if (v && !v.isDeleted) {
          const roomObj = { ...v, id: v.id || k };
          merged[k] = roomObj;
          saveCachedRoom(roomObj);
        } else if (v?.isDeleted) {
          delete merged[k];
          removeCachedRoom(k);
        }
      });
    }

    const list: GroupStudyRoom[] = Object.values(merged).filter(r => !r.isDeleted);
    // Filter rooms active in the last 12 hours
    const now = Date.now();
    const activeList = list.filter((r) => {
      const isFresh = (now - (r.lastActive || r.createdAt || 0)) < 12 * 3600 * 1000;
      return isFresh;
    }).sort((a, b) => (b.lastActive || b.createdAt) - (a.lastActive || a.createdAt));

    callback(activeList);
  }, (err) => {
    console.warn('RTDB study rooms listen warning, using local cache:', err);
    const localList = Object.values(getCachedRooms()).filter(r => !r.isDeleted);
    callback(localList);
  });

  return () => unsubscribe();
};

// ── Subscribe to a Single Room ────────────────────────────────────────────────
export const subscribeToRoom = (roomId: string, callback: (room: GroupStudyRoom | null) => void): (() => void) => {
  const roomRef = ref(rtdb, `group_study_rooms/${roomId}`);
  const unsubscribe = onValue(roomRef, (snap) => {
    const val = snap.val();
    if (val && !val.isDeleted) {
      const roomWithId = { ...val, id: val.id || roomId };
      saveCachedRoom(roomWithId);
      callback(roomWithId);
    } else if (val?.isDeleted) {
      removeCachedRoom(roomId);
      callback(null);
    } else {
      // RTDB value is null; check local cache before assuming deleted
      const cached = getCachedRooms()[roomId];
      if (cached && !cached.isDeleted) {
        callback(cached);
      } else {
        callback(null);
      }
    }
  }, (err) => {
    console.warn(`RTDB subscribe error for room ${roomId}, using cache:`, err);
    const cached = getCachedRooms()[roomId];
    callback(cached || null);
  });

  return () => unsubscribe();
};

// ── Create a New Group Room ───────────────────────────────────────────────────
export const createGroupRoom = async (
  roomData: {
    name: string;
    subject: string;
    password: string;
    description?: string;
    isPrivate?: boolean;
    maxMembers?: number;
    mode?: 'STUDY' | 'LIVE_MCQ' | 'LIVE_CLASS';
    mcqType?: StudyRoomMcqType;
    durationMinutes?: number;
  },
  host: {
    id: string;
    name: string;
    photoURL?: string;
    level?: number;
  }
): Promise<string> => {
  const cleanPassword = (roomData.password || '').trim();
  if (!cleanPassword) {
    throw new Error('Room Password is required to create and start a room!');
  }

  const roomsRef = ref(rtdb, 'group_study_rooms');
  const newRoomRef = push(roomsRef);
  const roomId = newRoomRef.key || `room_${Date.now()}`;
  const now = Date.now();
  const code = generateRoomCode();
  const effectiveHostId = auth.currentUser?.uid || host.id || 'host';

  const hostMember: GroupStudyMember = {
    id: effectiveHostId,
    name: host.name || 'Host',
    photoURL: host.photoURL || '',
    joinedAt: now,
    lastSeen: now,
    isHost: true,
    level: host.level || 1,
    handRaised: false,
    statusText: 'Hosting Room',
  };

  const durationMinutes = roomData.durationMinutes && roomData.durationMinutes > 0 ? roomData.durationMinutes : 30;
  const expiresAt = now + durationMinutes * 60 * 1000;
  const mcqType = roomData.mcqType || 'PROJECTOR_MODE';

  const initialRoom: GroupStudyRoom = {
    id: roomId,
    name: roomData.name.trim() || `${host.name}'s MCQ Arena`,
    subject: roomData.subject || 'General Knowledge',
    description: roomData.description?.trim() || '',
    code,
    password: cleanPassword,
    isPrivate: !!roomData.isPrivate,
    hostId: effectiveHostId,
    hostName: host.name,
    hostPhotoURL: host.photoURL,
    createdAt: now,
    lastActive: now,
    maxMembers: Math.min(Math.max(roomData.maxMembers || 30, 5), 100),
    mode: 'LIVE_MCQ',
    mcqType,
    durationMinutes,
    expiresAt,
    isExpired: false,
    timer: {
      durationMinutes,
      startTime: now,
      isPaused: false,
      remainingSeconds: durationMinutes * 60,
    },
    liveClass: {
      isActive: false,
      title: 'Welcome to Live MCQ Room',
      lectureNotes: '',
      classUrl: '',
    },
    liveMcq: {
      isActive: false,
      title: `${roomData.subject || 'Lesson'} MCQ Battle`,
      currentQuestionIndex: 0,
      totalQuestions: 0,
      questionStartTime: 0,
      durationPerQuestion: mcqType === 'REVISION_HUB' ? 15 : (mcqType === 'PROJECTOR_MODE' ? 25 : 20),
      status: 'WAITING',
      questions: [],
      scores: {},
    },
    members: {
      [effectiveHostId]: hostMember,
    },
    chat: {
      welcome_msg: {
        id: 'welcome_msg',
        userId: effectiveHostId,
        userName: 'IIC Study Bot',
        text: `🎉 Room created by ${host.name}! Mode: ${mcqType === 'REVISION_HUB' ? '⚡ MCQ +' : '🎯 MCQ'}. Room duration: ${durationMinutes} mins.`,
        timestamp: now,
        type: 'SYSTEM',
      }
    }
  };

  // 1. Always save in local room cache first
  saveCachedRoom(initialRoom);

  // 2. Sync to Firebase Realtime Database
  try {
    await set(newRoomRef, initialRoom);

    // Setup onDisconnect for host presence: if host disconnects, room is destroyed
    try {
      const roomRef = ref(rtdb, `group_study_rooms/${roomId}`);
      onDisconnect(roomRef).remove();
    } catch {}
  } catch (err: any) {
    console.warn('[GroupStudy] RTDB write error, room kept in local session:', err);
  }

  return roomId;
};

// ── Join a Room ───────────────────────────────────────────────────────────────
export const joinGroupRoom = async (
  roomId: string,
  user: {
    id: string;
    name: string;
    photoURL?: string;
    level?: number;
  }
): Promise<boolean> => {
  const roomRef = ref(rtdb, `group_study_rooms/${roomId}`);
  let room: GroupStudyRoom | null = null;
  
  try {
    const snap = await get(roomRef);
    if (snap.exists()) {
      room = snap.val();
    }
  } catch {}

  if (!room) {
    room = getCachedRooms()[roomId] || null;
  }
  if (!room) return false;

  const members = room.members || {};
  const memberCount = Object.keys(members).length;

  if (memberCount >= room.maxMembers && !members[user.id]) {
    throw new Error('Room is currently full (max members reached).');
  }

  const now = Date.now();
  const effectiveUserId = auth.currentUser?.uid || user.id;
  const newMember: GroupStudyMember = {
    id: effectiveUserId,
    name: user.name,
    photoURL: user.photoURL,
    joinedAt: now,
    lastSeen: now,
    isHost: room.hostId === effectiveUserId,
    level: user.level || 1,
    handRaised: false,
    statusText: 'Studying',
  };

  // Update local cache
  if (!room.members) room.members = {};
  room.members[effectiveUserId] = newMember;
  room.lastActive = now;
  saveCachedRoom(room);

  // Add member in RTDB
  try {
    const memberRef = ref(rtdb, `group_study_rooms/${roomId}/members/${effectiveUserId}`);
    await set(memberRef, newMember);

    try {
      onDisconnect(memberRef).remove();
    } catch {}

    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      lastActive: now,
    });

    // Post join message if not already present
    if (!members[effectiveUserId]) {
      const chatRef = ref(rtdb, `group_study_rooms/${roomId}/chat`);
      const newMsgRef = push(chatRef);
      await set(newMsgRef, {
        id: newMsgRef.key,
        userId: effectiveUserId,
        userName: user.name,
        text: `👋 ${user.name} joined the room`,
        timestamp: now,
        type: 'SYSTEM',
      });
    }
  } catch (err) {
    console.warn('[GroupStudy] Join RTDB sync error:', err);
  }

  return true;
};

// ── Leave a Room ──────────────────────────────────────────────────────────────
export const leaveGroupRoom = async (roomId: string, userId: string, userName: string): Promise<void> => {
  const effectiveUserId = auth.currentUser?.uid || userId;
  try {
    const memberRef = ref(rtdb, `group_study_rooms/${roomId}/members/${effectiveUserId}`);
    try {
      onDisconnect(memberRef).cancel();
      await remove(memberRef);
    } catch {}

    // Check if room host left OR if 0 members are left in the room
    const roomSnap = await get(ref(rtdb, `group_study_rooms/${roomId}`));
    if (roomSnap.exists()) {
      const room: GroupStudyRoom = roomSnap.val();
      const isHost =
        room.hostId === effectiveUserId ||
        room.hostId === userId ||
        isRoomCreatedByMe(roomId, room.hostId, userId) ||
        isRoomCreatedByMe(roomId, room.hostId, effectiveUserId);

      const remainingMembers = Object.keys(room.members || {}).filter((id) => id !== effectiveUserId);

      // "Room se host ke jate hi room submit ho jayega ya agar user na honge to destroy ho jayega apne aap"
      if (isHost || remainingMembers.length === 0) {
        // Destroy / Delete the room completely
        await deleteGroupRoom(roomId);
      } else {
        // Send leave message
        const chatRef = ref(rtdb, `group_study_rooms/${roomId}/chat`);
        const newMsgRef = push(chatRef);
        await set(newMsgRef, {
          id: newMsgRef.key,
          userId: effectiveUserId,
          userName: userName,
          text: `🏃 ${userName} left the room`,
          timestamp: Date.now(),
          type: 'SYSTEM',
        });
      }
    } else {
      removeCachedRoom(roomId);
    }
  } catch (err) {
    console.error('Error leaving group room:', err);
    removeCachedRoom(roomId);
  }
};

// ── Delete / Destroy a Room (Host or Admin Only) ───────────────────────────────
export const deleteGroupRoom = async (roomId: string): Promise<void> => {
  try {
    // 1. Remove from local cache immediately
    removeCachedRoom(roomId);

    // 2. Mark as deleted in RTDB so real-time subscribers immediately disconnect
    try {
      await update(ref(rtdb, `group_study_rooms/${roomId}`), { isDeleted: true });
    } catch {}

    // 3. Remove room node from Firebase RTDB
    const roomRef = ref(rtdb, `group_study_rooms/${roomId}`);
    await remove(roomRef);
  } catch (err) {
    console.error('Error deleting group room from RTDB:', err);
    // Even if RTDB fails or has permission issues, clean local cache
    removeCachedRoom(roomId);
  }
};

// ── Send a Chat Message / Doubt / Reaction ─────────────────────────────────────
export const sendRoomMessage = async (
  roomId: string,
  user: { id: string; name: string; photoURL?: string },
  text: string,
  type: 'MESSAGE' | 'DOUBT' | 'HAND_RAISE' | 'SYSTEM' = 'MESSAGE'
): Promise<void> => {
  if (!text.trim()) return;
  try {
    const chatRef = ref(rtdb, `group_study_rooms/${roomId}/chat`);
    const newMsgRef = push(chatRef);
    const now = Date.now();

    await set(newMsgRef, {
      id: newMsgRef.key,
      userId: user.id,
      userName: user.name,
      userPhotoURL: user.photoURL,
      text: text.trim(),
      timestamp: now,
      type,
    });

    // Keep room lastActive fresh (non-fatal if restricted)
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      lastActive: now,
    }).catch(() => {});
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('[GroupStudy] sendRoomMessage notice:', err);
  }
};

// ── Toggle Hand Raise ─────────────────────────────────────────────────────────
export const toggleHandRaise = async (roomId: string, userId: string, handRaised: boolean): Promise<void> => {
  try {
    const memberRef = ref(rtdb, `group_study_rooms/${roomId}/members/${userId}`);
    await update(memberRef, {
      handRaised,
      lastSeen: Date.now(),
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] toggleHandRaise notice:', err);
  }
};

// ── Update Study Timer (Start, Pause, Reset) ──────────────────────────────────
export const updateRoomTimer = async (
  roomId: string,
  durationMinutes: number,
  isPaused: boolean,
  startTime: number | null,
  remainingSeconds: number
): Promise<void> => {
  try {
    const timerRef = ref(rtdb, `group_study_rooms/${roomId}/timer`);
    const now = Date.now();
    await update(timerRef, {
      durationMinutes,
      isPaused,
      startTime,
      remainingSeconds,
    });
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      lastActive: now,
    }).catch(() => {});
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] updateRoomTimer notice:', err);
  }
};

// ── Update Live Class Settings ────────────────────────────────────────────────
export const updateLiveClass = async (
  roomId: string,
  classData: {
    isActive: boolean;
    title: string;
    classUrl?: string;
    lectureNotes?: string;
    pinnedDoubt?: string;
  }
): Promise<void> => {
  try {
    const liveClassRef = ref(rtdb, `group_study_rooms/${roomId}/liveClass`);
    await update(liveClassRef, {
      ...classData,
    });
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      mode: classData.isActive ? 'LIVE_CLASS' : 'STUDY',
      lastActive: Date.now(),
    }).catch(() => {});
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] updateLiveClass notice:', err);
  }
};

// ── Switch Room Mode ──────────────────────────────────────────────────────────
export const setRoomMode = async (
  roomId: string,
  mode: 'STUDY' | 'LIVE_MCQ' | 'LIVE_CLASS'
): Promise<void> => {
  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      mode,
      lastActive: Date.now(),
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] setRoomMode notice:', err);
  }
};

// ── Launch Live MCQ Battle ────────────────────────────────────────────────────
export const startLiveMcqBattle = async (
  roomId: string,
  quizTitle: string,
  questions: GroupStudyMcqQuestion[],
  durationPerQuestion: number = 20,
  autoAdvance: boolean = true
): Promise<void> => {
  const now = Date.now();
  const safeQuestions = (questions || []).map((q, idx) => ({
    question: String(q?.question || `Question ${idx + 1}`).trim(),
    options: (Array.isArray(q?.options) ? q.options : ['A', 'B', 'C', 'D'])
      .slice(0, 4)
      .map((opt, oIdx) => String(opt ?? `Option ${oIdx + 1}`).trim()),
    correctIndex: typeof q?.correctIndex === 'number' ? Math.max(0, Math.min(3, q.correctIndex)) : 0,
    explanation: q?.explanation ? String(q.explanation).trim() : '',
  }));

  const liveMcqData: any = {
    isActive: true,
    title: quizTitle,
    currentQuestionIndex: 0,
    totalQuestions: safeQuestions.length,
    questionStartTime: now,
    durationPerQuestion,
    autoAdvance,
    status: 'QUESTION' as const,
    questions: safeQuestions,
  };

  // 1. Immediately update in local cache so host and observers have zero-latency state
  try {
    const cached = getCachedRooms()[roomId];
    if (cached) {
      cached.mode = 'LIVE_MCQ';
      cached.liveMcq = {
        ...liveMcqData,
        scores: {},
        questionAnswers: {},
      };
      cached.lastActive = now;
      saveCachedRoom(cached);
    }
  } catch (cacheErr) {
    console.warn('[GroupStudy] Local cache error in startLiveMcqBattle:', cacheErr);
  }

  // 2. Sync to Firebase RTDB with cleaned payload (prevents undefined field crashes)
  try {
    const payload = cleanRtdbPayload({
      mode: 'LIVE_MCQ',
      liveMcq: liveMcqData,
      lastActive: now,
    });

    await update(ref(rtdb, `group_study_rooms/${roomId}`), payload);

    // Post system announcement
    const chatRef = ref(rtdb, `group_study_rooms/${roomId}/chat`);
    const newMsgRef = push(chatRef);
    await set(newMsgRef, {
      id: newMsgRef.key,
      userId: 'system',
      userName: 'IIC Battle Arena',
      text: `🎯 Live MCQ Battle Started: "${quizTitle}" (${safeQuestions.length} Questions, ${durationPerQuestion}s per question)! Get ready!`,
      timestamp: now,
      type: 'SYSTEM',
    });
  } catch (err: any) {
    console.warn('[GroupStudy] RTDB startLiveMcqBattle sync error:', err);
  }
};

// ── Update Question Timer Duration During Battle ──
export const setRoomMcqDuration = async (
  roomId: string,
  durationPerQuestion: number
): Promise<void> => {
  try {
    const cached = getCachedRooms()[roomId];
    if (cached && cached.liveMcq) {
      cached.liveMcq.durationPerQuestion = durationPerQuestion;
      saveCachedRoom(cached);
    }
  } catch {}

  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}/liveMcq`), {
      durationPerQuestion,
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] setRoomMcqDuration notice:', err);
  }
};

// ── Update Auto Advance Setting ──
export const setRoomMcqAutoAdvance = async (
  roomId: string,
  autoAdvance: boolean
): Promise<void> => {
  try {
    const cached = getCachedRooms()[roomId];
    if (cached && cached.liveMcq) {
      cached.liveMcq.autoAdvance = autoAdvance;
      saveCachedRoom(cached);
    }
  } catch {}

  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}/liveMcq`), {
      autoAdvance,
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] setRoomMcqAutoAdvance notice:', err);
  }
};

// ── Advance or Reveal Question in MCQ Battle ──────────────────────────────────
export const revealMcqAnswer = async (roomId: string): Promise<void> => {
  // Update local cached room immediately
  try {
    const cached = getCachedRooms()[roomId];
    if (cached && cached.liveMcq) {
      cached.liveMcq.status = 'REVEAL';
      saveCachedRoom(cached);
    }
  } catch {}

  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}/liveMcq`), {
      status: 'REVEAL',
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] revealMcqAnswer notice:', err);
  }
};

export const advanceMcqQuestion = async (roomId: string, nextIndex: number, isFinished: boolean = false): Promise<void> => {
  const now = Date.now();
  // Update local cached room immediately
  try {
    const cached = getCachedRooms()[roomId];
    if (cached && cached.liveMcq) {
      if (isFinished) {
        cached.liveMcq.status = 'ENDED';
        cached.liveMcq.isActive = false;
      } else {
        cached.liveMcq.currentQuestionIndex = nextIndex;
        cached.liveMcq.questionStartTime = now;
        cached.liveMcq.status = 'QUESTION';
      }
      saveCachedRoom(cached);
    }
  } catch {}

  try {
    if (isFinished) {
      await update(ref(rtdb, `group_study_rooms/${roomId}/liveMcq`), {
        status: 'ENDED',
        isActive: false,
      });
    } else {
      await update(ref(rtdb, `group_study_rooms/${roomId}/liveMcq`), {
        currentQuestionIndex: nextIndex,
        questionStartTime: now,
        status: 'QUESTION',
      });
    }
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] advanceMcqQuestion notice:', err);
  }
};

export const submitMcqAnswer = async (
  roomId: string,
  userId: string,
  userName: string,
  isCorrect: boolean,
  timeTakenSec: number,
  selectedOption: number,
  currentQuestionIndex?: number,
  userPhotoURL?: string
): Promise<McqAnswerOutcome> => {
  let current: any = {
    name: userName,
    score: 0,
    correctCount: 0,
    wrongCount: 0,
    totalAnswered: 0,
    currentStreak: 0,
    maxStreak: 0,
    userXp: 0,
    streakBonusXp: 0,
  };

  const userScoreRef = ref(rtdb, `group_study_rooms/${roomId}/liveMcq/scores/${userId}`);
  try {
    const snap = await get(userScoreRef);
    if (snap.exists()) {
      current = snap.val();
    }
  } catch {}

  const oldStreak = current.currentStreak || 0;
  let newCurrentStreak = 0;
  let maxStreak = current.maxStreak || 0;
  let baseXp = 0;
  let streakBonusXp = 0;
  let streakBrokenAt: number | undefined = undefined;

  if (isCorrect) {
    // Sahi jawab pe +5 XP
    baseXp = 5;
    newCurrentStreak = oldStreak + 1;
    maxStreak = Math.max(maxStreak, newCurrentStreak);
  } else {
    // Galat jawab pe -2 XP
    baseXp = -2;
    // Streak toot gaya -> Break par bonus milega (3 pe 10, 5 pe 15, 7 pe 20, 10 pe 20)
    if (oldStreak >= 10) {
      streakBonusXp = 20;
      streakBrokenAt = oldStreak;
    } else if (oldStreak >= 7) {
      streakBonusXp = 20;
      streakBrokenAt = oldStreak;
    } else if (oldStreak >= 5) {
      streakBonusXp = 15;
      streakBrokenAt = oldStreak;
    } else if (oldStreak >= 3) {
      streakBonusXp = 10;
      streakBrokenAt = oldStreak;
    }
    newCurrentStreak = 0;
  }

  const netXpChange = baseXp + streakBonusXp;
  const newUserXp = Math.max(0, (current.userXp || 0) + netXpChange);

  // Speed-based point bonus for room leaderboard:
  const speedBonus = isCorrect ? Math.max(0, Math.round(50 - (timeTakenSec * 2))) : 0;
  const earnedPoints = isCorrect ? (100 + speedBonus) : 0;

  try {
    await update(userScoreRef, {
      name: userName,
      score: (current.score || 0) + earnedPoints,
      correctCount: (current.correctCount || 0) + (isCorrect ? 1 : 0),
      wrongCount: (current.wrongCount || 0) + (isCorrect ? 0 : 1),
      totalAnswered: (current.totalAnswered || 0) + 1,
      currentStreak: newCurrentStreak,
      maxStreak,
      userXp: newUserXp,
      streakBonusXp: (current.streakBonusXp || 0) + streakBonusXp,
      lastAnswerTime: Date.now(),
      selectedOption,
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (!msg.includes('PERMISSION_DENIED') && !msg.includes('Permission denied')) {
      console.warn('[GroupStudy] submitMcqAnswer score update notice:', err);
    }
  }

  // Also record this specific question's answer for live per-question stats & final review
  if (typeof currentQuestionIndex === 'number') {
    try {
      const qAnswerRef = ref(
        rtdb,
        `group_study_rooms/${roomId}/liveMcq/questionAnswers/${currentQuestionIndex}/${userId}`
      );
      await set(qAnswerRef, {
        userId,
        userName,
        userPhotoURL: userPhotoURL || '',
        selectedOption,
        isCorrect,
        timeTakenSec,
        timestamp: Date.now(),
      });
    } catch (e: any) {
      const msg = String(e?.message || e || '');
      if (!msg.includes('PERMISSION_DENIED') && !msg.includes('Permission denied')) {
        console.warn('Could not save questionAnswer snapshot:', e);
      }
    }
  }

  return {
    isCorrect,
    baseXp,
    streakBonusXp,
    netXpChange,
    currentStreak: newCurrentStreak,
    maxStreak,
    streakBrokenAt,
    earnedPoints,
  };
};

/**
 * When the quiz or room ends, if a student has an active unbroken streak of 3+,
 * award their streak bonus upon session conclusion so they don't miss out.
 */
export const awardFinalStreakBonus = async (
  roomId: string,
  userId: string
): Promise<number> => {
  try {
    const userScoreRef = ref(rtdb, `group_study_rooms/${roomId}/liveMcq/scores/${userId}`);
    const snap = await get(userScoreRef);
    if (!snap.exists()) return 0;
    const current = snap.val();
    const streak = current.currentStreak || 0;
    if (streak < 3) return 0;

    let bonus = 0;
    if (streak >= 10) bonus = 20;
    else if (streak >= 7) bonus = 20;
    else if (streak >= 5) bonus = 15;
    else if (streak >= 3) bonus = 10;

    if (bonus > 0) {
      await update(userScoreRef, {
        currentStreak: 0,
        userXp: (current.userXp || 0) + bonus,
        streakBonusXp: (current.streakBonusXp || 0) + bonus,
      });
    }
    return bonus;
  } catch (e) {
    console.warn('awardFinalStreakBonus error:', e);
    return 0;
  }
};

export const endLiveMcqBattle = async (roomId: string): Promise<void> => {
  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      mode: 'LIVE_MCQ',
      'liveMcq/isActive': false,
      'liveMcq/status': 'ENDED',
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] endLiveMcqBattle notice:', err);
  }
};

export const autoSubmitRoom = async (roomId: string): Promise<void> => {
  const now = Date.now();
  try {
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      isExpired: true,
      lastActive: now,
      mode: 'LIVE_MCQ',
      'liveMcq/isActive': false,
      'liveMcq/status': 'ENDED',
      'timer/remainingSeconds': 0,
    });

    const chatRef = ref(rtdb, `group_study_rooms/${roomId}/chat`);
    const newMsgRef = push(chatRef);
    await set(newMsgRef, {
      id: newMsgRef.key,
      userId: 'system',
      userName: 'IIC Study Arena',
      text: '⏰ Room time expired! The session has been auto-submitted. Check your final score and XP results below!',
      timestamp: now,
      type: 'SYSTEM',
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) return;
    console.warn('[GroupStudy] autoSubmitRoom notice:', err);
  }
};

export const setRoomMcqType = async (
  roomId: string,
  mcqType: StudyRoomMcqType
): Promise<void> => {
  try {
    const cached = getCachedRooms()[roomId];
    if (cached) {
      cached.mcqType = mcqType;
      cached.lastActive = Date.now();
      saveCachedRoom(cached);
    }
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      mcqType,
      lastActive: Date.now(),
    });
  } catch (err) {
    console.warn('[GroupStudy] setRoomMcqType error:', err);
  }
};

// ── Helper to strip undefined values and empty objects recursively (RTDB throws if any field is undefined or an empty object {}) ──
export const cleanRtdbPayload = (obj: any): any => {
  if (obj === undefined) return null;
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    return obj.map(cleanRtdbPayload).filter((v) => v !== undefined);
  }
  const result: Record<string, any> = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== undefined) {
      const cleaned = cleanRtdbPayload(val);
      // Firebase RTDB update() throws fatal error if an empty object {} is present
      if (
        cleaned !== null &&
        typeof cleaned === 'object' &&
        !Array.isArray(cleaned) &&
        Object.keys(cleaned).length === 0
      ) {
        continue;
      }
      result[key] = cleaned;
    }
  }
  return result;
};

// ── Host Live Synchronization Functions ──────────────────────────────────────────
export const syncHostActivity = async (
  roomId: string,
  syncData: Partial<GroupStudyHostSync>
): Promise<void> => {
  try {
    const cleaned = cleanRtdbPayload(syncData);
    const syncRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync`);
    await update(syncRef, {
      ...cleaned,
      timestamp: Date.now(),
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      // Non-fatal permission boundary on RTDB sync for non-host participants or restricted nodes
      return;
    }
    console.warn('Failed to sync host activity:', err);
  }
};

export const syncHostNotesState = async (
  roomId: string,
  notesData: Partial<NonNullable<GroupStudyHostSync['notesState']>>
): Promise<void> => {
  try {
    const cleaned = cleanRtdbPayload(notesData);
    const notesRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync/notesState`);
    await update(notesRef, {
      ...cleaned,
      isOpen: true,
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('Failed to sync host notes:', err);
  }
};

export const broadcastHostMcq = async (
  roomId: string,
  mcqData: {
    chapterId?: string;
    chapterTitle?: string;
    questionIndex: number;
    totalQuestions: number;
    questionText: string;
    options: string[];
    correctIndex: number;
    explanation?: string;
    durationSeconds?: number;
  }
): Promise<void> => {
  try {
    const now = Date.now();
    const mcqRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync/activeMcq`);
    await set(mcqRef, cleanRtdbPayload({
      isOpen: true,
      chapterId: mcqData.chapterId || '',
      chapterTitle: mcqData.chapterTitle || '',
      questionIndex: mcqData.questionIndex,
      totalQuestions: mcqData.totalQuestions,
      questionText: mcqData.questionText,
      options: mcqData.options,
      correctIndex: mcqData.correctIndex,
      explanation: mcqData.explanation || '',
      status: 'QUESTION',
      startTime: now,
      durationSeconds: mcqData.durationSeconds || 25,
      studentAnswers: {},
    }));
    // Update room lastActive
    await update(ref(rtdb, `group_study_rooms/${roomId}`), {
      lastActive: now,
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('Failed to broadcast host MCQ:', err);
  }
};

export const submitStudentLiveAnswer = async (
  roomId: string,
  student: { id: string; name: string; photoURL?: string },
  selectedOption: number,
  isCorrect: boolean,
  timeTaken: number
): Promise<void> => {
  try {
    const answerRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync/activeMcq/studentAnswers/${student.id}`);
    await set(answerRef, {
      studentName: student.name,
      studentPhoto: student.photoURL || '',
      selectedOption,
      isCorrect,
      timeTaken,
      timestamp: Date.now(),
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('Failed to submit student live answer:', err);
  }
};

export const revealHostMcqAnswer = async (roomId: string): Promise<void> => {
  try {
    const statusRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync/activeMcq/status`);
    await set(statusRef, 'REVEAL');
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('Failed to reveal MCQ answer:', err);
  }
};

export const closeHostMcq = async (roomId: string): Promise<void> => {
  try {
    const mcqRef = ref(rtdb, `group_study_rooms/${roomId}/hostSync/activeMcq`);
    await update(mcqRef, {
      isOpen: false,
      status: 'ENDED',
    });
  } catch (err: any) {
    const msg = String(err?.message || err || '');
    if (msg.includes('PERMISSION_DENIED') || msg.includes('Permission denied')) {
      return;
    }
    console.warn('Failed to close host MCQ:', err);
  }
};

