import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { buildSubColorsFromHex } from '../utils/tierTheme';
import { useAppTheme } from '../utils/themeContext';
import { Send, MessageSquare, Shield, Users, X, Trash2, Crown, Zap, Lock, Megaphone, BookOpen, CheckCircle, ThumbsUp, ThumbsDown, Award, Flag, ChevronDown, ChevronUp, MessageCircle, Globe, ArrowLeft, Search, Plus } from 'lucide-react';
import { ref, onValue, query, limitToLast, remove, set, get } from 'firebase/database';
import { rtdb } from '../firebase';
import { TopBarEffectsLayer } from '../utils/topBarEffects';
import { CommunityPostFeed } from './CommunityPostFeed';
import { McqHub } from './McqHub';
import { extractStatements } from '../utils/mcqParser';
import { logScoreActivity } from '../utils/scoreSystem';

interface Props {
    user: User;
    onClose: () => void;
    isAdmin?: boolean;
    targetUser?: User;
    roomId?: string;
    roomName?: string;
    allowStudentMcq?: boolean;
    initialMcqDraft?: { question: string; statements?: string[]; options: [string,string,string,string] | string[]; correctAnswer: number; explanation: string };
    defaultTab?: 'GLOBAL' | 'MCQ' | 'SUPPORT';
    hideGlobalTab?: boolean;
    hideSupportTab?: boolean;
    isFeedOnly?: boolean;
    isMcqOnly?: boolean;
    isSupportOnly?: boolean;
    onSpendCoins?: (amount: number) => boolean;
    onSpendDiamonds?: (amount: number) => boolean;
    onUpdateUser?: (updatedUser: User) => void;
    themeColor?: string; // Optional override color from admin settings or user redeem code
    onRestoreBottomNav?: () => void;
    isBottomNavVisible?: boolean;
    appLogo?: string;
    appName?: string;
    initialCommunityFilter?: 'ALL' | 'OFFICIAL' | 'BUG_REPORT' | 'DOUBT' | 'MINE' | 'UNDER_REVIEW' | 'NOTES_FIX';
}

interface McqDraft {
    question: string;
    statements?: string[];
    options: [string, string, string, string];
    correctAnswer: number;
    explanation: string;
}

const EMPTY_MCQ: McqDraft = { question: '', statements: undefined, options: ['', '', '', ''], correctAnswer: 0, explanation: '' };

export const UniversalChat: React.FC<Props> = ({ user, onClose, isAdmin, targetUser, roomId, roomName, allowStudentMcq, initialMcqDraft, defaultTab, hideGlobalTab, hideSupportTab, isFeedOnly, isMcqOnly, isSupportOnly, onSpendCoins, onSpendDiamonds, onUpdateUser, themeColor, onRestoreBottomNav, isBottomNavVisible = false, appLogo, appName, initialCommunityFilter }) => {
    const appTheme = useAppTheme();
    // Determine effective color: prop override > subscription tier
    const _baseSubColor = (user.subscriptionLevel === 'ULTRA' && user.isPremium) ? '#1d4ed8'
        : (user.subscriptionLevel === 'BASIC' && user.isPremium) ? '#2563eb'
        : '#0ea5e9';
    const _effectiveColor = themeColor || _baseSubColor;
    const { subColor, subColorLight, subColorBorder } = themeColor
        ? buildSubColorsFromHex(_effectiveColor)
        : {
            subColor: _baseSubColor,
            subColorLight: (user.subscriptionLevel === 'ULTRA' && user.isPremium) ? 'rgba(29,78,216,0.08)'
                : (user.subscriptionLevel === 'BASIC' && user.isPremium) ? 'rgba(37,99,235,0.08)'
                : 'rgba(14,165,233,0.08)',
            subColorBorder: (user.subscriptionLevel === 'ULTRA' && user.isPremium) ? 'rgba(29,78,216,0.30)'
                : (user.subscriptionLevel === 'BASIC' && user.isPremium) ? 'rgba(37,99,235,0.30)'
                : 'rgba(14,165,233,0.28)',
          };
    // Open to ALL users (Free, Basic, Ultra) for community posts & chat
    const isUltraChatUser = true;
    // Community MCQ posting is now open for ALL users (Free, Basic, Ultra)
    const canSendMcq = isAdmin || allowStudentMcq !== false;
    const isSubscriber = true;
    const [activeTab, setActiveTab] = useState<'GLOBAL' | 'SUPPORT' | 'MCQ'>(
        isFeedOnly ? 'GLOBAL' : isMcqOnly ? 'MCQ' : isSupportOnly ? 'SUPPORT' : (defaultTab || (hideGlobalTab ? 'MCQ' : 'GLOBAL'))
    );
    const [supportCurrency, setSupportCurrency] = useState<'CREDITS' | 'DIAMONDS'>('CREDITS');
    const [mcqVotes, setMcqVotes] = useState<Record<string, Record<string, number>>>({});
    const [mcqDailyCount, setMcqDailyCount] = useState(0);
    const [messages, setMessages] = useState<any[]>([]);
    const [input, setInput] = useState('');
    const [showMcqBuilder, setShowMcqBuilder] = useState(!!initialMcqDraft);
    const [mcqDraft, setMcqDraft] = useState<McqDraft>(() => {
        if (initialMcqDraft) {
            const opts = (initialMcqDraft.options || []).length === 4
                ? initialMcqDraft.options as [string, string, string, string]
                : ([...(initialMcqDraft.options || []), '', '', '', ''].slice(0, 4) as [string, string, string, string]);
            return {
                question: initialMcqDraft.question,
                statements: initialMcqDraft.statements,
                options: opts,
                correctAnswer: initialMcqDraft.correctAnswer,
                explanation: initialMcqDraft.explanation,
            };
        }
        return EMPTY_MCQ;
    });

    useEffect(() => {
        if (initialMcqDraft) {
            const opts = (initialMcqDraft.options || []).length === 4
                ? initialMcqDraft.options as [string, string, string, string]
                : ([...(initialMcqDraft.options || []), '', '', '', ''].slice(0, 4) as [string, string, string, string]);
            setMcqDraft({
                question: initialMcqDraft.question,
                statements: initialMcqDraft.statements,
                options: opts,
                correctAnswer: initialMcqDraft.correctAnswer,
                explanation: initialMcqDraft.explanation,
            });
            setShowMcqBuilder(true);
        }
    }, [initialMcqDraft]);

    // Active in Community: 30 XP per active minute (0 credit) per user mandate
    useEffect(() => {
        if (!user?.id) return;
        const communityXpTimer = setInterval(() => {
            const curXp = user?.xp || user?.totalScore || 0;
            if (onUpdateUser) {
                onUpdateUser({
                    ...user,
                    xp: curXp + 30,
                    totalScore: curXp + 30,
                });
            }
            try {
                logScoreActivity(user.id, 'COMMUNITY_ACTIVE_TIME', 30, 'Community Active Minute');
            } catch (_) {}
        }, 60000);

        return () => clearInterval(communityXpTimer);
    }, [user?.id, user, onUpdateUser]);
    const [showMcqLeaderboard, setShowMcqLeaderboard] = useState(true);
    const [isAdminOnly, setIsAdminOnly] = useState(false);
    const [selectedUserProfile, setSelectedUserProfile] = useState<{name: string; id: string; role: string} | null>(null);
    const [answerRevealed, setAnswerRevealed] = useState<Record<string, boolean>>({});
    const [replyTarget, setReplyTarget] = useState<any | null>(null);
    const [mcqUpvotes, setMcqUpvotes] = useState<Record<string, number>>({});
    const [myUpvotes, setMyUpvotes] = useState<Set<string>>(new Set());
    const [msgLikes, setMsgLikes] = useState<Record<string, number>>({});
    const [msgDislikes, setMsgDislikes] = useState<Record<string, number>>({});
    const [myMsgReaction, setMyMsgReaction] = useState<Record<string, 'like' | 'dislike'>>({});
    const [showTopContribs, setShowTopContribs] = useState(true);
    const [communitySearchOpen, setCommunitySearchOpen] = useState(false);
    const [communitySearchQuery, setCommunitySearchQuery] = useState('');
    const [communityComposerOpen, setCommunityComposerOpen] = useState(false);
    const dummyRef = useRef<HTMLDivElement>(null);
    const upvotingRef = useRef<Set<string>>(new Set());
    const reactingRef = useRef<Set<string>>(new Set());
    const isAdminOrSub = user.role === 'ADMIN' || user.role === 'SUB_ADMIN';

    if (isMcqOnly) {
        return (
            <div className="w-full h-full bg-slate-900 flex flex-col min-h-0 overflow-y-auto overscroll-contain">
                <McqHub
                    user={user}
                    onBack={onClose}
                    initialMcqDraft={initialMcqDraft}
                />
            </div>
        );
    }

    const chatPath = roomId
        ? `chat/rooms/${roomId}`
        : activeTab === 'SUPPORT'
            ? `chat/dm/${isAdmin ? targetUser?.id : user.id}`
            : 'chat/universal';
    const broadcastPath = 'chat/universal';

    useEffect(() => {
        if (activeTab === 'SUPPORT' && isAdmin && !targetUser && !roomId) return;
        const q = query(ref(rtdb, chatPath), limitToLast(80));
        const unsub = onValue(q, (snap) => {
            const data = snap.val();
            if (data) {
                const list = Object.entries(data).map(([k, v]: any) => ({ id: k, ...v }));
                list.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
                setMessages(list);
            } else {
                setMessages([]);
            }
        });
        return () => unsub();
    }, [chatPath, activeTab, isAdmin, targetUser]);

    // Listen to MCQ upvotes from Firebase
    useEffect(() => {
        const upvotesRef = ref(rtdb, 'chat/mcq_upvotes');
        const unsub = onValue(upvotesRef, (snap) => {
            const data = snap.val() || {};
            const counts: Record<string, number> = {};
            const mine = new Set<string>();
            Object.entries(data).forEach(([msgId, voters]: any) => {
                if (typeof voters === 'object') {
                    counts[msgId] = Object.keys(voters).length;
                    if (voters[user.id]) mine.add(msgId);
                }
            });
            setMcqUpvotes(counts);
            setMyUpvotes(mine);
        });
        return () => unsub();
    }, [user.id]);

    // Listen to message reactions (like/dislike) for all messages
    useEffect(() => {
        const rRef = ref(rtdb, 'chat/msg_reactions');
        const unsub = onValue(rRef, (snap) => {
            const data = snap.val() || {};
            const likes: Record<string, number> = {};
            const dislikes: Record<string, number> = {};
            const mine: Record<string, 'like' | 'dislike'> = {};
            Object.entries(data).forEach(([msgId, voters]: any) => {
                if (typeof voters === 'object') {
                    Object.entries(voters).forEach(([uid, reaction]: any) => {
                        if (reaction === 'like') likes[msgId] = (likes[msgId] || 0) + 1;
                        else if (reaction === 'dislike') dislikes[msgId] = (dislikes[msgId] || 0) + 1;
                        if (uid === user.id) mine[msgId] = reaction;
                    });
                }
            });
            setMsgLikes(likes);
            setMsgDislikes(dislikes);
            setMyMsgReaction(mine);
        });
        return () => unsub();
    }, [user.id]);

    // Load MCQ answer votes from localStorage on mount
    useEffect(() => {
        const allVotes: Record<string, Record<string, number>> = {};
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith('mcq_vote_')) {
                const msgId = k.replace('mcq_vote_', '');
                try { allVotes[msgId] = JSON.parse(localStorage.getItem(k) || '{}'); } catch {}
            }
        }
        setMcqVotes(allVotes);
    }, []);

    // Track daily MCQ send count — stored in localStorage (no Firebase rules needed)
    useEffect(() => {
        const today = new Date().toISOString().slice(0, 10);
        const key = `mcq_daily_${today}_${user.id}`;
        const stored = parseInt(localStorage.getItem(key) || '0', 10);
        setMcqDailyCount(stored);
    }, [user.id]);

    const handleUpvote = async (msgId: string) => {
        if (upvotingRef.current.has(msgId)) return;
        upvotingRef.current.add(msgId);
        const vPath = `chat/mcq_upvotes/${msgId}/${user.id}`;
        const wasLiked = myUpvotes.has(msgId);
        // Optimistic update — show count change immediately
        setMyUpvotes(prev => {
            const next = new Set(prev);
            if (wasLiked) next.delete(msgId); else next.add(msgId);
            return next;
        });
        setMcqUpvotes(prev => ({
            ...prev,
            [msgId]: Math.max(0, (prev[msgId] || 0) + (wasLiked ? -1 : 1)),
        }));
        try {
            if (wasLiked) {
                await remove(ref(rtdb, vPath));
            } else {
                await set(ref(rtdb, vPath), true);
            }
        } catch (e) {
            console.error('Upvote failed', e);
            // Revert optimistic update on failure
            setMyUpvotes(prev => {
                const next = new Set(prev);
                if (wasLiked) next.add(msgId); else next.delete(msgId);
                return next;
            });
            setMcqUpvotes(prev => ({
                ...prev,
                [msgId]: Math.max(0, (prev[msgId] || 0) + (wasLiked ? 1 : -1)),
            }));
        } finally {
            setTimeout(() => upvotingRef.current.delete(msgId), 800);
        }
    };

    // Like / dislike any message (TEXT, BROADCAST, MCQ dislike)
    const handleMsgReact = async (msgId: string, type: 'like' | 'dislike') => {
        const key = `${msgId}_${type}`;
        if (reactingRef.current.has(key)) return;
        reactingRef.current.add(key);
        const vPath = `chat/msg_reactions/${msgId}/${user.id}`;
        const current = myMsgReaction[msgId];
        // Optimistic update — show count change immediately
        const toggling = current === type; // clicking same button = toggle off
        setMyMsgReaction(prev => {
            const next = { ...prev };
            if (toggling) delete next[msgId]; else next[msgId] = type;
            return next;
        });
        if (type === 'like') {
            setMsgLikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + (toggling ? -1 : 1)) }));
            if (current === 'dislike') setMsgDislikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) - 1) }));
        } else {
            setMsgDislikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + (toggling ? -1 : 1)) }));
            if (current === 'like') setMsgLikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) - 1) }));
        }
        try {
            if (toggling) {
                await remove(ref(rtdb, vPath));
            } else {
                await set(ref(rtdb, vPath), type);
            }
        } catch (e) {
            console.error('React failed', e);
            // Revert optimistic update on failure
            setMyMsgReaction(prev => {
                const next = { ...prev };
                if (current) next[msgId] = current; else delete next[msgId];
                return next;
            });
            if (type === 'like') {
                setMsgLikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + (toggling ? 1 : -1)) }));
                if (current === 'dislike') setMsgDislikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + 1) }));
            } else {
                setMsgDislikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + (toggling ? 1 : -1)) }));
                if (current === 'like') setMsgLikes(prev => ({ ...prev, [msgId]: Math.max(0, (prev[msgId] || 0) + 1) }));
            }
        } finally { setTimeout(() => reactingRef.current.delete(key), 800); }
    };

    useEffect(() => {
        dummyRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const genId = () => `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;

    const buildBase = (extra: any = {}) => ({
        id: genId(),
        userId: user.id || 'anon',
        userName: user.name || 'User',
        role: user.role || 'STUDENT',
        subscriptionLevel: user.subscriptionLevel || 'FREE',
        isPremium: !!user.isPremium,
        subscriptionTier: user.subscriptionTier || 'FREE',
        timestamp: new Date().toISOString(),
        ...extra,
    });

    const normalizeLevel = (msg: any) => {
        const raw = String(msg.subscriptionLevel || msg.subscriptionTier || (msg.isPremium ? 'PREMIUM' : 'FREE')).toUpperCase();
        if (raw === 'ULTRA') return 'ULTRA';
        if (raw === 'PREMIUM') return 'PREMIUM';
        if (raw === 'BASIC') return 'BASIC';
        return 'FREE';
    };

    const cleanMessage = (msg: any) => {
        const out: any = {};
        Object.entries(msg).forEach(([key, value]) => {
            if (value !== undefined) out[key] = value;
        });
        return out;
    };

    const SUPPORT_COIN_COST = 10;
    const SUPPORT_DIAMOND_COST = 5;
    const MCQ_COIN_COST = 5;

    const handleSendText = async () => {
        const txt = input.trim();
        if (!txt) return;

        // Global chat check: Only Ultra users and Admin can send
        if (activeTab === 'GLOBAL' && !isAdminOrSub && !isUltraChatUser) {
            alert('🔒 Global chat mein message sirf Ultra users bhej sakte hain. Free aur Basic users sabhi messages dekh aur like kar sakte hain.');
            return;
        }

        // Support chat: Free for subscribers. For Free users: 10 Credits or 5 Diamonds
        if (!isAdminOrSub && activeTab === 'SUPPORT' && !isSubscriber) {
            if (supportCurrency === 'DIAMONDS') {
                const curDia = user.diamonds ?? 0;
                if (curDia < SUPPORT_DIAMOND_COST) {
                    alert(`⚠️ Admin ko message bhejne ke liye ${SUPPORT_DIAMOND_COST} Diamonds chahiye. Aapke paas sirf ${curDia} 💎 hain.`);
                    return;
                }
                if (onSpendDiamonds) {
                    const ok = onSpendDiamonds(SUPPORT_DIAMOND_COST);
                    if (!ok) return;
                } else if (onUpdateUser) {
                    onUpdateUser({ ...user, diamonds: Math.max(0, curDia - SUPPORT_DIAMOND_COST) });
                }
            } else {
                const curCr = (user.credits || 0) + (user.bonusCredits || 0);
                if (curCr < SUPPORT_COIN_COST) {
                    alert(`⚠️ Admin ko message bhejne ke liye ${SUPPORT_COIN_COST} Coins chahiye. Aapke paas sirf ${curCr} 🪙 hain.`);
                    return;
                }
                if (onSpendCoins) {
                    const ok = onSpendCoins(SUPPORT_COIN_COST);
                    if (!ok) return;
                } else if (onUpdateUser) {
                    onUpdateUser({ ...user, credits: Math.max(0, (user.credits || 0) - SUPPORT_COIN_COST) });
                }
            }
        }
        const replyPayload = replyTarget ? {
            id: replyTarget.id,
            userId: replyTarget.userId,
            userName: replyTarget.userName,
            role: replyTarget.role,
            text: replyTarget.text || '',
        } : null;
        const msg = buildBase({
            type: 'TEXT',
            text: txt,
            isAdminOnly: isAdminOrSub ? isAdminOnly : false,
            ...(replyPayload ? { replyTo: replyPayload } : {}),
        });
        try {
            await set(ref(rtdb, `${chatPath}/${msg.id}`), cleanMessage(msg));
            setInput('');
            setIsAdminOnly(false);
            setReplyTarget(null);
        } catch (e: any) { alert('Send failed: ' + e.message); }
    };

    const handleBroadcast = async () => {
        const txt = input.trim();
        if (!txt) return;
        const msg = buildBase({ type: 'ADMIN_BROADCAST', text: txt, isAdminOnly: false });
        try {
            await Promise.all([
                set(ref(rtdb, `${broadcastPath}/${msg.id}`), cleanMessage(msg)),
                set(ref(rtdb, `${chatPath}/${msg.id}`), cleanMessage(msg)),
            ]);
            setInput('');
        } catch (e: any) { alert('Failed: ' + e.message); }
    };

    const handleMcqVote = async (msgId: string, optionIndex: number) => {
        try {
            // Store vote in localStorage — no Firebase rules needed
            const key = `mcq_vote_${msgId}`;
            const existing = JSON.parse(localStorage.getItem(key) || '{}');
            existing[user.id] = optionIndex;
            localStorage.setItem(key, JSON.stringify(existing));
            // Refresh votes state from localStorage
            setMcqVotes(prev => ({
                ...prev,
                [msgId]: { ...(prev[msgId] || {}), [user.id]: optionIndex }
            }));
        } catch (e) { console.error('MCQ vote failed', e); }
    };

    const handleSendMcq = async () => {
        if (!isAdminOrSub && mcqDailyCount >= 10) {
            alert('Aap aaj ke 10 MCQ bhej chuke hain! Kal phir aa sakte hain. 😊'); return;
        }
        let { question, statements, options, correctAnswer, explanation } = mcqDraft;
        let finalStmts = statements && statements.length > 0 ? statements : undefined;
        let cleanQ = question.trim();
        if (!finalStmts) {
            const ext = extractStatements(cleanQ);
            if (ext.statements.length > 0) {
                finalStmts = ext.statements;
                cleanQ = ext.cleanedQuestion;
            }
        }
        if (!cleanQ || options.some(o => !o.trim())) {
            alert('Question aur sare 4 options fill karo'); return;
        }
        const msg = buildBase({
            type: 'MCQ',
            text: cleanQ,
            mcqData: {
                question: cleanQ,
                statements: finalStmts,
                options,
                correctAnswer,
                explanation
            },
            isAdminOnly: isAdminOrSub ? isAdminOnly : false,
        });
        try {
            await set(ref(rtdb, `chat/universal/${msg.id}`), cleanMessage(msg));
            if (!isAdminOrSub) {
                const today = new Date().toISOString().slice(0, 10);
                const lsKey = `mcq_daily_${today}_${user.id}`;
                const newCount = mcqDailyCount + 1;
                localStorage.setItem(lsKey, String(newCount));
                setMcqDailyCount(newCount);
            }
            setMcqDraft(EMPTY_MCQ);
            setShowMcqBuilder(false);
            setIsAdminOnly(false);
            // Close the popup so user stays where they were
            onClose();
        } catch (e: any) { alert('Send failed: ' + e.message); }
    };

    const handleDelete = async (msgId: string, msgUserId: string) => {
        if (!isAdminOrSub && user.id !== msgUserId) return;
        if (!confirm('Delete this message?')) return;
        try { await remove(ref(rtdb, `${chatPath}/${msgId}`)); }
        catch (e) { console.error(e); }
    };

    const getBubbleStyle = (msg: any, isMe: boolean) => {
        const level = normalizeLevel(msg);
        const corner = isMe ? 'rounded-tr-none' : 'rounded-tl-none';
        // Admin / SUB_ADMIN always show their role colour regardless of isMe
        if (msg.type === 'ADMIN_BROADCAST' || msg.role === 'ADMIN') return `bg-slate-950 text-white border border-blue-500 ${corner} shadow-[0_0_18px_rgba(30,64,175,0.45)]`;
        if (msg.role === 'SUB_ADMIN') return `bg-indigo-900 text-white border border-indigo-400 ${corner} shadow-md`;
        // Regular users — colour by subscription tier (same for isMe and others)
        if (level === 'ULTRA') return `bg-blue-900 text-white border border-blue-700 ${corner} shadow-sm`;
        if (level === 'BASIC') return `bg-sky-200 text-sky-900 border border-sky-300 ${corner}`;
        // FREE / default → gray
        return `bg-slate-200 text-slate-700 border border-slate-300 ${corner}`;
    };

    const getRoleBadge = (msg: any) => {
        const level = normalizeLevel(msg);
        if (msg.role === 'ADMIN') return <span className="bg-blue-950 text-white border border-blue-400 px-1.5 rounded text-[8px] font-black">ADMIN</span>;
        if (msg.role === 'SUB_ADMIN') return <span className="bg-indigo-500 text-white px-1.5 rounded text-[8px] font-bold">MOD</span>;
        if (level === 'ULTRA') return <span className="bg-sky-500 text-white px-1.5 rounded text-[8px] font-black">ULTRA</span>;
        if (level === 'PREMIUM') return <span className="bg-amber-500 text-white px-1.5 rounded text-[8px] font-black">PREMIUM</span>;
        if (level === 'BASIC') return <span className="bg-sky-400 text-white px-1.5 rounded text-[8px] font-black">BASIC</span>;
        if (level === 'FREE') return <span className="bg-slate-400 text-white px-1.5 rounded text-[8px] font-black">FREE</span>;
        return null;
    };

    const getNameColor = (msg: any) => {
        const level = normalizeLevel(msg);
        if (msg.role === 'ADMIN') return 'text-blue-300';
        if (msg.role === 'SUB_ADMIN') return 'text-indigo-300';
        if (level === 'ULTRA') return 'text-sky-500';
        if (msg.subscriptionLevel === 'PREMIUM') return 'text-amber-500';
        if (level === 'BASIC') return 'text-sky-400';
        return 'text-slate-400';
    };

    const getNameBadge = (msg: any) => {
        const level = normalizeLevel(msg);
        if (msg.role === 'ADMIN') return <span className="bg-blue-950 text-white border border-blue-400 px-1.5 py-0.5 rounded text-[8px] font-black">ADMIN</span>;
        if (msg.role === 'SUB_ADMIN') return <span className="bg-indigo-500 text-white px-1.5 py-0.5 rounded text-[8px] font-black">MOD</span>;
        if (level === 'ULTRA') return <span className="bg-sky-500 text-white px-1.5 py-0.5 rounded text-[8px] font-black">ULTRA</span>;
        if (level === 'PREMIUM') return <span className="bg-amber-500 text-white px-1.5 py-0.5 rounded text-[8px] font-black">PREMIUM</span>;
        if (level === 'BASIC') return <span className="bg-sky-400 text-white px-1.5 py-0.5 rounded text-[8px] font-black">BASIC</span>;
        return <span className="bg-slate-400 text-white px-1.5 py-0.5 rounded text-[8px] font-black">FREE</span>;
    };

    const visibleMessages = activeTab === 'MCQ'
        ? messages.filter(msg => msg.type === 'MCQ')
        : activeTab === 'GLOBAL'
            ? messages.filter(msg => (!msg.isAdminOnly || isAdminOrSub) && msg.type !== 'MCQ')
            : messages.filter(msg => !msg.isAdminOnly || isAdminOrSub);
    const canReply = activeTab === 'MCQ' || activeTab === 'SUPPORT' || !!roomId || isAdminOrSub;

    return (
        <div className="fixed inset-0 z-[170] bg-slate-900/90 backdrop-blur-sm flex items-stretch justify-stretch p-0">

            {/* Profile popup */}
            {selectedUserProfile && (
                <div className="absolute inset-0 z-[110] flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setSelectedUserProfile(null)}>
                    <div className="bg-white p-6 rounded-2xl shadow-2xl text-center animate-in zoom-in-95 max-w-xs w-full" onClick={e => e.stopPropagation()}>
                        <div className="w-16 h-16 bg-slate-100 rounded-full mx-auto mb-3 flex items-center justify-center text-2xl font-bold text-slate-600">
                            {selectedUserProfile.name.charAt(0)}
                        </div>
                        <h3 className="text-lg font-black text-slate-800">{selectedUserProfile.name}</h3>
                        <p className="text-xs text-slate-600 font-mono mb-2">ID: {selectedUserProfile.id}</p>
                        <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-bold uppercase">{selectedUserProfile.role}</span>
                    </div>
                </div>
            )}

            <div className={`w-full h-full flex flex-col overflow-hidden ${isBottomNavVisible ? 'pb-[64px]' : ''}`} style={{ background: appTheme.appBgColor || appTheme.profileBg || '#ffffff' }}>

                {/* Unified Single Top Bar: Combines Header + Navigation Tabs */}
                <div
                    className="text-white px-2.5 py-2 flex items-center justify-between gap-2 shrink-0 shadow-sm"
                    style={{ background: appTheme.topBarGrad || '#0f172a' }}
                >
                    <div className="flex items-center gap-1 shrink-0">
                        {onClose && (
                            <button
                                type="button"
                                onClick={onClose}
                                className="p-1.5 -ml-0.5 hover:bg-white/10 rounded-full transition-colors cursor-pointer active:scale-95 text-white shrink-0"
                                title="Back"
                                aria-label="Back"
                            >
                                <ArrowLeft size={18} />
                            </button>
                        )}
                    </div>

                    {/* Integrated Tab Pills or Community Header inside the single top bar */}
                    {communitySearchOpen && (activeTab === 'GLOBAL' || isFeedOnly) ? (
                        <div className="flex-1 flex items-center gap-2 bg-white/15 px-2.5 py-1 rounded-xl border border-white/25 min-w-0">
                            <Search size={15} className="text-white/80 shrink-0" />
                            <input
                                type="text"
                                value={communitySearchQuery}
                                onChange={(e) => setCommunitySearchQuery(e.target.value)}
                                placeholder="Search posts or students..."
                                className="w-full bg-transparent text-white placeholder-white/60 text-xs focus:outline-none"
                                autoFocus
                            />
                            {communitySearchQuery && (
                                <button
                                    type="button"
                                    onClick={() => setCommunitySearchQuery('')}
                                    className="text-white/70 hover:text-white p-0.5"
                                >
                                    <X size={13} />
                                </button>
                            )}
                            <button
                                type="button"
                                onClick={() => {
                                    setCommunitySearchOpen(false);
                                    setCommunitySearchQuery('');
                                }}
                                className="text-[11px] text-white/90 hover:text-white font-bold px-1 cursor-pointer shrink-0"
                            >
                                Cancel
                            </button>
                        </div>
                    ) : (activeTab === 'GLOBAL' || isFeedOnly) ? (
                        <div className="flex-1 flex items-center justify-between gap-1 min-w-0">
                            <div className="flex items-center gap-2 min-w-0">
                                <div className="p-1.5 rounded-lg bg-white/10 text-white shrink-0">
                                    <Globe size={16} />
                                </div>
                                <span className="font-bold text-sm sm:text-base text-white truncate tracking-tight">
                                    Community
                                </span>
                                {/* Search icon right after Community */}
                                <button
                                    type="button"
                                    onClick={() => setCommunitySearchOpen(true)}
                                    className="p-1.5 hover:bg-white/15 rounded-lg text-white/90 hover:text-white transition-all cursor-pointer active:scale-95 shrink-0"
                                    title="Search posts"
                                    aria-label="Search posts"
                                >
                                    <Search size={16} />
                                </button>
                                {/* + icon to add new post right after search */}
                                <button
                                    type="button"
                                    onClick={() => setCommunityComposerOpen((prev) => !prev)}
                                    className="p-1.5 hover:bg-white/15 rounded-lg text-white/90 hover:text-white transition-all cursor-pointer active:scale-95 shrink-0"
                                    title="Naya Post Add Karein"
                                    aria-label="Naya Post"
                                >
                                    <Plus size={18} />
                                </button>
                            </div>
                        </div>
                    ) : !roomId && !isMcqOnly && !isSupportOnly && !isFeedOnly ? (
                        <div className="flex-1 flex items-center justify-center gap-1 max-w-sm mx-auto bg-black/25 p-1 rounded-xl border border-white/10">
                            {!hideGlobalTab && (
                                <button
                                    type="button"
                                    onClick={() => setActiveTab('GLOBAL')}
                                    className={`flex-1 py-1.5 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none ${
                                        activeTab === 'GLOBAL'
                                            ? 'bg-purple-600 text-white shadow-sm'
                                            : 'text-white/70 hover:text-white hover:bg-white/5'
                                    }`}
                                >
                                    <Globe size={13} />
                                    <span>Community</span>
                                </button>
                            )}
                            <button
                                type="button"
                                onClick={() => setActiveTab('MCQ')}
                                className={`flex-1 py-1.5 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer select-none relative ${
                                    activeTab === 'MCQ'
                                        ? 'bg-blue-600 text-white shadow-sm'
                                        : 'text-white/70 hover:text-white hover:bg-white/5'
                                }`}
                            >
                                <BookOpen size={13} />
                                <span>MCQs</span>
                                {!isAdminOrSub && mcqDailyCount > 0 && (
                                    <span className="text-[9px] bg-amber-400 text-slate-950 font-black rounded-full px-1 py-0.2 ml-0.5">
                                        {mcqDailyCount}/10
                                    </span>
                                )}
                            </button>
                            {!hideSupportTab && (
                                <button
                                    type="button"
                                    onClick={() => setActiveTab('SUPPORT')}
                                    className={`flex-1 py-1.5 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer select-none ${
                                        activeTab === 'SUPPORT'
                                            ? 'bg-emerald-600 text-white shadow-sm'
                                            : 'text-white/70 hover:text-white hover:bg-white/5'
                                    }`}
                                >
                                    <Shield size={13} />
                                    <span>{isAdmin ? 'DMs' : 'Help'}</span>
                                </button>
                            )}
                        </div>
                    ) : (
                        <div className="flex-1 flex items-center gap-2 min-w-0">
                            <div className="p-1.5 rounded-lg bg-white/10 text-white">
                                {roomId ? <MessageSquare size={16} /> : activeTab === 'MCQ' ? <BookOpen size={16} /> : <Shield size={16} />}
                            </div>
                            <div className="min-w-0">
                                <h3 className="font-bold text-xs sm:text-sm truncate">
                                    {roomId ? roomName : activeTab === 'MCQ' ? 'MCQ Community' : isAdmin ? `Chat — ${targetUser?.name || 'User'}` : 'Community Support'}
                                </h3>
                                <p className="text-[10px] text-white/70 leading-tight truncate">
                                    {activeTab === 'MCQ' ? `Daily: ${mcqDailyCount}/10 MCQ` : 'Direct Admin Support'}
                                </p>
                            </div>
                        </div>
                    )}

                    <div className="flex items-center gap-1 shrink-0">
                        {/* NSTA App icon button to toggle bottom navigation on Community / MCQ / Support */}
                        {onRestoreBottomNav && (
                            <button
                                type="button"
                                onClick={onRestoreBottomNav}
                                className={`p-1 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 px-2 active:scale-95 ${
                                    isBottomNavVisible
                                        ? 'bg-white text-slate-900 shadow-xs'
                                        : 'bg-white/15 text-white hover:bg-white/25'
                                }`}
                                title={isBottomNavVisible ? "Bottom navigation chhipayein" : "Bottom navigation dikhayein"}
                            >
                                <img
                                    src={appLogo || '/branding/nsta-logo.svg'}
                                    alt={appName || "NSTA"}
                                    className="w-5 h-5 rounded-md object-contain"
                                    onError={(e) => {
                                        (e.target as HTMLElement).style.display = 'none';
                                    }}
                                />
                                <span className="text-[10px] font-black">{appName || 'NSTA'}</span>
                            </button>
                        )}
                        {onClose && (
                            <button
                                type="button"
                                onClick={onClose}
                                className="p-1.5 hover:bg-white/10 rounded-full transition-colors cursor-pointer active:scale-95 text-white"
                                title="Close"
                                aria-label="Close"
                            >
                                <X size={18} />
                            </button>
                        )}
                    </div>
                </div>

                {/* Content: Community Post Feed (replaces Global Chat) */}
                {activeTab === 'GLOBAL' && !roomId ? (
                    <div className="flex-1 overflow-hidden">
                        <CommunityPostFeed
                            user={user}
                            isAdmin={isAdminOrSub}
                            onClose={onClose}
                            isEmbedded={true}
                            initialFilter={initialCommunityFilter}
                            externalSearchQuery={communitySearchQuery}
                            onSearchQueryChange={setCommunitySearchQuery}
                            externalShowComposer={communityComposerOpen}
                            onShowComposerChange={setCommunityComposerOpen}
                        />
                    </div>
                ) : activeTab === 'SUPPORT' && isAdmin && !targetUser && !roomId ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-6 text-center">
                        <Shield size={40} className="mb-3 opacity-40" />
                        <p className="font-bold text-sm">Koi user select nahi hua</p>
                        <p className="text-xs mt-1 text-slate-400">Admin panel → Users list se kisi user ka "Chat" button dabao</p>
                    </div>
                ) : (
                    <>
                        {/* MCQ LEADERBOARD — hidden from community MCQ tab */}

                        {/* TOP CONTRIBUTORS BANNER — shown only in Global tab */}
                        {activeTab === 'GLOBAL' && !roomId && (() => {
                            const today = new Date().toDateString();
                            const todayMcqs = visibleMessages.filter(m => m.type === 'MCQ' && new Date(m.timestamp).toDateString() === today);
                            const contribMap: Record<string, {name: string; count: number; upvotes: number}> = {};
                            todayMcqs.forEach(m => {
                                if (!contribMap[m.userId]) contribMap[m.userId] = { name: m.userName, count: 0, upvotes: 0 };
                                contribMap[m.userId].count++;
                                contribMap[m.userId].upvotes += (mcqUpvotes[m.id] || 0);
                            });
                            const contribs = Object.entries(contribMap)
                                .map(([id, v]) => ({ id, ...v }))
                                .sort((a, b) => (b.count + b.upvotes) - (a.count + a.upvotes))
                                .slice(0, 3);
                            if (contribs.length === 0) return null;
                            const medals = ['🥇','🥈','🥉'];
                            return (
                                <div className="mx-3 mt-3 mb-0 rounded-2xl overflow-hidden border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50">
                                    <button
                                        className="w-full flex items-center justify-between px-3 py-2"
                                        onClick={() => setShowTopContribs(v => !v)}
                                    >
                                        <div className="flex items-center gap-2">
                                            <Award size={14} className="text-amber-600" />
                                            <span className="text-[11px] font-black text-amber-800 uppercase tracking-wider">Top Contributors Today</span>
                                        </div>
                                        {showTopContribs ? <ChevronUp size={14} className="text-amber-600" /> : <ChevronDown size={14} className="text-amber-600" />}
                                    </button>
                                    {showTopContribs && (
                                        <div className="px-3 pb-2.5 flex gap-2">
                                            {contribs.map((c, i) => (
                                                <div key={c.id} className="flex-1 bg-white rounded-xl px-2 py-2 text-center border border-amber-100 shadow-sm">
                                                    <p className="text-lg leading-none mb-0.5">{medals[i]}</p>
                                                    <p className="text-[10px] font-black text-slate-800 truncate">{c.name.split(' ')[0]}</p>
                                                    <p className="text-[9px] font-bold text-amber-600">{c.count} MCQ{c.count > 1 ? 's' : ''}</p>
                                                    {c.upvotes > 0 && <p className="text-[8px] text-slate-400">👍 {c.upvotes}</p>}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })()}

                {/* Messages or MCQ Hub */}
                {activeTab === 'MCQ' ? (
                    <div className="flex-1 overflow-y-auto flex flex-col min-h-0">
                        <McqHub
                            user={user}
                            onBack={() => setActiveTab('GLOBAL')}
                            initialMcqDraft={initialMcqDraft}
                        />
                    </div>
                ) : (
                    <div
                        className="flex-1 overflow-y-auto p-3 space-y-3 pb-3.5"
                        style={{ background: appTheme.appBgColor || appTheme.profileBg || '#f8fafc' }}
                    >
                        {visibleMessages.length === 0 && (
                            <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-2">
                                <MessageSquare size={40} className="opacity-40" />
                                <p className="text-xs">Koi message nahi. Pehla message bhejo!</p>
                            </div>
                        )}

                        {visibleMessages.map((msg) => {
                            const isMe = msg.userId === user.id;
                            return (
                                <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group`}>

                                        {msg.isAdminOnly && isAdminOrSub && (
                                            <div className="flex items-center gap-1 mb-0.5 px-1">
                                                <Lock size={9} className="text-amber-500" />
                                                <span className="text-[9px] font-bold text-amber-500">ADMIN ONLY</span>
                                            </div>
                                        )}

                                        <div className={`max-w-[92%] rounded-2xl px-4 py-3.5 text-sm relative overflow-hidden ${getBubbleStyle(msg, isMe)} ${msg.type === 'ADMIN_BROADCAST' || msg.role === 'ADMIN' ? 'admin-dark-bubble' : ''}`}>
                                            {/* TopBar animated effect on admin/broadcast messages */}
                                            {(msg.role === 'ADMIN' || msg.role === 'SUB_ADMIN') && (
                                                <TopBarEffectsLayer effects={[
                                                    { id: 'shimmer-gold', enabled: true, color: msg.role === 'ADMIN' ? '#a78bfa' : '#818cf8', speed: 1.2 },
                                                    { id: 'glow-both',    enabled: true, color: msg.role === 'ADMIN' ? '#a78bfa' : '#818cf8', speed: 1.5 },
                                                ]} />
                                            )}
                                            {msg.type === 'ADMIN_BROADCAST' && (
                                                <TopBarEffectsLayer effects={[
                                                    { id: 'shimmer-gold', enabled: true, color: '#fbbf24', speed: 1.0 },
                                                ]} />
                                            )}
                                            {/* Delete — admin sees on all, user sees only on own */}
                                            {(isAdminOrSub || isMe) && (
                                                <button
                                                    onClick={() => handleDelete(msg.id, msg.userId)}
                                                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm z-10"
                                                >
                                                    <Trash2 size={10} />
                                                </button>
                                            )}
                                            {/* Reply — all users, on others' messages */}
                                            {canReply && !isMe && (
                                                <button
                                                    onClick={() => setReplyTarget(msg)}
                                                    className="absolute -bottom-2 -right-2 bg-blue-600 text-white rounded-full px-2 py-1 text-[9px] font-black shadow-md"
                                                >
                                                    Reply
                                                </button>
                                            )}

                                            {/* Sender name */}
                                            {!isMe && (
                                                <div
                                                    className="flex items-center gap-1 mb-1 cursor-pointer"
                                                    onClick={() => setSelectedUserProfile({ name: msg.userName, id: msg.userId, role: msg.role })}
                                                >
                                                    <p className={`text-[9px] font-bold ${getNameColor(msg)} ${msg.type === 'ADMIN_BROADCAST' || msg.role === 'ADMIN' ? 'admin-name' : ''}`}>
                                                        {msg.userName}
                                                    </p>
                                                    <div className={msg.type === 'ADMIN_BROADCAST' || msg.role === 'ADMIN' ? 'admin-badge' : ''}>
                                                        {getNameBadge(msg)}
                                                    </div>
                                                </div>
                                            )}
                                            {msg.replyTo && (
                                                <div className="mb-2 rounded-lg border-l-4 border-blue-300 bg-white/60 px-2 py-1 text-[10px] text-slate-600">
                                                    <div className="font-bold text-blue-600">{msg.replyTo.userName}</div>
                                                    <div className="truncate">{msg.replyTo.text}</div>
                                                </div>
                                            )}
                                            {msg.isPremium && (
                                                <div className="mb-1 flex items-center gap-1 text-[9px] font-black uppercase tracking-wider" style={{ color: subColor }}>
                                                    <Crown size={10} style={{ fill: subColor }} /> Premium
                                                </div>
                                            )}
                                            {(msg.role === 'ADMIN' || msg.role === 'SUB_ADMIN') && !msg.isPremium && (
                                                <div className="mb-1 flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-blue-300">
                                                    <Shield size={10} className="text-blue-300" /> Admin
                                                </div>
                                            )}

                                            {/* TEXT */}
                                            {(msg.type === 'TEXT' || !msg.type) && (
                                                <>
                                                    <p className="leading-relaxed break-words whitespace-pre-wrap">{msg.text}</p>
                                                    <div className="flex items-center gap-1.5 mt-2">
                                                        <button
                                                            onClick={() => handleMsgReact(msg.id, 'like')}
                                                            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myMsgReaction[msg.id] === 'like' ? 'bg-green-500 text-white' : 'bg-white/20 hover:bg-green-100 hover:text-green-700 text-inherit'}`}
                                                        >
                                                            <ThumbsUp size={10} className={myMsgReaction[msg.id] === 'like' ? 'fill-white' : ''} />
                                                            <span>{msgLikes[msg.id] || 0}</span>
                                                        </button>
                                                        <button
                                                            onClick={() => handleMsgReact(msg.id, 'dislike')}
                                                            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myMsgReaction[msg.id] === 'dislike' ? 'bg-red-500 text-white' : 'bg-white/20 hover:bg-red-100 hover:text-red-600 text-inherit'}`}
                                                        >
                                                            <ThumbsDown size={10} className={myMsgReaction[msg.id] === 'dislike' ? 'fill-white' : ''} />
                                                            <span>{msgDislikes[msg.id] || 0}</span>
                                                        </button>
                                                    </div>
                                                </>
                                            )}

                                            {/* ADMIN BROADCAST */}
                                            {msg.type === 'ADMIN_BROADCAST' && (
                                                <>
                                                    <div className="flex items-start gap-2">
                                                        <Megaphone size={14} className="text-blue-300 shrink-0 mt-0.5" />
                                                        <p className="leading-relaxed font-semibold text-white">{msg.text}</p>
                                                    </div>
                                                    <div className="flex items-center gap-1.5 mt-2">
                                                        <button
                                                            onClick={() => handleMsgReact(msg.id, 'like')}
                                                            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myMsgReaction[msg.id] === 'like' ? 'bg-green-500 text-white' : 'bg-white/20 text-blue-200 hover:bg-green-900/40 hover:text-green-300'}`}
                                                        >
                                                            <ThumbsUp size={10} className={myMsgReaction[msg.id] === 'like' ? 'fill-white' : ''} />
                                                            <span>{msgLikes[msg.id] || 0}</span>
                                                        </button>
                                                        <button
                                                            onClick={() => handleMsgReact(msg.id, 'dislike')}
                                                            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myMsgReaction[msg.id] === 'dislike' ? 'bg-red-500 text-white' : 'bg-white/20 text-blue-200 hover:bg-red-900/40 hover:text-red-300'}`}
                                                        >
                                                            <ThumbsDown size={10} className={myMsgReaction[msg.id] === 'dislike' ? 'fill-white' : ''} />
                                                            <span>{msgDislikes[msg.id] || 0}</span>
                                                        </button>
                                                    </div>
                                                </>
                                            )}

                                            {/* MCQ — Interactive Poll with Vote Distribution */}
                                            {msg.type === 'MCQ' && msg.mcqData && (() => {
                                                const voteData = mcqVotes[msg.id] || {};
                                                const myVote = voteData[user.id];
                                                const hasVoted = myVote !== undefined;
                                                const totalVotes = Object.values(voteData).length;
                                                const optionCounts = (msg.mcqData.options || []).map((_: any, i: number) =>
                                                    Object.values(voteData).filter((v: any) => v === i).length
                                                );
                                                return (
                                                    <div className="min-w-[220px] max-w-[295px]">
                                                        <div className="flex items-center gap-1 mb-2">
                                                            <BookOpen size={11} className={isMe ? 'opacity-70' : ''} style={!isMe ? { color: subColor } : {}} />
                                                            <span className={`text-[10px] font-black uppercase tracking-wide ${isMe ? 'text-white/70' : ''}`} style={!isMe ? { color: subColor } : {}}>MCQ</span>
                                                            {totalVotes > 0 && <span className={`text-[9px] font-bold ml-auto ${isMe ? 'text-blue-200' : 'text-slate-400'}`}>{totalVotes} jawab</span>}
                                                        </div>
                                                        <p className="font-semibold text-[13px] leading-snug mb-2">{msg.mcqData.question}</p>
                                                        {(() => {
                                                            let stmts = msg.mcqData.statements;
                                                            if (!stmts || stmts.length === 0) {
                                                                const ext = extractStatements(msg.mcqData.question || '');
                                                                if (ext.statements.length > 0) stmts = ext.statements;
                                                            }
                                                            if (stmts && stmts.length > 0) {
                                                                return (
                                                                    <div className={`mb-3 p-2 rounded-lg text-xs space-y-1 ${isMe ? 'bg-blue-950/40 text-blue-100 border border-blue-400/30' : 'bg-slate-50 text-slate-700 border border-slate-200'}`}>
                                                                        {stmts.map((s: string, sIdx: number) => (
                                                                            <div key={sIdx} className="leading-relaxed font-medium">
                                                                                {s}
                                                                            </div>
                                                                        ))}
                                                                    </div>
                                                                );
                                                            }
                                                            return null;
                                                        })()}
                                                        <div className="space-y-2">
                                                            {(msg.mcqData.options || []).map((opt: string, oi: number) => {
                                                                const isPicked = myVote === oi;
                                                                const correct = oi === msg.mcqData.correctAnswer;
                                                                const pct = totalVotes > 0 ? Math.round((optionCounts[oi] / totalVotes) * 100) : 0;
                                                                if (!hasVoted) {
                                                                    return (
                                                                        <button
                                                                            key={oi}
                                                                            onClick={() => handleMcqVote(msg.id, oi)}
                                                                            className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium border transition-all active:scale-[0.98] ${isMe ? 'bg-blue-400/20 border-blue-300/50 text-blue-50 hover:bg-blue-400/30' : 'bg-white border-slate-200 text-slate-700 hover:border-violet-400 hover:bg-violet-50'}`}
                                                                        >
                                                                            <span className="font-bold mr-1.5 text-[10px]">{String.fromCharCode(65 + oi)}.</span>{opt}
                                                                        </button>
                                                                    );
                                                                }
                                                                return (
                                                                    <div key={oi} className={`rounded-xl border overflow-hidden ${correct ? 'border-green-400' : isPicked && !correct ? 'border-red-300' : 'border-slate-200'}`}>
                                                                        <div className={`relative px-3 py-2 text-xs font-medium ${correct ? 'bg-green-50 text-green-800' : isPicked && !correct ? 'bg-red-50 text-red-700' : 'bg-slate-50 text-slate-500'}`}>
                                                                            <div className="absolute inset-y-0 left-0 rounded-xl transition-all duration-700 ease-out" style={{ width: `${pct}%`, background: correct ? 'rgba(34,197,94,0.18)' : isPicked ? 'rgba(239,68,68,0.12)' : 'rgba(148,163,184,0.12)' }} />
                                                                            <div className="relative flex items-center justify-between gap-2">
                                                                                <span className="flex items-center gap-1">
                                                                                    <span className="font-bold text-[10px]">{String.fromCharCode(65 + oi)}.</span>
                                                                                    {opt}
                                                                                    {correct && <CheckCircle size={10} className="text-green-600 shrink-0" />}
                                                                                    {isPicked && !correct && <span className="text-red-500 font-black text-sm leading-none">✗</span>}
                                                                                    {isPicked && correct && <span className="text-green-600 font-black text-sm leading-none">✓</span>}
                                                                                </span>
                                                                                <span className="font-black text-[11px] shrink-0">{pct}%</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                );
                                                            })}
                                                        </div>
                                                        {!hasVoted && <p className={`mt-1.5 text-[10px] font-bold ${isMe ? 'text-white/60' : ''}`} style={!isMe ? { color: subColor } : {}}>👆 Apna jawab chunein</p>}
                                                        {hasVoted && msg.mcqData.explanation && (
                                                            <p className={`mt-2 text-[10px] italic leading-relaxed ${isMe ? 'text-blue-200' : 'text-slate-500'}`}>💡 {msg.mcqData.explanation}</p>
                                                        )}
                                                        {/* Like / Dislike row */}
                                                        <div className="mt-2.5 flex items-center gap-2 flex-wrap">
                                                            <button
                                                                onClick={() => handleUpvote(msg.id)}
                                                                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myUpvotes.has(msg.id) ? 'text-white' : isMe ? 'bg-blue-400/20 text-blue-200 hover:bg-blue-400/30' : 'bg-slate-100 text-slate-600'}`}
                                                style={myUpvotes.has(msg.id) ? { background: subColor } : (!isMe ? { ['--hover-bg' as any]: subColorLight } : {})}
                                                            >
                                                                <ThumbsUp size={10} className={myUpvotes.has(msg.id) ? 'fill-white' : ''} />
                                                                <span>{mcqUpvotes[msg.id] || 0}</span>
                                                            </button>
                                                            <button
                                                                onClick={() => handleMsgReact(msg.id, 'dislike')}
                                                                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all active:scale-95 ${myMsgReaction[msg.id] === 'dislike' ? 'bg-red-500 text-white' : isMe ? 'bg-blue-400/20 text-blue-200 hover:bg-blue-400/30' : 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-500'}`}
                                                            >
                                                                <ThumbsDown size={10} className={myMsgReaction[msg.id] === 'dislike' ? 'fill-white' : ''} />
                                                                <span>{msgDislikes[msg.id] || 0}</span>
                                                            </button>
                                                            {(mcqUpvotes[msg.id] || 0) >= 5 && (
                                                                <span className="flex items-center gap-0.5 text-[9px] font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                                                                    <Award size={9} className="text-amber-500" /> Highlighted
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        <span className="text-[9px] text-slate-400 mt-0.5 px-1">
                                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </span>
                                    </div>
                                );
                            })}
                            <div ref={dummyRef} />
                        </div>
                )}

                        {/* MCQ Builder — bottom-sheet modal */}
                        {showMcqBuilder && (
                            <div className="fixed inset-0 z-[350] flex flex-col justify-end" style={{touchAction:'none'}}>
                                {/* Backdrop */}
                                <div
                                    className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
                                    onClick={() => { setShowMcqBuilder(false); setMcqDraft(EMPTY_MCQ); }}
                                />
                                {/* Sheet */}
                                <div className="relative bg-white rounded-t-3xl shadow-2xl flex flex-col max-h-[88vh]">
                                    {/* Handle bar */}
                                    <div className="flex justify-center pt-3 pb-1 shrink-0">
                                        <div className="w-10 h-1 rounded-full bg-slate-200" />
                                    </div>
                                    {/* Header */}
                                    <div className="flex items-center justify-between px-5 pb-3 pt-1 border-b border-slate-100 shrink-0">
                                        <div>
                                            <p className="text-sm font-black text-indigo-700 flex items-center gap-2"><BookOpen size={15} /> MCQ Banao &amp; Bhejo</p>
                                            {!isAdminOrSub && (
                                                <p className={`text-[10px] font-bold mt-0.5 ${mcqDailyCount >= 10 ? 'text-red-500' : 'text-slate-400'}`}>
                                                    Aaj ke {mcqDailyCount}/10 MCQ bheje gaye (Daily limit: 10)
                                                </p>
                                            )}
                                        </div>
                                        <button
                                            onClick={() => { setShowMcqBuilder(false); setMcqDraft(EMPTY_MCQ); }}
                                            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-red-50 hover:text-red-500 transition-all"
                                        >
                                            <X size={15} />
                                        </button>
                                    </div>
                                    {/* Scrollable form body */}
                                    <div className="overflow-y-auto flex-1 px-5 py-4 space-y-3">
                                        {!isAdminOrSub && (
                                            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center gap-2">
                                                <span className="text-base text-emerald-600 font-black">✓</span>
                                                <div className="text-[11px] text-emerald-800 font-bold">
                                                    MCQ Community posting sabhi users ke liye free hai (Daily Limit: 10 MCQ)
                                                </div>
                                            </div>
                                        )}
                                        {/* Question */}
                                        <div>
                                            <label className="block text-[11px] font-black text-slate-500 mb-1 uppercase tracking-wide">Question</label>
                                            <textarea
                                                rows={3}
                                                value={mcqDraft.question}
                                                onChange={e => setMcqDraft(p => ({ ...p, question: e.target.value }))}
                                                placeholder="Apna question yahan likhein..."
                                                className="w-full p-3 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-400 focus:border-transparent outline-none resize-none leading-relaxed"
                                            />
                                        </div>
                                        {/* Statements (कथन) */}
                                        <div>
                                            <div className="flex items-center justify-between mb-1">
                                                <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wide">कथन (Statements) - यदि प्रश्न कथन वाला है</label>
                                                <span className="text-[10px] text-purple-600 font-semibold">(1 लाइन = 1 कथन)</span>
                                            </div>
                                            <textarea
                                                rows={3}
                                                value={(mcqDraft.statements || []).join('\n')}
                                                onChange={e => {
                                                    const lines = e.target.value.split('\n').map(s => s.trim()).filter(Boolean);
                                                    setMcqDraft(p => ({ ...p, statements: lines.length > 0 ? lines : undefined }));
                                                }}
                                                placeholder={`1. कथन 1\n2. कथन 2`}
                                                className="w-full p-2.5 text-xs border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-400 focus:border-transparent outline-none resize-none leading-relaxed"
                                            />
                                        </div>
                                        {/* Options */}
                                        <div>
                                            <label className="block text-[11px] font-black text-slate-500 mb-2 uppercase tracking-wide">Options <span className="normal-case text-green-600 font-bold">(sahi jawab pe tap karo ✓)</span></label>
                                            <div className="space-y-2">
                                                {mcqDraft.options.map((opt, oi) => (
                                                    <div key={oi} className={`flex gap-2.5 items-center rounded-xl border-2 px-3 py-2 transition-all ${mcqDraft.correctAnswer === oi ? 'border-green-400 bg-green-50' : 'border-slate-200 bg-white'}`}>
                                                        <button
                                                            onClick={() => setMcqDraft(p => ({ ...p, correctAnswer: oi }))}
                                                            className={`w-7 h-7 shrink-0 rounded-full border-2 flex items-center justify-center text-[11px] font-black transition-all ${mcqDraft.correctAnswer === oi ? 'bg-green-500 border-green-500 text-white shadow-sm' : 'border-slate-300 text-slate-400'}`}
                                                        >
                                                            {mcqDraft.correctAnswer === oi ? '✓' : String.fromCharCode(65 + oi)}
                                                        </button>
                                                        <input
                                                            value={opt}
                                                            onChange={e => {
                                                                const opts = [...mcqDraft.options] as [string, string, string, string];
                                                                opts[oi] = e.target.value;
                                                                setMcqDraft(p => ({ ...p, options: opts }));
                                                            }}
                                                            placeholder={`Option ${String.fromCharCode(65 + oi)}`}
                                                            className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-300"
                                                        />
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                        {/* Explanation */}
                                        <div>
                                            <label className="block text-[11px] font-black text-slate-500 mb-1 uppercase tracking-wide">Explanation <span className="normal-case text-slate-400 font-normal">(optional)</span></label>
                                            <input
                                                value={mcqDraft.explanation}
                                                onChange={e => setMcqDraft(p => ({ ...p, explanation: e.target.value }))}
                                                placeholder="Jawab ka reason ya explanation..."
                                                className="w-full p-3 text-sm border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-400 focus:border-transparent outline-none"
                                            />
                                        </div>
                                    </div>
                                    {/* Fixed send footer */}
                                    <div className="shrink-0 px-5 pt-4 pb-[calc(env(safe-area-inset-bottom,0px)+92px)] border-t border-slate-100 bg-white">
                                        {!isAdminOrSub && (
                                            <p className="text-[11px] text-emerald-600 font-bold text-center mb-2">
                                                ✓ Community MCQ posting sabhi students ke liye open hai
                                            </p>
                                        )}
                                        <button
                                            onClick={() => {
                                                if (!canSendMcq) {
                                                    alert('🔒 Community MCQ posting abhi admin ne disable ki hai.');
                                                    return;
                                                }
                                                handleSendMcq();
                                            }}
                                            className="w-full active:scale-95 text-white py-4 rounded-2xl text-sm font-black transition-all flex items-center justify-center gap-2 shadow-lg"
                                            style={{ background: subColor }}
                                        >
                                            <Send size={15} /> <span>MCQ Community Mein Bhejo</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Input area — hidden in MCQ tab (no text messages allowed) */}
                        {activeTab !== 'MCQ' && (
                        <div className="p-3 pb-2.5 pb-safe border-t border-slate-100 shrink-0 sticky bottom-0" style={{ background: appTheme.profileCardBg || '#ffffff' }}>
                            {/* Global Chat Send restriction for Free & Basic users */}
                            {activeTab === 'GLOBAL' && !isAdminOrSub && !isUltraChatUser ? (
                                <div className="p-3 rounded-2xl bg-amber-50/90 border border-amber-200 flex items-center gap-2.5">
                                    <Lock size={18} className="text-amber-600 shrink-0" />
                                    <div className="flex-1">
                                        <p className="text-xs font-bold text-amber-900 leading-tight">
                                            Global Chat mein message bhejna sirf <span className="text-purple-700 font-black">Ultra members</span> ke liye hai.
                                        </p>
                                        <p className="text-[11px] text-amber-700 font-medium mt-0.5">
                                            Aap sabhi messages padh aur like kar sakte hain! ❤️
                                        </p>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    {replyTarget && (
                                        <div className="mb-2 rounded-xl bg-blue-50 border border-blue-200 px-3 py-2 text-xs flex items-start justify-between gap-2">
                                            <div className="min-w-0">
                                                <div className="font-black text-blue-700">Replying to {replyTarget.userName}</div>
                                                <div className="text-slate-600 truncate">{replyTarget.text}</div>
                                            </div>
                                            <button onClick={() => setReplyTarget(null)} className="text-slate-500 font-black">X</button>
                                        </div>
                                    )}
                                    {/* Admin toggles */}
                                    {isAdminOrSub && (
                                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                                            <button
                                                onClick={() => setIsAdminOnly(v => !v)}
                                                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all ${isAdminOnly ? 'bg-amber-500 text-white border-amber-500' : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-amber-50'}`}
                                            >
                                                <Lock size={9} /> Admin Only
                                            </button>
                                            <button
                                                onClick={handleBroadcast}
                                                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold border bg-red-50 text-red-600 border-red-200 hover:bg-red-100 transition-all"
                                                title="Input ka text broadcast karo"
                                            >
                                                <Megaphone size={9} /> Broadcast
                                            </button>
                                        </div>
                                    )}

                                    {/* Support Tab Pricing Information */}
                                    {activeTab === 'SUPPORT' && (
                                        (isSubscriber || isAdminOrSub) ? (
                                            <div className="flex items-center gap-1.5 px-3 py-1.5 mb-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold">
                                                <Crown size={12} className="text-emerald-600" />
                                                <span>Subscribers ke liye Admin Support bilkul <strong>FREE</strong> hai! 🎉</span>
                                            </div>
                                        ) : (
                                            <div className="flex items-center justify-between gap-2 mb-2 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-[11px]">
                                                <div className="flex items-center gap-1 text-amber-900 font-bold">
                                                    <span>Cost: 10 🪙 ya 5 💎 per message</span>
                                                </div>
                                                <div className="flex gap-1 bg-white p-0.5 rounded-lg border border-amber-200">
                                                    <button
                                                        type="button"
                                                        onClick={() => setSupportCurrency('CREDITS')}
                                                        className={`px-2 py-0.5 rounded-md font-black text-[10px] transition-all ${supportCurrency === 'CREDITS' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-600'}`}
                                                    >
                                                        10 🪙
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={() => setSupportCurrency('DIAMONDS')}
                                                        className={`px-2 py-0.5 rounded-md font-black text-[10px] transition-all ${supportCurrency === 'DIAMONDS' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600'}`}
                                                    >
                                                        5 💎
                                                    </button>
                                                </div>
                                            </div>
                                        )
                                    )}

                                    <div className="flex gap-2 items-center">
                                        <input
                                            type="text"
                                            value={input}
                                            onChange={e => setInput(e.target.value)}
                                            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSendText()}
                                            placeholder="Message likhein..."
                                            className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                        />
                                        <button
                                            onClick={handleSendText}
                                            disabled={!input.trim()}
                                            className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-all disabled:opacity-40 shrink-0 self-end"
                                        >
                                            <Send size={18} />
                                        </button>
                                    </div>
                                    {isAdminOnly && (
                                        <p className="text-[10px] text-amber-600 font-bold mt-1.5 flex items-center gap-1">
                                            <Lock size={9} /> Ye message sirf Admin/Mod dekhenge
                                        </p>
                                    )}
                                </>
                            )}
                        </div>
                        )}
                        {/* MCQ tab footer — Admin: send MCQ + bulk delete */}
                        {activeTab === 'MCQ' && isAdminOrSub && (
                        <div className="p-3 pb-[calc(env(safe-area-inset-bottom,0px)+88px)] bg-white border-t border-slate-100 shrink-0 sticky bottom-0 space-y-2">
                            <button
                                onClick={() => setShowMcqBuilder(true)}
                                className="w-full flex items-center justify-center gap-2 border px-4 py-2.5 rounded-xl text-xs font-black active:scale-95 transition-all"
                                style={{ background: subColorLight, color: subColor, borderColor: subColorBorder }}
                            >
                                <BookOpen size={14} /> MCQ Bhejo (Admin)
                            </button>
                            <button
                                onClick={async () => {
                                    const mcqMsgs = messages.filter(m => m.type === 'MCQ');
                                    if (mcqMsgs.length === 0) { alert('Koi MCQ message nahi hai.'); return; }
                                    if (!confirm(`Kya aap pakka sab ${mcqMsgs.length} MCQ messages delete karna chahte hain? Yeh wapas nahi aayenge.`)) return;
                                    try {
                                        await Promise.all(mcqMsgs.map(m => remove(ref(rtdb, `chat/universal/${m.id}`))));
                                    } catch (e: any) { alert('Delete failed: ' + e.message); }
                                }}
                                className="w-full flex items-center justify-center gap-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 px-4 py-2.5 rounded-xl text-xs font-black active:scale-95 transition-all"
                            >
                                <Trash2 size={14} /> Sab MCQ Delete Karo ({messages.filter(m => m.type === 'MCQ').length})
                            </button>
                        </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};
