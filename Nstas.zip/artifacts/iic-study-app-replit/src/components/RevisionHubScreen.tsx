// @ts-nocheck
import React, { useState, useMemo, useEffect } from 'react';
import {
  ArrowLeft, BookOpen, RotateCcw, Clock, BarChart2, ChevronRight,
  CheckCircle, XCircle, Zap, Calendar, BrainCircuit, Trophy, Plus, List, Slash, Bookmark,
} from 'lucide-react';
import { playSoundCorrect, playSoundWrong, playSoundClick } from '../utils/soundEffects';
import type { User, StudentTab, SystemSettings } from '../types';
import { RevisionHubV2 } from './RevisionHubV2';
import { McqReviewHub } from './McqReviewHub';
import { MonthlyMarksheet } from './MonthlyMarksheet';
import { PerformanceGraph } from './PerformanceGraph';
import { subscribeMcqLessons, saveUserToLive, saveTestResult, saveUserHistory } from '../firebase';
import { useAppTheme } from '../utils/themeContext';
import {
  recordAttempt, applyInitialSchedule, bucketKey, getAllBuckets,
} from '../utils/revisionTrackerV2';
import { getStudyActivitySummary, formatActivityDuration } from '../utils/activityTracker';
import { syncAllRevisionBuckets } from '../utils/revisionFirebase';
import { applyDeduction, getTotalCredits } from '../utils/creditSystem';
import { CreditConfirmationModal } from './CreditConfirmationModal';
import { renderMathInHtml } from '../utils/mathUtils';
import { UNLOCK_COSTS } from '../utils/limits';
import { isSubjectMatch } from '../constants';
import { isSequentialLearningCompletedForLesson } from '../utils/routineAutoTrack';
import { loadRoutineData } from '../utils/routineStorage';
import McqQuestionDisplay from './McqQuestionDisplay';
import McqPracticeCard from './McqPracticeCard';
import McqQuestionNavigator from './McqQuestionNavigator';
import { hapticMedium } from '../utils/haptic';
import { getMcqStatements } from '../utils/mcqStructure';
import { extractStatements } from '../utils/mcqParser';

type HubTab = 'MCQ' | 'REVISION' | 'PERFORMANCE';

const CLASSES = ['6', '7', '8', '9', '10', '11', '12'];
const CLASS_EMOJIS: Record<string, string> = {
  '6': '📗', '7': '📘', '8': '📙', '9': '📕',
  '10': '🏅', '11': '🔬', '12': '🎓',
};

interface Props {
  user: User;
  settings?: SystemSettings;
  onBack: () => void;
  onTabChange: (tab: StudentTab) => void;
  onNavigateContent?: (type: 'PDF' | 'MCQ', chapterId: string, topicName?: string, subjectName?: string) => void;
  onUpdateUser?: (user: User) => void;
  onMcqAnswer?: (isCorrect: boolean) => boolean;
  onSendToMcqCommunity?: (draft: { question: string; statements?: string[]; options: [string,string,string,string]; correctAnswer: number; explanation: string }) => void;
  /** If set, auto-navigate to this lesson's MCQ on open — matched by lessonTitle (Routine / Daily Event shortcut, coins already paid by caller) */
  initialLessonTitle?: string | null;
  autoStartMcq?: boolean;
  appName?: string;
  appLogo?: string;
  onRestoreBottomNav?: (explicitState?: boolean) => void;
  isBottomNavVisible?: boolean;
}

const TABS: { id: HubTab; label: string; icon: React.ReactNode }[] = [
  { id: 'MCQ',          label: 'MCQ',         icon: <BookOpen size={16} /> },
  { id: 'REVISION',    label: 'Revision',     icon: <RotateCcw size={16} /> },
  { id: 'PERFORMANCE', label: 'Performance',  icon: <BarChart2 size={16} /> },
];

function daysLabel(secs: number): string {
  const d = Math.round(secs / 86400);
  if (d <= 0) return 'Aaj';
  if (d === 1) return 'Kal';
  return `${d} din baad`;
}

function accuracyTier(pct: number, cfg: any) {
  const t = cfg?.thresholds ?? { mastery: 80, strong: 65, average: 50 };
  if (pct >= t.mastery) return 'mastered';
  if (pct >= t.strong)  return 'strong';
  if (pct >= t.average) return 'average';
  return 'weak';
}

function nextRevisionSecs(pct: number, cfg: any): number {
  const iv = cfg?.intervals ?? {
    weak:     { revision: 86400 },
    average:  { revision: 259200 },
    strong:   { revision: 604800 },
    mastered: { revision: 2592000 },
  };
  const tier = accuracyTier(pct, cfg);
  return iv[tier]?.revision ?? 86400;
}

const TIER_STYLES: Record<string, { bg: string; text: string; label: string }> = {
  mastered: { bg: 'bg-emerald-100', text: 'text-emerald-700', label: '🏆 Mastered' },
  strong:   { bg: 'bg-indigo-100',  text: 'text-indigo-700',  label: '💪 Strong'   },
  average:  { bg: 'bg-amber-100',   text: 'text-amber-700',   label: '🙂 Average'  },
  weak:     { bg: 'bg-rose-100',    text: 'text-rose-700',    label: '😕 Weak'     },
};

export const RevisionHubScreen: React.FC<Props> = ({
  user, settings, onBack, onTabChange, onNavigateContent, onUpdateUser, onMcqAnswer, onSendToMcqCommunity,
  initialLessonTitle, autoStartMcq,
  appName, appLogo, onRestoreBottomNav, isBottomNavVisible
}) => {
  const theme = useAppTheme();
  const primary = theme.primary || '#6366f1';
  const [activeTab, setActiveTab]           = useState<HubTab>(autoStartMcq ? 'REVISION' : 'MCQ');
  const [showTopBar, setShowTopBar]                 = useState(true);
  const [localBottomNavVisible, setLocalBottomNavVisible] = useState(false);
  const activeBottomNavVisible = typeof isBottomNavVisible === 'boolean' ? isBottomNavVisible : localBottomNavVisible;

  const officialNstaLogo = (appLogo && !appLogo.includes('placeholder'))
    ? appLogo
    : (settings?.appLogo && !settings.appLogo.includes('placeholder'))
      ? settings.appLogo
      : '/branding/nsta-logo.svg';

  const handleToggleNavBars = () => {
    try { hapticMedium(); } catch (_) {}
    if (showTopBar && activeBottomNavVisible) {
      // Second tap: Hide BOTH top bar and bottom navigation!
      setShowTopBar(false);
      onRestoreBottomNav?.(false);
      setLocalBottomNavVisible(false);
    } else if (!showTopBar && !activeBottomNavVisible) {
      // Tap to restore: Bring back BOTH top bar and bottom navigation!
      setShowTopBar(true);
      onRestoreBottomNav?.(true);
      setLocalBottomNavVisible(true);
    } else {
      // First tap (top bar is visible, bottom nav was hidden):
      // Show navigation bar!
      setShowTopBar(true);
      onRestoreBottomNav?.(true);
      setLocalBottomNavVisible(true);
    }
  };

  const [mcqSelectedClass, setMcqSelectedClass]     = useState<string | null>(null);
  const [mcqSelectedSubject, setMcqSelectedSubject] = useState<string | null>(null);
  const [mcqSelectedLesson, setMcqSelectedLesson]   = useState<any | null>(null);
  const [allLessons, setAllLessons]                 = useState<any[]>([]);
  const [showMonthlySheet, setShowMonthlySheet]     = useState(false);

  const [sessionActive, setSessionActive]   = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionQIndex, setSessionQIndex]   = useState(0);
  const [sessionAnswers, setSessionAnswers] = useState<(number | null)[]>([]);
  const [sessionDone, setSessionDone]       = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback]     = useState(false);
  const [sessionMcqs, setSessionMcqs]       = useState<any[]>([]);
  const [showSessionNavigator, setShowSessionNavigator] = useState(false);
  const [sessionBookmarks, setSessionBookmarks] = useState<Set<number>>(new Set());
  const [sessionEliminated, setSessionEliminated] = useState<Record<number, Set<number>>>({});
  const [showEliminateTool, setShowEliminateTool] = useState(false);
  const [coinModal, setCoinModal] = useState<{
    title: string;
    cost: number;
    diamondCost: number;
    onConfirmCredits: () => void;
    onConfirmDiamonds: () => void;
  } | null>(null);
  const [pendingLesson, setPendingLesson] = useState<any | null>(null);

  // Subscribe to mcq_lessons from Firebase
  useEffect(() => {
    const unsub = subscribeMcqLessons((lessons) => setAllLessons(lessons));
    return unsub;
  }, []);

  // Auto-navigate: when opened from Routine/DailyEvent with a lessonTitle,
  // coins are already paid by the caller — just select the lesson directly.
  const autoNavigatedRef = React.useRef(false);
  useEffect(() => {
    if (!initialLessonTitle || autoNavigatedRef.current || allLessons.length === 0) return;
    const titleLower = initialLessonTitle.trim().toLowerCase();
    const lesson = allLessons.find(l =>
      String(l.lessonTitle || '').trim().toLowerCase() === titleLower
    );
    if (!lesson) return;
    autoNavigatedRef.current = true;
    setActiveTab('MCQ');
    setMcqSelectedClass(lesson.classLevel || null);
    setMcqSelectedSubject(lesson.subject || null);
    setMcqSelectedLesson(lesson); // coins already paid — go directly
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialLessonTitle, allLessons]);

  // Helper: excludes blank-topic MCQs and "General" MCQs (only real topic-wise MCQs allowed in Revision Hub)
  const isRealTopicMcq = (q: any) => {
    if (!q || (!q.question && !q.id)) return false;
    const topic = String(q.topic || '').trim();
    if (!topic) return false;
    const lower = topic.toLowerCase();
    return lower !== 'general' && lower !== 'सामान्य' && lower !== 'general mcq' && lower !== 'general mcqs';
  };

  const getValidMcqs = (lesson: any): any[] => {
    if (!lesson || !Array.isArray(lesson.mcqs)) return [];
    return lesson.mcqs.filter(isRealTopicMcq);
  };

  // Only include lessons that actually have Revision Hub MCQs (> 0).
  // Chapters/lessons with 0 MCQs (Pending / Coming Soon) are completely hidden.
  const hubLessons = useMemo(
    () => allLessons.filter(l => {
      if (!l.lessonTitle || !String(l.lessonTitle).trim()) return false;
      return getValidMcqs(l).length > 0;
    }),
    [allLessons],
  );

  // Subjects are derived purely from lessons that actually exist in Firebase
  // for the selected class — no hardcoded subject list, so a subject only
  // ever shows up once real notes/MCQ content has been added for it.
  const mcqSubjects = useMemo(() => {
    if (!mcqSelectedClass) return [];
    const names = Array.from(
      new Set(
        hubLessons
          .filter(l => l.classLevel === mcqSelectedClass && l.subject)
          .map(l => l.subject as string),
      ),
    );
    return names
      .sort((a, b) => a.localeCompare(b))
      .map(name => ({ id: name, name }));
  }, [mcqSelectedClass, hubLessons]);

  // Lessons available for current class + subject
  const subjectLessons = hubLessons.filter(
    l => l.classLevel === mcqSelectedClass && (
      l.subject === mcqSelectedSubject ||
      isSubjectMatch(l.subject, mcqSelectedSubject, mcqSelectedClass, settings)
    )
  );

  // MCQs from the selected lesson — only real topic-wise MCQs.
  // Excludes blank-topic MCQs and "General" MCQs (page-synced content).
  const classMcqs: any[] = (mcqSelectedLesson
    ? (mcqSelectedLesson.mcqs || [])
    : []
  ).filter(isRealTopicMcq);

  const currentQ = sessionActive ? sessionMcqs[sessionQIndex] : null;

  const topicResults = useMemo(() => {
    if (!sessionDone || !sessionMcqs.length) return [];
    const map: Record<string, { topic: string; correct: number; total: number }> = {};
    sessionMcqs.forEach((q: any, i: number) => {
      // Only count questions that were actually attempted (answered)
      if (sessionAnswers[i] === null || sessionAnswers[i] === undefined) return;
      const t = (q.topic || 'General').trim();
      if (!map[t]) map[t] = { topic: t, correct: 0, total: 0 };
      map[t].total += 1;
      if (sessionAnswers[i] === q.correctAnswer) {
        map[t].correct += 1;
      }
    });
    return Object.values(map);
  }, [sessionDone, sessionMcqs, sessionAnswers]);

  const revCfg = (settings as any)?.revisionConfig;

  const MCQ_START_COST = 40;
  const LESSON_OPEN_COST = UNLOCK_COSTS.REVISION_HUB_MCQ.credits;
  const LESSON_OPEN_DIAMOND_COST = UNLOCK_COSTS.REVISION_HUB_MCQ.diamonds;

  function doStartSession() {
    // ── Session tracking: App.tsx ko batao session shuru hua ─────────────
    const _chapterName = mcqSelectedLesson?.lessonTitle || `Class ${mcqSelectedClass} — ${mcqSelectedSubject}`;
    window.dispatchEvent(new CustomEvent('iic-mcq-session', {
      detail: { active: true, chapterName: _chapterName, subjectName: mcqSelectedSubject || 'General', activityType: 'MCQ' }
    }));
    // Group questions by topic, shuffle within each group, then round-robin interleave
    const topicBuckets: Record<string, any[]> = {};
    classMcqs.forEach((q: any) => {
      const t = (q.topic || 'General').trim();
      if (!topicBuckets[t]) topicBuckets[t] = [];
      topicBuckets[t].push(q);
    });
    const buckets = Object.values(topicBuckets).map(qs => {
      const arr = [...qs];
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    });
    const mixed: any[] = [];
    const maxLen = Math.max(...buckets.map(b => b.length), 0);
    for (let row = 0; row < maxLen; row++) {
      for (const bucket of buckets) {
        if (row < bucket.length) mixed.push(bucket[row]);
      }
    }
    setSessionMcqs(mixed);
    setSessionAnswers(new Array(mixed.length).fill(null));
    setSessionQIndex(0);
    setSelectedOption(null);
    setShowFeedback(false);
    setSessionDone(false);
    setShowSessionNavigator(false);
    setSessionActive(true);
  }

  function startSession() {
    // Direct start — no credit deduction popup
    doStartSession();
  }

  function handleNext() {
    doHandleNext();
  }

  function doHandleNext() {
    const nextIdx = sessionQIndex + 1;
    if (nextIdx >= sessionMcqs.length) {
      finishSession();
    } else {
      setSessionQIndex(nextIdx);
      const prevAns = sessionAnswers[nextIdx];
      setSelectedOption(prevAns !== undefined && prevAns !== null ? prevAns : null);
      setShowFeedback(false);
    }
  }

  function handleLessonClick(lesson: any) {
    const validMcqs = getValidMcqs(lesson);
    if (validMcqs.length === 0) {
      alert(`⏳ "${lesson.lessonTitle}"\n\nIs lesson mein abhi Topic-wise MCQs upload nahi huye hain (Coming Soon).\nAdmin jald hi questions add karenge.`);
      return;
    }

    const _isAdm = user?.role === 'ADMIN' || user?.role === 'SUB_ADMIN';
    if (_isAdm && user?.studyMode !== 'CREDIT') {
      setMcqSelectedLesson(lesson);
      return;
    }

    const lessonTarget = lesson.lessonId || lesson.id || lesson.lessonTitle;
    const isSeqDone = isSequentialLearningCompletedForLesson(lessonTarget);
    const isCreditOff = user?.studyMode !== 'CREDIT';

    // Rule 3: Free ONLY if user is in Credit-Off mode AND has completed Sequential Learning (Notes + MCQ)
    if (isCreditOff && isSeqDone) {
      setMcqSelectedLesson(lesson);
      return;
    }

    // Check if lesson is part of user's routine for 50% discount
    const routineData = loadRoutineData();
    const isRoutineLesson = Boolean(
      initialLessonTitle === lesson.lessonTitle ||
      (routineData?.subjects && routineData.subjects.some((s: any) => s.name === lesson.subject || s.id === lesson.subject))
    );

    const costCredits = isRoutineLesson ? 50 : 100;
    const costDiamonds = isRoutineLesson ? 12 : 25; // 1 diamond = 4 credits

    const unlockTitle = isRoutineLesson
      ? `⚡ ${lesson.lessonTitle || 'Lesson'} (Routine 50% OFF)`
      : `⚡ ${lesson.lessonTitle || 'Lesson'} MCQ Access (100 Coins)`;

    setPendingLesson(lesson);
    setCoinModal({
      title: unlockTitle,
      cost: costCredits,
      diamondCost: costDiamonds,
      onConfirmCredits: () => {
        const updated = applyDeduction(user, costCredits);
        if (updated) {
          onUpdateUser?.(updated);
          saveUserToLive(updated);
        }
        setCoinModal(null);
        setMcqSelectedLesson(lesson);
        setPendingLesson(null);
      },
      onConfirmDiamonds: () => {
        const curDiamonds = user.diamonds || 0;
        const updated: User = {
          ...user,
          diamonds: Math.max(0, curDiamonds - costDiamonds),
        };
        onUpdateUser?.(updated);
        try {
          localStorage.setItem("nst_current_user", JSON.stringify(updated));
          if (updated?.id) {
            localStorage.setItem(`nst_user_profile_${updated.id}`, JSON.stringify(updated));
            localStorage.setItem("nst_user_profile", JSON.stringify(updated));
          }
        } catch (_) {}
        saveUserToLive(updated, { immediate: true });
        setCoinModal(null);
        setMcqSelectedLesson(lesson);
        setPendingLesson(null);
      },
    });
  }

  function handleOptionSelect(optIdx: number) {
    // Only record if not already answered for this question
    if (sessionAnswers[sessionQIndex] !== null && sessionAnswers[sessionQIndex] !== undefined) return;
    const isCorrect = optIdx === (sessionMcqs[sessionQIndex]?.correctAnswer);
    if (isCorrect) {
      playSoundCorrect();
    } else {
      playSoundWrong();
    }
    // Apply level-based daily MCQ limit (if parent provides the tracker)
    if (onMcqAnswer) {
      if (!onMcqAnswer(isCorrect)) return;
    }
    setSelectedOption(optIdx);
    setSessionAnswers(prev => {
      const next = [...prev];
      next[sessionQIndex] = optIdx;
      return next;
    });

  }

  function handlePrev() {
    if (sessionQIndex <= 0) return;
    const prevIdx = sessionQIndex - 1;
    setSessionQIndex(prevIdx);
    const prevAns = sessionAnswers[prevIdx];
    setSelectedOption(prevAns !== undefined && prevAns !== null ? prevAns : null);
    setShowFeedback(false);
  }

  function finishSession() {
    const answeredCount = sessionAnswers.filter(a => a !== null && a !== undefined).length;
    if (sessionMcqs.length === 0 || answeredCount < sessionMcqs.length) return;

    setSessionActive(false);
    setSessionDone(true);
    // ── Session tracking: App.tsx ko batao session khatam hua ────────────
    window.dispatchEvent(new CustomEvent('iic-mcq-session', {
      detail: { active: false, activityType: 'MCQ' }
    }));

    const lessonId = mcqSelectedLesson?.id || `${mcqSelectedClass}_${mcqSelectedSubject}`;
    const chapterId = lessonId;
    const subjectId = mcqSelectedSubject || 'General';
    const subjectName = mcqSelectedSubject || 'General';
    const chapterTitle = mcqSelectedLesson?.lessonTitle || `Class ${mcqSelectedClass} — ${mcqSelectedSubject}`;

    // Tally totals across all answered questions
    let totalCorrect = 0;
    let totalAnswered = 0;
    sessionMcqs.forEach((q: any, i: number) => {
      if (sessionAnswers[i] === null || sessionAnswers[i] === undefined) return;
      totalAnswered++;
      if (sessionAnswers[i] === q.correctAnswer) totalCorrect++;
    });

    const topicMap: Record<string, { questions: any[]; answers: (number | null)[] }> = {};
    sessionMcqs.forEach((q: any, i: number) => {
      if (sessionAnswers[i] === null || sessionAnswers[i] === undefined) return;
      const t = (q.topic || 'General').trim();
      if (!topicMap[t]) topicMap[t] = { questions: [], answers: [] };
      topicMap[t].questions.push(q);
      topicMap[t].answers.push(sessionAnswers[i]);
    });

    Object.entries(topicMap).forEach(([topic, { questions, answers }]) => {
      try {
        recordAttempt({
          subjectId,
          subjectName,
          chapterId,
          chapterTitle,
          pageKey: chapterId,
          questions,
          userAnswers: answers,
        });
        const correct = answers.filter((a, i) => a !== null && a === questions[i].correctAnswer).length;
        const accuracy = questions.length > 0 ? correct / questions.length : 0;
        const bk = bucketKey(subjectId, chapterId, chapterId, topic);
        applyInitialSchedule(bk, accuracy, revCfg);
      } catch (_) {}
    });

    // ── Sync all revision buckets to Firebase after session (fire-and-forget) ──
    try {
      const allBuckets = getAllBuckets();
      const bucketMap: Record<string, any> = {};
      allBuckets.forEach((b: any) => {
        const k = `${b.subjectId}::${b.chapterId}::${b.pageKey}::${b.topic}`;
        bucketMap[k] = b;
      });
      syncAllRevisionBuckets(user.id, bucketMap);
    } catch (_) {}

    // ── Save to mcqHistory so My Routine + score tracking can see it ──────────
    if (totalAnswered > 0 && onUpdateUser) {
      const newEntry = {
        id: `rhub-${Date.now()}`,
        testId: `rhub-${Date.now()}`,
        chapterId,
        chapterTitle,
        subjectId,
        subjectName,
        userId: user.id,
        date: new Date().toISOString(),
        totalQuestions: totalAnswered,
        correctCount: totalCorrect,
        wrongCount: totalAnswered - totalCorrect,
        score: totalCorrect,
        totalTimeSeconds: 0,
        averageTimePerQuestion: 0,
        performanceTag: totalCorrect / totalAnswered >= 0.8 ? 'EXCELLENT' : totalCorrect / totalAnswered >= 0.5 ? 'GOOD' : 'NEEDS_IMPROVEMENT',
        type: 'REVISION_MCQ',
        questions: sessionMcqs,
        userAnswers: sessionAnswers,
        omrData: sessionAnswers.reduce((acc: any, ans: any, idx: number) => {
          if (ans !== null && ans !== undefined) acc[idx] = ans;
          return acc;
        }, {}),
      };
      // Keep a durable per-attempt copy in Firebase as well as the user's
      // aggregated mcqHistory. This makes the complete test history recoverable
      // independently on another device.
      try {
        saveTestResult(user.id, newEntry);
        saveUserHistory(user.id, newEntry);
      } catch (_) {}
      // ── Pts: +5 sahi jawab, -2 galat jawab ──────────────────────────────
      const wrongCount = Math.max(0, totalAnswered - totalCorrect);
      const ptsEarned = (totalCorrect * 5) - (wrongCount * 2);
      const updatedUser = {
        ...user,
        mcqHistory: [...(user.mcqHistory || []), newEntry],
        totalScore: Math.max(0, (user.totalScore || 0) + ptsEarned),
      };
      onUpdateUser(updatedUser);
      try { saveUserToLive(updatedUser); } catch (_) {}
    }
  }

  useEffect(() => {
    if (!sessionActive || sessionDone) return;
    const interval = setInterval(() => {
      setSessionSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionActive, sessionDone]);

  function resetSession() {
    setSessionActive(false);
    setSessionDone(false);
    setSessionSeconds(0);
    setSessionQIndex(0);
    setSessionAnswers([]);
    setSessionMcqs([]);
    setSelectedOption(null);
    setShowFeedback(false);
    setShowSessionNavigator(false);
  }

  const handleTabChange = (tab: HubTab) => {
    setActiveTab(tab);
    setMcqSelectedClass(null);
    setMcqSelectedSubject(null);
    setMcqSelectedLesson(null);
    setShowMonthlySheet(false);
    resetSession();
  };

  const handleBack = () => {
    if (sessionActive || sessionDone) { resetSession(); return; }
    if (mcqSelectedLesson)  { setMcqSelectedLesson(null); return; }
    if (mcqSelectedSubject) { setMcqSelectedSubject(null); return; }
    if (mcqSelectedClass)   { setMcqSelectedClass(null);   return; }
    onBack();
  };

  const titleText =
    sessionDone   ? 'Session Results'                        :
    sessionActive ? `Q${sessionQIndex + 1} / ${sessionMcqs.length}` :
    activeTab === 'MCQ' && mcqSelectedLesson  ? mcqSelectedLesson.lessonTitle :
    activeTab === 'MCQ' && mcqSelectedSubject ? `MCQ — ${mcqSelectedSubject}` :
    activeTab === 'MCQ' && mcqSelectedClass   ? (mcqSelectedClass === 'COMPETITION' ? 'Competition MCQs' : `Class ${mcqSelectedClass}`) :
    'Revision Hub';

  const progress = sessionActive && sessionMcqs.length > 0
    ? ((sessionQIndex) / sessionMcqs.length) * 100
    : 0;

  return (
    <div className="fixed inset-0 z-[350] flex flex-col bg-white" style={{ height: '100dvh' }}>

      {/* ── Top Bar (can be toggled / hidden) ── */}
      {showTopBar && (
        <div className="flex items-center gap-3 px-4 py-3 bg-white border-b border-slate-100 shadow-sm shrink-0">
          <button
            id="revision-hub-back-btn"
            onClick={handleBack}
            className="p-2 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 transition-all"
            aria-label="Back"
          >
            <ArrowLeft size={18} className="text-slate-700" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-black text-slate-800 leading-none truncate">{titleText}</h1>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {sessionActive
                ? `Topic: ${currentQ?.topic || 'Topic Practice'}`
                : (mcqSelectedClass && activeTab === 'MCQ')
                  ? 'MCQ Practice'
                  : 'MCQ · Revision · History · Performance'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {sessionActive && (
              <button
                type="button"
                onClick={() => setShowSessionNavigator(prev => !prev)}
                aria-label={showSessionNavigator ? 'Hide question switcher' : 'Show question switcher'}
                aria-expanded={showSessionNavigator}
                className={`shrink-0 p-2 rounded-xl border transition-all ${
                  showSessionNavigator
                    ? 'bg-indigo-100 border-indigo-300 text-indigo-700'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <List size={18} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Progress bar (session only) */}
      {sessionActive && (
        <div className={`h-1 bg-slate-100 shrink-0 ${!showTopBar ? 'fixed top-0 left-0 right-0 z-[400]' : ''}`}>
          <div
            className="h-1 transition-all duration-300"
            style={{ width: `${progress}%`, background: primary }}
          />
        </div>
      )}

      {/* ── Minimalist Back button when Top Bar is hidden ── */}
      {!showTopBar && (
        <button
          onClick={handleBack}
          className="fixed top-3 left-3 z-[450] p-2 rounded-full bg-slate-900/80 hover:bg-slate-900 text-white backdrop-blur shadow-lg active:scale-95 transition-all cursor-pointer"
          aria-label="Back"
          title="Back"
        >
          <ArrowLeft size={16} className="text-white" />
        </button>
      )}

      {/* ── Tabs (hidden during session / results, and hidden when showTopBar is false) ── */}
      {showTopBar && !sessionActive && !sessionDone && (
        <div className="flex items-center bg-white border-b border-slate-100 shrink-0 overflow-x-auto">
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`revision-hub-tab-${tab.id.toLowerCase()}`}
                onClick={() => handleTabChange(tab.id)}
                className={`flex-1 min-w-[80px] flex flex-col items-center gap-1 py-2.5 text-[11px] font-bold transition-all relative ${
                  isActive ? '' : 'text-slate-400 hover:text-slate-600'
                }`}
                style={isActive ? { color: primary } : {}}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full" style={{ background: primary }} />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* ── Content ── */}
      <div className={`flex-1 overflow-y-auto overflow-x-hidden ${!showTopBar ? 'pt-4' : ''} ${activeBottomNavVisible ? 'pb-[88px]' : 'pb-20'}`}>

        {sessionActive && showSessionNavigator && (
          <div className="px-4 pt-3 max-w-xl mx-auto w-full">
            <McqQuestionNavigator
              total={sessionMcqs.length}
              currentIndex={sessionQIndex}
              answers={Object.fromEntries(
                sessionAnswers
                  .map((answer, index) => [index, answer])
                  .filter(([, answer]) => answer !== null && answer !== undefined),
              )}
              bookmarked={sessionBookmarks}
              onJump={(index) => {
                setSessionQIndex(index);
                setSelectedOption(sessionAnswers[index] ?? null);
                setShowFeedback(false);
                playSoundClick();
              }}
            />
          </div>
        )}

        {/* ══ SESSION MODE ══ */}
        {sessionActive && currentQ && (() => {
          const answered   = sessionAnswers.filter(a => a !== null && a !== undefined).length;
          const correct    = sessionAnswers.filter((a, i) => a !== null && a !== undefined && a === sessionMcqs[i]?.correctAnswer).length;
          const wrong      = answered - correct;
          const isAnswered = sessionAnswers[sessionQIndex] !== null && sessionAnswers[sessionQIndex] !== undefined;
           const totalQuestions = sessionMcqs.length;
           const ready      = totalQuestions > 0 && answered >= totalQuestions;
           // After moving back, keep a forward-navigation path even if the
           // current question has not been answered yet. The first question
           // still requires an answer before moving forward.
           const canGoForward = isAnswered || (sessionQIndex > 0 && sessionQIndex < totalQuestions - 1);

          return (
          <div className="p-4 max-w-xl mx-auto space-y-4 pb-32">

            {/* Running score counter */}
            <div className="flex items-center gap-2">
              {currentQ?.topic && (
                <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                  {currentQ.topic}
                </span>
              )}
              <button
                type="button"
                onClick={() => {
                  setShowEliminateTool(e => !e);
                  playSoundClick();
                }}
                className={`text-[10px] font-black px-2 py-0.5 rounded-full border transition-all flex items-center gap-1 ${
                  showEliminateTool
                    ? 'bg-purple-100 text-purple-700 border-purple-300'
                    : 'bg-slate-100 text-slate-500 border-slate-200 hover:text-slate-700'
                }`}
                title="50:50 Option Elimination Mode"
              >
                <Slash size={10} /> 50:50
              </button>
              <span className="text-[10px] text-slate-400 ml-auto">{sessionQIndex + 1}/{sessionMcqs.length}</span>
              <div className="flex items-center gap-1 font-mono font-black text-[10px] px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 shrink-0" title="Practice Timer">
                <Clock size={10} className="text-indigo-600 animate-pulse" />
                <span>{Math.floor(sessionSeconds / 60).toString().padStart(2, '0')}:{(sessionSeconds % 60).toString().padStart(2, '0')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle size={10} /> {correct}
                </span>
                <span className="text-[10px] font-black bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <XCircle size={10} /> {wrong}
                </span>
              </div>
            </div>

             <McqPracticeCard
               q={currentQ}
               questionNumber={currentQ.questionNumber ?? sessionQIndex + 1}
               selectedOption={selectedOption}
               answered={isAnswered}
               onSelect={handleOptionSelect}
               isBookmarked={sessionBookmarks.has(sessionQIndex)}
               onToggleBookmark={() => {
                 setSessionBookmarks(prev => {
                   const next = new Set(prev);
                   if (next.has(sessionQIndex)) next.delete(sessionQIndex);
                   else next.add(sessionQIndex);
                   return next;
                 });
                 playSoundClick();
               }}
               eliminatedOptions={sessionEliminated[sessionQIndex]}
               onToggleEliminate={(oi) => {
                 setSessionEliminated(prev => {
                   const cur = prev[sessionQIndex] || new Set<number>();
                   const next = new Set(cur);
                   if (next.has(oi)) next.delete(oi);
                   else next.add(oi);
                   return { ...prev, [sessionQIndex]: next };
                 });
                 playSoundClick();
               }}
               showEliminateTool={showEliminateTool}
               actions={onSendToMcqCommunity ? (
                 <button
                   onClick={(e) => {
                     e.stopPropagation();
                     e.preventDefault();
                     const opts = (currentQ.options || []).length === 4
                       ? currentQ.options as [string,string,string,string]
                       : ([...(currentQ.options || []), '', '', '', ''].slice(0, 4) as [string,string,string,string]);
                     const stmts = getMcqStatements(currentQ);
                     let finalStmts = stmts;
                     let cleanQ = (currentQ.question || '').replace(/<br\s*\/?>/gi, '\n').trim();
                     if (finalStmts.length === 0) {
                       const ext = extractStatements(cleanQ);
                       if (ext.statements.length > 0) {
                         finalStmts = ext.statements;
                         cleanQ = ext.cleanedQuestion.replace(/<br\s*\/?>/gi, '\n').trim();
                       }
                     }
                     onSendToMcqCommunity({
                       question: cleanQ,
                       statements: finalStmts.length > 0 ? finalStmts : undefined,
                       options: opts,
                       correctAnswer: currentQ.correctAnswer ?? 0,
                       explanation: currentQ.explanation || '',
                     });
                   }}
                   className="w-7 h-7 rounded-full flex items-center justify-center active:scale-90 transition-all bg-indigo-100 text-indigo-600"
                   title="MCQ Community mein bhejo"
                 >
                   <Plus size={13} strokeWidth={2.5} />
                 </button>
               ) : undefined}
             />

             {/* Fixed Bottom navigation row */}
            <div className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 py-2.5 shadow-xl max-w-xl mx-auto space-y-2">
              <div className="flex gap-2">
                {/* Prev button */}
                <button
                  onClick={handlePrev}
                  disabled={sessionQIndex === 0}
                  className="flex items-center justify-center gap-1.5 px-4 py-3.5 rounded-2xl border-2 border-slate-200 text-slate-600 font-bold text-sm disabled:opacity-30 disabled:cursor-not-allowed active:scale-[0.97] transition-all bg-white"
                >
                  <ArrowLeft size={15} /> Pichla
                </button>

                 {/* Manual next button — keep the selected answer visible until
                     the student is ready to move on. */}
                 <button
                   type="button"
                   onClick={handleNext}
                   disabled={!canGoForward}
                   className={`flex-1 flex items-center justify-center gap-1.5 rounded-2xl border-2 py-3.5 font-black text-sm active:scale-[0.97] transition-all ${
                     canGoForward
                       ? 'border-indigo-500 bg-indigo-600 text-white shadow-md shadow-indigo-200'
                       : 'border-dashed border-slate-200 bg-white text-slate-400 cursor-not-allowed'
                   }`}
                 >
                   {canGoForward
                     ? (sessionQIndex < sessionMcqs.length - 1
                       ? <>Agla <ChevronRight size={16} /></>
                       : <>✅ Finish</>)
                     : '⬆ Ek option chunein'}
                 </button>
              </div>

              {/* Submit button */}
              <button
                onClick={finishSession}
                disabled={!ready}
                className={`w-full py-3.5 font-bold rounded-2xl transition-all flex items-center justify-center gap-2 text-sm ${ready ? 'active:scale-[0.99] text-white' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}
                style={ready ? { background: '#16a34a' } : {}}
              >
                {ready
                   ? <><Trophy size={16} /> Submit karein ({answered}/{totalQuestions})</>
                   : `${answered}/${totalQuestions} — ${totalQuestions - answered} sawaal baaki`}
              </button>
            </div>
          </div>
          );
        })()}

        {/* ══ SESSION RESULTS ══ */}
        {sessionDone && (
          <div className="p-4 max-w-xl mx-auto space-y-4">
            {/* Header */}
            <div className="rounded-2xl p-5 text-white text-center" style={{ background: `linear-gradient(135deg, ${primary}ee, ${primary})` }}>
              <BrainCircuit size={32} className="mx-auto mb-2 opacity-80" />
              <p className="text-lg font-black">Session Complete!</p>
              <p className="text-xs opacity-70 mt-1">Revision schedule update ho gaya ✓</p>
            </div>

            {/* Per-topic results */}
            <p className="text-[11px] font-black uppercase tracking-wider text-slate-400 text-center">Topic-wise Results</p>
            {topicResults.map(({ topic, correct, total }) => {
              const pct = total > 0 ? (correct / total) * 100 : 0;
              const tier = accuracyTier(pct, revCfg);
              const style = TIER_STYLES[tier];
              const revSecs = nextRevisionSecs(pct, revCfg);
              return (
                <div key={topic} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="px-4 py-3 flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center shrink-0 font-black ${style.bg} ${style.text}`}>
                      <span className="text-sm leading-none">{correct}/{total}</span>
                      <span className="text-[9px] uppercase">score</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-black text-slate-800 truncate">{topic}</p>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${style.bg} ${style.text}`}>
                        {style.label}
                      </span>
                    </div>
                  </div>

                  {/* Schedule line */}
                  <div className="px-4 pb-3 flex items-center gap-4 text-[11px]">
                    <div className="flex items-center gap-1.5 text-indigo-600">
                      <BookOpen size={12} />
                      <span className="font-bold">Notes: <span className="text-slate-600">Kal</span></span>
                    </div>
                    <div className="flex items-center gap-1.5 text-emerald-600">
                      <Calendar size={12} />
                      <span className="font-bold">
                        MCQ: <span className="text-slate-600">{daysLabel(revSecs + 86400)}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-violet-600 ml-auto">
                      <Zap size={12} />
                      <span className="font-bold">Interval: {Math.round(revSecs / 86400)}d</span>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Q-by-Q Review */}
            <div>
              <p className="text-[11px] font-black uppercase tracking-wider text-slate-400 text-center mb-3">Sawaal-wise Review</p>
              <div className="space-y-2">
                {sessionMcqs.map((q: any, qi: number) => {
                  const userAns = sessionAnswers[qi];
                  // Only show questions that were actually attempted
                  if (userAns === null || userAns === undefined) return null;
                  const isCorrect = userAns === q.correctAnswer;
                  return (
                    <div key={qi} className={`rounded-2xl border overflow-hidden ${isCorrect ? 'border-emerald-200 bg-emerald-50' : 'border-rose-200 bg-rose-50'}`}>
                      <div className="flex items-start gap-3 px-4 py-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-black text-sm ${isCorrect ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                          {isCorrect ? '✅' : '❌'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[10px] font-black text-slate-400 mb-0.5">
                            Q{qi + 1}{q.topic ? ` · ${q.topic}` : ''}
                          </p>
                          <p className="text-xs font-bold text-slate-800 leading-relaxed line-clamp-2"
                            dangerouslySetInnerHTML={{ __html: renderMathInHtml((q.question || '').replace(/<br\/?>/g, ' ')) }}
                          />
                          <div className="mt-1.5 space-y-0.5">
                            {!isCorrect && (
                              <p className="text-[10px] text-rose-600 font-bold">
                                ❌ Tumhara: {String.fromCharCode(65 + userAns)}. <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.options?.[userAns] || '') }} />
                              </p>
                            )}
                            <p className="text-[10px] text-emerald-700 font-bold">
                              ✅ Sahi: {String.fromCharCode(65 + q.correctAnswer)}. <span dangerouslySetInnerHTML={{ __html: renderMathInHtml(q.options?.[q.correctAnswer] || '') }} />
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Info box */}
            <div className="rounded-2xl px-4 py-3 text-xs leading-relaxed" style={{ background: `${primary}12`, border: `1px solid ${primary}25`, color: primary }}>
              <p className="font-black mb-1">📅 Performance Save Ho Gaya</p>
              <p><strong>Revision Hub → Performance</strong> tab mein Weak / Average / Strong topics dekhein. <strong>Aaj Ka Kaam</strong> tab mein notes aur MCQ schedule milega.</p>
            </div>

            <button
              onClick={resetSession}
              className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3.5 rounded-2xl transition-all"
            >
              <RotateCcw size={16} /> Wapas Jao
            </button>
          </div>
        )}

        {/* MCQ → Class Selection */}
        {activeTab === 'MCQ' && !mcqSelectedClass && !sessionActive && !sessionDone && (
          <div className="p-4 space-y-3">
            {/* Header — same as home page */}
            <div className="flex items-center gap-2">
              <span className="flex-1 h-px bg-slate-100" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Apni Class Choose Karein</span>
              <span className="flex-1 h-px bg-slate-100" />
            </div>

            {(() => {
              const _isDark = theme.isDarkMode;
              const _c612Bg  = (settings as any)?.homeClass612CardBg     || (theme as any).cardBg || (theme as any).profileCardBg || '#ffffff';
              const _c612Bdr = (settings as any)?.homeClass612CardBorder  || (theme as any).primary || primary;
              const _card3D  = (settings as any)?.homeAllCards3D || (settings as any)?.homeClass612Card3D || false;
              const boardClasses = ['10', '11', '12'];

              const cardStyle3D = _card3D ? {
                background: _c612Bg,
                border: `2px solid ${_c612Bdr}`,
                boxShadow: `0 1px 0 rgba(255,255,255,0.85) inset, 0 4px 0 ${_c612Bdr}bb, 0 7px 18px ${_c612Bdr}28`,
                transform: 'translateY(-1px)',
              } : {
                background: _c612Bg,
                border: `2px solid ${_c612Bdr}`,
                boxShadow: _isDark ? `0 4px 16px ${_c612Bdr}20` : '0 2px 8px rgba(0,0,0,0.05)',
              };

              const ClassBtn = ({ c }: { c: string }) => {
                const subjCount = new Set(
                  hubLessons.filter(l => l.classLevel === c && l.subject).map(l => l.subject as string),
                ).size;
                const isBoard = boardClasses.includes(c);
                return (
                  <button
                    key={c}
                    onClick={() => setMcqSelectedClass(c)}
                    className="relative flex flex-col p-2.5 rounded-xl active:scale-95 transition-all text-left group"
                    style={cardStyle3D}
                  >
                    {isBoard ? (
                      <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-full text-[7px] font-black bg-amber-400 text-amber-900 leading-none shadow-xs">👑</span>
                    ) : (
                      <span className="absolute top-1.5 right-1.5 text-sm leading-none select-none opacity-70 group-hover:scale-110 transition-transform">{CLASS_EMOJIS[c]}</span>
                    )}
                    <p className="text-[7px] font-black uppercase tracking-widest mb-0.5" style={{ color: _isDark ? '#94a3b8' : theme.textSecondary || '#64748b' }}>CLASS</p>
                    <p className="text-2xl font-black leading-none mb-1" style={{ color: _c612Bdr }}>{c}</p>
                    <p className="text-[9px] font-bold leading-tight" style={{ color: _isDark ? '#cbd5e1' : theme.textPrimary || '#334155' }}>{subjCount} Subj.</p>
                  </button>
                );
              };

              const _cmpBg  = (settings as any)?.homeCompetitionCardBg     || (theme as any).cardBg || (theme as any).profileCardBg || '#ffffff';
              const _cmpBdr = (settings as any)?.homeCompetitionCardBorder  || (theme as any).primary || primary;
              const _cmp3D  = (settings as any)?.homeAllCards3D || (settings as any)?.homeCompetitionCard3D || false;

              return (
                <>
                  {/* Row 1: Class 6-9 (4 columns) */}
                  <div className="grid grid-cols-4 gap-2">
                    {['6','7','8','9'].map(c => <ClassBtn key={c} c={c} />)}
                  </div>
                  {/* Row 2: Class 10-12 (3 columns) */}
                  <div className="grid grid-cols-3 gap-2">
                    {['10','11','12'].map(c => <ClassBtn key={c} c={c} />)}
                  </div>

                  {/* Competition card — matches home page big banner style */}
                  <button
                    onClick={() => setMcqSelectedClass('COMPETITION')}
                    className="w-full relative overflow-hidden rounded-2xl text-left active:scale-[0.99] transition-all group"
                    style={_cmp3D ? {
                      background: _cmpBg,
                      border: `2px solid ${_cmpBdr}`,
                      boxShadow: `0 1px 0 rgba(255,255,255,0.85) inset, 0 4px 0 ${_cmpBdr}bb, 0 7px 18px ${_cmpBdr}28`,
                      transform: 'translateY(-1px)',
                    } : {
                      background: _cmpBg,
                      border: `2px solid ${_cmpBdr}`,
                      boxShadow: _isDark ? `0 4px 20px ${_cmpBdr}20` : '0 2px 10px rgba(0,0,0,0.06)',
                    }}
                  >
                    <div className="flex items-center justify-between px-4 py-4">
                      <div className="flex-1 min-w-0 pr-2">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider shrink-0"
                            style={{
                              background: `${_cmpBdr}18`,
                              color: _cmpBdr,
                              border: `1px solid ${_cmpBdr}35`
                            }}
                          >
                            Competitive Mode
                          </span>
                        </div>
                        <h3 className="text-[22px] font-black leading-tight mb-1" style={{ color: _isDark ? '#f8fafc' : theme.textPrimary || '#1e293b' }}>Govt. Exams</h3>
                        <div className="mb-3 flex items-center flex-wrap gap-1.5">
                          <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${_isDark ? 'bg-white/10 border border-white/10 text-slate-300' : 'bg-slate-100/90 border border-slate-200/60 text-slate-700'}`}>
                            📚 7 Books
                          </span>
                          <span className="text-[10px] font-medium" style={{ color: _isDark ? '#94a3b8' : theme.textSecondary || '#64748b' }}>SSC · UPSC · Railway · Police</span>
                        </div>
                        <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-[11px] font-black text-white shadow-xs group-hover:translate-x-0.5 transition-transform" style={{ background: theme.btnGrad || _cmpBdr }}>
                          <span>Tap to open</span>
                          <span>→</span>
                        </span>
                      </div>
                      <div className="text-[52px] leading-none shrink-0 select-none group-hover:scale-105 transition-transform">🏛️</div>
                    </div>
                  </button>
                </>
              );
            })()}
          </div>
        )}

        {/* MCQ → Subject Selection */}
        {activeTab === 'MCQ' && mcqSelectedClass && !mcqSelectedSubject && !sessionActive && !sessionDone && (
          <div className="p-4 space-y-2">
            <p className="text-[11px] font-black uppercase tracking-widest text-center py-2 text-slate-400">
              Subject Choose Karein
            </p>
            {mcqSubjects.length === 0 ? (
              <div className="text-center py-14">
                <div className="text-5xl mb-3">📭</div>
                <p className="text-slate-700 font-bold">Is class mein abhi koi Revision MCQ available nahi hai</p>
                <p className="text-slate-400 text-sm mt-1">Admin jald hi questions add karenge</p>
              </div>
            ) : (
              mcqSubjects.map((sub: any) => {
                const lessonCount = hubLessons.filter(l => l.classLevel === mcqSelectedClass && l.subject === sub.name).length;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setMcqSelectedSubject(sub.name)}
                    className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-white active:scale-[0.99] active:translate-y-0.5 transition-all"
                    style={{ border: `1.5px solid #e2e8f0`, boxShadow: `0 4px 0 0 #cbd5e1, 0 4px 12px rgba(0,0,0,0.05)` }}
                  >
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0" style={{ background: `${primary}18` }}>
                      📚
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-bold text-slate-800 text-sm">{sub.name}</p>
                      <p className="text-[10px] text-slate-400">
                        {lessonCount} {lessonCount === 1 ? 'lesson' : 'lessons'}
                      </p>
                    </div>
                    {lessonCount > 0 && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${primary}18`, color: primary }}>
                        {lessonCount}
                      </span>
                    )}
                    <ChevronRight size={16} className="text-slate-400" />
                  </button>
                );
              })
            )}
          </div>
        )}

        {/* MCQ → Lesson List */}
        {activeTab === 'MCQ' && mcqSelectedClass && mcqSelectedSubject && !mcqSelectedLesson && !sessionActive && !sessionDone && (
          <div className="p-4 space-y-3">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest text-center py-1">
              Lesson Choose Karein
            </p>
            {subjectLessons.length === 0 ? (
              <div className="text-center py-14">
                <div className="text-5xl mb-3">📭</div>
                <p className="text-slate-700 font-bold">Is subject mein abhi koi Revision MCQ nahi hai</p>
                <p className="text-slate-400 text-sm mt-1">Admin jald hi MCQs add karenge</p>
              </div>
            ) : (
              subjectLessons.map((lesson: any) => (
                <button
                  key={lesson.id}
                  onClick={() => handleLessonClick(lesson)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-white active:scale-[0.99] active:translate-y-0.5 transition-all"
                  style={{ border: '1.5px solid #e2e8f0', boxShadow: '0 4px 0 0 #cbd5e1, 0 4px 12px rgba(0,0,0,0.05)' }}
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: `${primary}18` }}>📖</div>
                  <div className="flex-1 text-left min-w-0">
                    <p className="font-bold text-slate-800 text-sm truncate">{lesson.lessonTitle}</p>
                    <div className="flex flex-wrap gap-1 mt-0.5">
                      {(() => {
                        const cnt = getValidMcqs(lesson).length;
                        return (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: `${primary}18`, color: primary }}>
                            {cnt} MCQs
                          </span>
                        );
                      })()}
                      {(() => {
                        const lessonTarget = lesson.lessonId || lesson.id || lesson.lessonTitle;
                        const isSeqDone = isSequentialLearningCompletedForLesson(lessonTarget);
                        const isCreditOff = user?.studyMode !== 'CREDIT';
                        if (isCreditOff && isSeqDone) {
                          return (
                            <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                              ✓ Free (Sequential Done)
                            </span>
                          );
                        }
                        const routineData = loadRoutineData();
                        const isRoutine = Boolean(
                          initialLessonTitle === lesson.lessonTitle ||
                          (routineData?.subjects && routineData.subjects.some((s: any) => s.name === lesson.subject || s.id === lesson.subject))
                        );
                        if (isRoutine) {
                          return (
                            <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700">
                              ⚡ 50 🪙 (Routine 50% OFF)
                            </span>
                          );
                        }
                        return (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700">
                            🔒 100 🪙
                          </span>
                        );
                      })()}
                      {(() => {
                        const validTopics = (lesson.topics || []).filter((t: string) => {
                          const s = String(t || '').trim().toLowerCase();
                          return s && s !== 'general' && s !== 'सामान्य' && s !== 'general mcq' && s !== 'general mcqs';
                        });
                        return (
                          <>
                            {validTopics.slice(0, 2).map((t: string) => (
                              <span key={t} className="text-[9px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full truncate max-w-[90px]">
                                {t}
                              </span>
                            ))}
                            {validTopics.length > 2 && (
                              <span className="text-[9px] text-slate-400">+{validTopics.length - 2} more</span>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-slate-400 shrink-0" />
                </button>
              ))
            )}
          </div>
        )}

        {/* MCQ → Start Session */}
        {activeTab === 'MCQ' && mcqSelectedLesson && !sessionActive && !sessionDone && (
          <div className="p-4 max-w-xl mx-auto">
            <div className="space-y-4">
              {/* Summary card */}
              <div className="rounded-2xl p-5 text-center" style={{ background: `${primary}10`, border: `1px solid ${primary}25` }}>
                <div className="text-4xl mb-2">📖</div>
                <p className="font-black text-slate-800 text-lg leading-tight">{mcqSelectedLesson.lessonTitle}</p>
                <p className="text-slate-500 text-sm mt-1">Class {mcqSelectedClass} · {mcqSelectedSubject}</p>
                <div className="mt-3 flex items-center justify-center gap-3 text-sm">
                  <span className="bg-white rounded-xl px-3 py-1.5 font-bold" style={{ border: `1px solid ${primary}25`, color: primary }}>
                    {classMcqs.length} Sawaal
                  </span>
                  <span className="bg-white border border-slate-200 rounded-xl px-3 py-1.5 font-bold text-slate-600">
                    {[...new Set(classMcqs.map((q: any) => String(q.topic || '').trim()).filter(Boolean))].length} Topics
                  </span>
                </div>
              </div>

              {/* Topic preview */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-2">
                <p className="text-[11px] font-black uppercase tracking-wider text-slate-400 mb-2">Topics in this lesson</p>
                {[...new Set(classMcqs.map((q: any) => String(q.topic || '').trim()).filter(Boolean))].map((t: string) => {
                  const cnt = classMcqs.filter((q: any) => String(q.topic || '').trim() === t).length;
                  return (
                    <div key={t} className="flex items-center justify-between text-sm">
                      <span className="text-slate-700 font-medium truncate flex-1">{t}</span>
                      <span className="text-[11px] font-bold ml-2 shrink-0" style={{ color: primary }}>{cnt}Q</span>
                    </div>
                  );
                })}
              </div>

              {/* Info */}
              <div className="rounded-xl bg-amber-50 border border-amber-100 px-3 py-2.5 text-xs text-amber-700 flex gap-2">
                <span>💡</span>
                <span>MCQ complete karne ke baad topic-wise Weak/Average/Strong automatically save ho jayega.</span>
              </div>

              <button
                onClick={startSession}
                className="w-full flex items-center justify-center gap-2 active:scale-[0.99] text-white font-black py-4 rounded-2xl text-base transition-all shadow-lg"
                style={{ background: primary }}
              >
                <Zap size={20} /> MCQ Session Shuru Karo
              </button>
            </div>
          </div>
        )}

        {/* Revision Tab — full RevisionHubV2 embedded (header hidden to avoid duplicate title) */}
        {activeTab === 'REVISION' && (
          <RevisionHubV2
            user={user}
            settings={settings}
            onBack={() => setActiveTab('MCQ')}
            onTabChange={onTabChange}
            onNavigateContent={onNavigateContent}
            onUpdateUser={onUpdateUser}
            hideHeader={true}
            onMcqAnswer={onMcqAnswer}
            autoStartMcq={autoStartMcq}
          />
        )}

        {/* Performance Tab */}
        {activeTab === 'PERFORMANCE' && (() => {
          const topicSummaries = getStudyActivitySummary(user.id).filter(s => s.mcq.attempts > 0 || Object.keys(s.seconds).length > 0);
          return (
            <div className="p-4 space-y-4">
              <PerformanceGraph
                history={(user as any).mcqHistory || []}
                user={user}
              />

              {/* Topic-wise Progress from activityTracker */}
              {topicSummaries.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[11px] font-black uppercase tracking-wider text-slate-400 px-1">📚 Topic-wise Progress</p>
                  {topicSummaries.map((s, i) => {
                    const latest = s.mcq.latest;
                    const prev = s.mcq.previous;
                    const latestPct = latest ? Math.round((latest.correct / Math.max(1, latest.total)) * 100) : 0;
                    const prevPct = prev ? Math.round((prev.correct / Math.max(1, prev.total)) * 100) : 0;
                    const totalSec = Object.values(s.seconds).reduce((a, b) => a + (b || 0), 0);
                    return (
                      <div key={i} className="bg-white rounded-2xl border border-slate-100 shadow-sm px-4 py-3 space-y-1.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-[12px] font-black text-slate-800 truncate">{s.topic}</p>
                            {s.subject && (
                              <p className="text-[10px] text-slate-400 font-bold">{s.subject}</p>
                            )}
                          </div>
                          {totalSec > 0 && (
                            <span className="text-[9px] font-bold text-slate-400 shrink-0 flex items-center gap-0.5">
                              <Clock size={9} />{formatActivityDuration(totalSec)}
                            </span>
                          )}
                        </div>

                        {/* MCQ scores */}
                        {latest && (
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${latestPct >= 70 ? 'bg-emerald-50 text-emerald-700' : latestPct >= 40 ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-600'}`}>
                              Last: {latest.correct}/{latest.total} ({latestPct}%)
                            </span>
                            {prev && (
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${prevPct >= 70 ? 'bg-emerald-50 text-emerald-700' : prevPct >= 40 ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-600'} opacity-70`}>
                                Prev: {prev.correct}/{prev.total} ({prevPct}%)
                              </span>
                            )}
                            {/* Improvement arrow */}
                            {prev && latestPct !== prevPct && (
                              <span className={`text-[10px] font-black ${latestPct > prevPct ? 'text-emerald-600' : 'text-rose-500'}`}>
                                {latestPct > prevPct ? `↑ +${latestPct - prevPct}%` : `↓ ${latestPct - prevPct}%`}
                              </span>
                            )}
                            <span className="text-[9px] text-slate-400">{s.mcq.attempts} attempt{s.mcq.attempts !== 1 ? 's' : ''}</span>
                          </div>
                        )}

                        {/* Last 5 question timings */}
                        {s.mcq.timings.length > 0 && (
                          <div className="flex items-center gap-1 flex-wrap">
                            <span className="text-[8px] text-slate-400 font-bold">⏱</span>
                            {s.mcq.timings.map((t, ti) => (
                              <span key={ti} className="text-[8px] font-bold bg-slate-100 text-slate-600 px-1 py-[1px] rounded">
                                {t}s
                              </span>
                            ))}
                            <span className="text-[8px] text-slate-400">last q timings</span>
                          </div>
                        )}

                        {/* Mode-wise time breakdown */}
                        <div className="flex flex-wrap gap-1">
                          {(Object.entries(s.seconds) as [string, number][])
                            .filter(([, sec]) => sec > 0)
                            .map(([mode, sec]) => {
                              const emoji = mode === 'READING' ? '📖' : mode === 'WRITING' ? '✍️' : mode === 'MCQ' ? '🧠' : mode === 'VIDEO' ? '🎬' : mode === 'PDF' ? '📄' : mode === 'AUDIO' ? '🔊' : mode === 'FLASHCARD' ? '🃏' : '💬';
                              return (
                                <span key={mode} className="text-[8px] font-bold bg-slate-50 border border-slate-100 text-slate-500 px-1.5 py-[2px] rounded-full">
                                  {emoji} {formatActivityDuration(sec)}
                                </span>
                              );
                            })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <button
                onClick={() => setShowMonthlySheet(true)}
                className="w-full flex items-center justify-between px-4 py-3.5 rounded-2xl border border-indigo-200 bg-indigo-50 active:scale-[0.99] transition-all"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📊</span>
                  <div className="text-left">
                    <p className="font-black text-slate-800 text-sm">Monthly Report</p>
                    <p className="text-[10px] text-slate-500">Full marksheet aur analysis</p>
                  </div>
                </div>
                <ChevronRight size={16} className="text-indigo-400" />
              </button>
            </div>
          );
        })()}
      </div>

      {showMonthlySheet && (
        <MonthlyMarksheet
          user={user}
          settings={settings}
          onClose={() => setShowMonthlySheet(false)}
        />
      )}

      {/* Coin deduction modal */}
      {coinModal && (
        <CreditConfirmationModal
          title={coinModal.title}
          cost={coinModal.cost}
          userCredits={getTotalCredits(user)}
          diamondCost={coinModal.diamondCost}
          userDiamonds={user.diamonds || 0}
          onConfirm={() => coinModal.onConfirmCredits()}
          onConfirmDiamonds={() => coinModal.onConfirmDiamonds()}
          onCancel={() => { setCoinModal(null); setPendingLesson(null); }}
          isAutoEnabledInitial={false}
        />
      )}
    </div>
  );
};
